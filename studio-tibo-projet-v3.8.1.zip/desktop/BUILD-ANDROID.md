# STUDIO TIBO — Compiler l'APK Android

Le même projet Tauri qui produit le .exe Windows produit aussi une **vraie
application Android**. Ce guide va du PC vide jusqu'au .apk installé sur
votre téléphone ou votre tablette.

## 0. À savoir avant de commencer (l'honnêteté d'abord)

- **Tablette recommandée** : l'interface de STUDIO TIBO est pensée pour un
  grand écran. Sur tablette c'est confortable ; sur téléphone, c'est dense
  (le zoom à deux doigts fonctionne). Tout est tactile (pointer events) et
  le clavier à l'écran 🎹 remplace le clavier d'ordinateur.
- **Pas de MIDI USB sur Android** : la WebView Android ne propose pas le
  Web MIDI. Le clavier 🎹, la saisie pas à pas ✎, l'import/export .mid et
  l'enregistrement à la souris/au doigt fonctionnent, eux, parfaitement.
- **Multi-fenêtres ⧉** : sans objet sur Android (une seule fenêtre).
- **Micro 🎤** : fonctionne, à condition d'ajouter la permission (étape 4).
- L'audio passe par la WebView (moteur Chrome) : latence un peu supérieure
  au bureau, très correcte pour composer.

## 1. Prérequis (une seule fois)

1. **Node.js** ≥ 18 → https://nodejs.org
2. **Rust** → https://rustup.rs
3. **Android Studio** → https://developer.android.com/studio — puis dans
   *SDK Manager*, installez : **Android SDK Platform** (API 34+),
   **SDK Build-Tools**, **NDK (Side by side)**, **CMake** et
   **Android SDK Platform-Tools** (adb).
4. **Variables d'environnement** (Windows : Paramètres → variables
   d'environnement ; macOS/Linux : votre shell) :
   - `ANDROID_HOME` → le dossier du SDK (ex. `C:\Users\vous\AppData\Local\Android\Sdk`)
   - `NDK_HOME` → `%ANDROID_HOME%\ndk\<version>` 
   - `JAVA_HOME` → le JDK 17 fourni par Android Studio
     (ex. `C:\Program Files\Android\Android Studio\jbr`)
5. **Cibles Rust Android** (le script le fait pour vous) :
   `rustup target add aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android`

Redémarrez le terminal après tout ça.

## 2. Compiler

Double-cliquez **`build-android.bat`** (Windows) ou lancez
**`./build-android.sh`** (macOS/Linux). Le script :
vérifie l'environnement → installe les cibles Rust → `npm install` →
**génère le projet Android la première fois** (`tauri android init`) →
compile l'**APK debug**, directement installable.

La première compilation est longue (Rust compile pour 4 architectures) ;
les suivantes sont incrémentales.

## 3. Récupérer et installer l'APK

L'APK universel est dans :
`src-tauri/gen/android/app/build/outputs/apk/universal/debug/app-universal-debug.apk`

- **Par câble** : `adb install chemin/vers/app-universal-debug.apk`
- **Sans câble** : copiez le .apk sur l'appareil (cloud, câble, mail),
  ouvrez-le ; Android demande d'autoriser « installer des applications
  inconnues » pour votre gestionnaire de fichiers — c'est normal pour
  toute app hors Play Store.

## 4. La permission micro (à faire une fois après l'init)

Ouvrez `src-tauri/gen/android/app/src/main/AndroidManifest.xml` et
ajoutez à côté des autres `<uses-permission>` :

```xml
<uses-permission android:name="android.permission.RECORD_AUDIO"/>
```

Recompilez. Au premier 🎤, Android demandera l'autorisation.

## 5. Version « release » signée (pour distribuer)

L'APK *debug* est signé avec une clé de développement : parfait pour vous.
Pour distribuer (ou publier), il faut **votre** clé :

1. Créez un keystore :
   `keytool -genkey -v -keystore studio-tibo.keystore -alias tibo -keyalg RSA -keysize 2048 -validity 10000`
2. Créez `src-tauri/gen/android/keystore.properties` :
   ```
   storeFile=chemin/vers/studio-tibo.keystore
   storePassword=•••
   keyAlias=tibo
   keyPassword=•••
   ```
3. Suivez la section *Code signing Android* de la documentation Tauri pour
   référencer ce fichier dans `app/build.gradle.kts`, puis :
   `npm run android:release`

Gardez le keystore précieusement : il est exigé pour toute mise à jour.

## 6. Dépannage

- `ANDROID_HOME non défini` → étape 1.4, puis nouveau terminal.
- Erreur NDK/CMake → installez-les via SDK Manager (étape 1.3).
- `java: command not found` ou version → pointez `JAVA_HOME` vers le JDK 17
  d'Android Studio.
- Gradle télécharge longtemps la première fois → normal.
- Mise à jour de l'app : à la racine, `node build.js` (synchronise le HTML
  et les versions), puis relancez le script Android.
