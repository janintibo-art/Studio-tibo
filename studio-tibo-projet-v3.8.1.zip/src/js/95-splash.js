/* ---------- Écran d'accueil ---------- */
let _entered=false;
function enterStudio(){
  if(_entered) return;           // évite le double déclenchement (tactile + clic synthétique)
  _entered=true;
  /* Chaque étape est isolée : sur mobile/WebView, une API absente (MIDI…) ne doit
     jamais empêcher l'entrée dans le studio. */
  try{ audio(); }catch(e){}      // geste utilisateur : déverrouille le moteur audio
  try{ initMidi(); }catch(e){}   // MIDI absent sur Android : on ignore proprement
  try{ applyPendingTibo(); }catch(e){}
  if(window._resume){
    try{
      applyProject(window._resume);
      setStatus('Session précédente restaurée — réglages, patterns et notes. (Les samples audio ne sont pas dans l\'autosauvegarde : sauvegardez en .tibo pour tout conserver.)');
    }catch(e){ setStatus('Reprise impossible : '+e); }
    window._resume=null;
  }
  const sp=$('#splash');
  if(sp){ sp.classList.add('hide'); setTimeout(()=>{ try{sp.remove();}catch(e){} },600); }
  try{ setStatus(isTauri?'Bienvenue dans STUDIO TIBO — bonne production !':'Bienvenue dans STUDIO TIBO. Appuyez sur espace (ou ▶) pour écouter la démo.'); }catch(e){}
  if(isTauri){ const v=$('.logo .ver'); if(v) v.textContent+=' · app'; }
}
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&$('#splash')&&!$('#splash').classList.contains('hide')) enterStudio();
});
{
  const se=$('#splashEnter');
  if(se){
    se.onclick=enterStudio;                          // souris / clic
    se.addEventListener('touchend',ev=>{ ev.preventDefault(); enterStudio(); },{passive:false}); // tactile direct
  }
  /* filet de sécurité : taper n'importe où sur l'accueil entre aussi dans le studio */
  const sp=$('#splash');
  if(sp) sp.addEventListener('pointerup',ev=>{ if(!_entered) enterStudio(); });
}
