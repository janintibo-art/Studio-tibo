# STUDIO TIBO — v3.8.1

> 📱 **Compiler l'APK Android via GitHub (sans rien installer) : voir [`GITHUB-APK.md`](GITHUB-APK.md).**

Station de production musicale dans le navigateur : step sequencer,
enregistrement micro (piste sample avec décalage de latence), piano roll
multi-instruments (notes fantômes, presets, couleurs) avec vélocité,
enregistrement MIDI (claviers USB via Web MIDI + clavier musical ⌨ +
boîtes à rythmes : séparation par note ou par canal, instruments auto-créés),
plugins d'insert (11 effets : Drive, Bitcrusher, Chorus, Tremolo, Phaser,
Flanger, Auto-Wah, Filtre, Compresseur, Pump, Largeur stéréo + bypass
par slot + format ouvert .js,
voir examples/plugin-tibo-exemple.js), patterns multiples, playlist/arrangeur, mixeur (EQ 3 bandes,
envois reverb/delay, vu-mètres, spectre), automation par courbes,
annuler/rétablir, 5 presets de synthé, swing, métronome, bibliothèque de sons
libres, export WAV 16 bit et stems en .zip. Format projet .tibo : une archive
qui embarque réglages et samples audio (module ZIP maison, js/58-zip.js).

## Démarrage rapide

Ouvrez `dist/studio-tibo-v1.0.html` dans un navigateur — c'est tout.
Le fichier est autonome (logo, icônes et code embarqués).

## Compiler depuis les sources

```bash
node build.js
```

Aucune dépendance : le bundler concatène `src/styles/*.css` et `src/js/*.js`
(ordre alphabétique — d'où les préfixes numériques) dans `src/index.html`
et écrit `dist/studio-tibo-v1.0.html`.

## Arborescence

```
studio-tibo/
├── build.js                  Bundler maison (Node, zéro dépendance)
├── src/
│   ├── index.html            Gabarit : markup + tokens {{CSS}} et {{JS}}
│   ├── assets/assets.json    Logo et icônes (WebP base64)
│   ├── styles/               15 feuilles, une par zone d'interface
│   │   ├── 00-base.css       Variables de thème, fond, typographie
│   │   ├── 12-transport.css  Lecture, tempo, swing, vu-mètre master
│   │   ├── 24-pianoroll.css  Grille, notes, lane de vélocité
│   │   ├── 25-automation.css Éditeur de courbes, spectre, métronome
│   │   └── …
│   └── js/                   23 modules, chargés dans l'ordre des préfixes
│       ├── 05-state.js       État du projet (pistes, patterns, automation…)
│       ├── 06-synth-presets  5 sons du synthé interne
│       ├── 10-engine.js      Contexte audio, canaux (gain→EQ→pan), bus FX
│       ├── 12-voices.js      Batterie synthétisée, sampler, synthé, métronome
│       ├── 20-scheduler.js   Ordonnanceur à anticipation, swing, modes PAT/SONG
│       ├── 45-automation.js  Courbes, interpolation, éditeur SVG
│       ├── 60-export.js      Rendu offline + encodeur WAV
│       ├── 68-io.js          Sauvegarde/ouverture (format v5, rétrocompatible v1→v4)
│       ├── 80-undo.js        Annuler/rétablir par instantanés
│       └── …
├── dist/
│   └── studio-tibo-v1.5.html Fichier unique compilé (navigateur)
└── desktop/                  Application de bureau Tauri 2
    ├── README-DESKTOP.md     Prérequis, compilation, installeurs
    ├── src/index.html        Frontend (synchronisé par build.js)
    └── src-tauri/            Rust, configuration, icônes
```

## Conventions

- Tout l'audio passe par des fonctions paramétrées par contexte
  (`playSynth(c, dest, …)`) : la lecture live et l'export offline
  partagent exactement le même code.
- Les mutations « musicales » appellent `pushUndo()` avant de modifier l'état.
- Les buffers audio des samples sont conservés dans `bufReg` (clé `tid`)
  pour survivre aux annulations.
- Format projet : JSON versionné (`version: 5`), les anciens projets
  s'ouvrent et sont convertis.

## Licences

Code : à vous. Identité visuelle : STUDIO TIBO. Le kit de sons interne est
synthétisé par le moteur (libre). Pour étendre la banque, l'onglet
Bibliothèque pointe vers des ressources CC0 / domaine public.
