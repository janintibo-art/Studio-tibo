/* Plugin TIBO — fichier .js à charger via Bibliothèque > Plugins.
   Le fichier doit appeler registerPlugin({...}) :
   - id      : identifiant unique (sauvegardé dans les projets)
   - name    : nom affiché
   - params  : [{key,label,min,max,def,fmt}] — potentiomètres générés automatiquement
   - create(c) : reçoit un AudioContext (ou OfflineAudioContext à l'export) et
                 retourne {input, output, set(key, valeur)} en nœuds Web Audio. */
registerPlugin({
  id:'monfiltre', name:'Mon Filtre',
  desc:'Passe-bas résonant — exemple de plugin TIBO.',
  params:[
    {key:'freq',label:'FREQ',min:100,max:8000,def:1200,fmt:v=>Math.round(v)+' Hz'},
    {key:'q',   label:'RES', min:0.3,max:14,  def:2,   fmt:v=>v.toFixed(1)},
  ],
  create(c){
    const f=c.createBiquadFilter();
    f.type='lowpass'; f.frequency.value=1200; f.Q.value=2;
    return {input:f,output:f,set(k,v){
      if(k==='freq') f.frequency.value=v;
      if(k==='q') f.Q.value=v;
    }};
  }
});
