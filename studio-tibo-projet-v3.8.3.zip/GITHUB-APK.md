# Déposer STUDIO TIBO sur GitHub et obtenir l'APK automatiquement

Bonne nouvelle : **vous n'avez pas besoin d'Android Studio sur votre PC.**
GitHub compile l'APK pour vous, dans le cloud, gratuitement. Le fichier
`.github/workflows/android.yml` est déjà inclus dans le projet — il s'occupe
de tout dès que le code est en ligne.

Ce guide couvre les **deux façons** d'envoyer le projet : par le **site web**
(glisser-déposer, sans rien installer) ou par la **ligne de commande git**
(plus pro, idéal pour les mises à jour).

---

## Étape 1 — Créer le dépôt (commun aux deux méthodes)

1. Connectez-vous sur https://github.com (créez un compte si besoin, gratuit).
2. En haut à droite : **+** → **New repository**.
3. **Repository name** : par exemple `studio-tibo`.
4. Laissez-le **Public** (obligatoire pour des Actions gratuites illimitées ;
   en privé vous avez tout de même un quota mensuel large).
5. **Ne cochez PAS** « Add a README » (le projet en a déjà un).
6. Cliquez **Create repository**. Gardez la page ouverte.

---

## Méthode A — Par le site web (glisser-déposer)

> Le plus simple, zéro installation. Une limite : l'interface web n'accepte
> pas les **dossiers vides** et peut être fastidieuse pour beaucoup de
> fichiers. L'astuce ci-dessous l'évite.

1. **Préparez les fichiers à envoyer.** Décompressez
   `studio-tibo-projet-v3.8.zip`. Vous obtenez un dossier contenant
   `README.md`, `build.js`, `src/`, `dist/`, `examples/`, `desktop/`,
   **`.github/`** et **`.gitignore`**.

   ⚠️ Les noms commençant par un point (`.github`, `.gitignore`) sont parfois
   masqués par l'explorateur de fichiers — activez « Afficher les fichiers
   cachés ». **`.github/` est indispensable** : c'est lui qui contient la
   recette de compilation.

2. Sur la page du dépôt vide, cliquez le lien
   **« uploading an existing file »** (ou allez dans **Add file → Upload files**).

3. **Glissez-déposez tout le contenu** du dossier décompressé dans la zone
   prévue (sélectionnez les fichiers ET les sous-dossiers `src`, `desktop`,
   `.github`… — vous pouvez tout sélectionner d'un coup et glisser).

   Si `.github` refuse de partir par glisser-déposer (certains navigateurs
   filtrent les dossiers cachés), voir l'encadré « Si .github ne monte pas ».

4. En bas, dans **Commit changes**, laissez le message par défaut et cliquez
   **Commit changes**.

5. **C'est parti tout seul.** Ouvrez l'onglet **Actions** du dépôt : une tâche
   « Build Android APK » tourne (point orange → coche verte). Comptez
   ~10-20 min la première fois.

### Si `.github` ne monte pas par glisser-déposer

Créez le fichier à la main sur GitHub :

1. **Add file → Create new file**.
2. Dans le champ du nom, tapez exactement :
   `.github/workflows/android.yml`
   (les `/` créent les dossiers automatiquement).
3. Ouvrez `android.yml` depuis le zip avec un éditeur de texte, copiez tout,
   collez dans la grande zone.
4. **Commit changes**. L'onglet Actions démarre la compilation.

---

## Méthode B — Par la ligne de commande (git)

> Idéale pour les mises à jour : une fois en place, publier une nouvelle
> version = trois commandes.

### Installer git (une fois)

- Windows : https://git-scm.com/download/win (options par défaut).
- macOS : `xcode-select --install` (ou git est déjà là).
- Linux : `sudo apt install git`.

### Envoyer le projet

Ouvrez un terminal **dans le dossier décompressé** du projet (celui qui
contient `README.md` et `.github/`) et lancez, ligne par ligne :

```bash
git init
git add .
git commit -m "STUDIO TIBO v3.8"
git branch -M main
git remote add origin https://github.com/VOTRE-PSEUDO/studio-tibo.git
git push -u origin main
```

Remplacez `VOTRE-PSEUDO` (l'URL exacte est affichée sur la page du dépôt).
GitHub demandera votre identifiant : utilisez un **token d'accès personnel**
comme mot de passe (Settings → Developer settings → Personal access tokens →
*Generate new token*, cochez le scope `repo`). Collez-le quand le terminal
demande le mot de passe.

Le `.gitignore` fourni exclut automatiquement `node_modules`, les dossiers
de compilation et les `.apk` : seul le code source part, c'est voulu.

---

## Étape 2 — Récupérer l'APK

### À chaque envoi (artefact)

1. Onglet **Actions** → cliquez le run le plus récent (coche verte).
2. En bas, section **Artifacts** : **studio-tibo-apk**. Cliquez pour
   télécharger un `.zip` contenant `studio-tibo.apk`.

> Note : un artefact est forcément livré dans un zip par GitHub ; décompressez
> pour obtenir le `.apk`.

### Version publique téléchargeable (Release)

Pour produire une **page de téléchargement propre** (utile pour partager) :

```bash
git tag v3.8
git push origin v3.8
```

(ou par le site : **Releases → Draft a new release → Choose a tag →** tapez
`v3.8` → **Publish**.)

Le workflow détecte le tag, compile, et **attache `studio-tibo.apk` à une
Release** : onglet **Releases** du dépôt, le fichier est en téléchargement
direct, sans zip.

---

## Étape 3 — Installer sur le téléphone / la tablette

1. Téléchargez `studio-tibo.apk` sur l'appareil (depuis la Release, ou
   transférez l'artefact décompressé).
2. Ouvrez-le. Android demande d'autoriser « installer des applications
   inconnues » pour votre navigateur ou gestionnaire de fichiers — normal
   hors Play Store, acceptez.
3. STUDIO TIBO s'installe avec son icône. 🎉

> L'APK produit ici est **debug** (signé avec une clé de développement) :
> parfait pour vous et vos proches. Pour le Play Store, il faut une version
> *release* signée avec votre propre clé — voir `desktop/BUILD-ANDROID.md`,
> section 5.

---

## Mettre à jour l'application plus tard

- **Site web** : Add file → Upload files → glissez les fichiers modifiés →
  Commit. La compilation repart.
- **Ligne de commande** :
  ```bash
  git add .
  git commit -m "nouvelle version"
  git push
  ```

Dans les deux cas, l'onglet Actions reconstruit l'APK automatiquement.

---

## Dépannage

- **Actions ne démarre pas** : vérifiez que le dossier `.github/workflows/`
  est bien présent dans le dépôt (il est peut-être resté masqué localement).
- **Le run échoue à `tauri android init`** : c'est souvent temporaire
  (réseau). Relancez via **Actions → le run → Re-run jobs**.
- **« Actions disabled »** : onglet **Settings → Actions → General →**
  autorisez les workflows.
- **Quota** : sur un dépôt public, les minutes Actions sont gratuites et
  illimitées. Gardez-le public si possible.
