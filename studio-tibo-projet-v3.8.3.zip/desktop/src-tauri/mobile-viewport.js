(function(){
  function fixVP(){
    try{
      var m=document.querySelector('meta[name=viewport]');
      if(!m){ m=document.createElement('meta'); m.name='viewport'; (document.head||document.documentElement).appendChild(m); }
      m.setAttribute('content','width=device-width, initial-scale=1.0, maximum-scale=5.0, viewport-fit=cover');
    }catch(e){}
  }
  fixVP();
  document.addEventListener('DOMContentLoaded',fixVP);
})();