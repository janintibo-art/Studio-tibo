use std::sync::Mutex;

/// Chemin du fichier .tibo passé en argument (double-clic / "Ouvrir avec")
struct OpenFile(Mutex<Option<std::path::PathBuf>>);

const B64: &[u8] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
fn b64encode(data: &[u8]) -> String {
    let mut out = String::with_capacity((data.len() + 2) / 3 * 4);
    for chunk in data.chunks(3) {
        let b = [chunk[0], *chunk.get(1).unwrap_or(&0), *chunk.get(2).unwrap_or(&0)];
        let n = ((b[0] as u32) << 16) | ((b[1] as u32) << 8) | (b[2] as u32);
        out.push(B64[(n >> 18) as usize & 63] as char);
        out.push(B64[(n >> 12) as usize & 63] as char);
        out.push(if chunk.len() > 1 { B64[(n >> 6) as usize & 63] as char } else { '=' });
        out.push(if chunk.len() > 2 { B64[(n as usize) & 63] as char } else { '=' });
    }
    out
}

#[derive(serde::Serialize)]
struct OpenPayload {
    name: String,
    b64: String,
}

/// Le frontend appelle cette commande au démarrage : si l'application a été
/// lancée en double-cliquant un projet .tibo, elle reçoit son contenu.
#[tauri::command]
fn read_open_file(state: tauri::State<OpenFile>) -> Option<OpenPayload> {
    let path = state.0.lock().ok()?.take()?;
    let data = std::fs::read(&path).ok()?;
    Some(OpenPayload {
        name: path
            .file_name()
            .map(|s| s.to_string_lossy().into_owned())
            .unwrap_or_else(|| "projet.tibo".into()),
        b64: b64encode(&data),
    })
}

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let open = std::env::args()
        .skip(1)
        .map(std::path::PathBuf::from)
        .find(|p| {
            p.extension()
                .map(|e| e.eq_ignore_ascii_case("tibo"))
                .unwrap_or(false)
                && p.exists()
        });
    tauri::Builder::default()
        .manage(OpenFile(Mutex::new(open)))
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_fs::init())
        .invoke_handler(tauri::generate_handler![read_open_file])
        .run(tauri::generate_context!())
        .expect("erreur au lancement de STUDIO TIBO");
}
