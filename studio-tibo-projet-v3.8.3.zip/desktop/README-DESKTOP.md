# STUDIO TIBO — Application de bureau (Tauri 2)

La même application que `dist/studio-tibo-v1.5.html`, empaquetée en
application native : fenêtre dédiée avec l'icône STUDIO TIBO, installeurs
Windows / macOS / Linux, et boîtes de dialogue « Enregistrer sous » natives
pour tous les exports (WAV, stems .zip, projets .tibo/.json, plugins).

**Windows : guide dédié `BUILD-WINDOWS.md`** · **Android (.apk) : guide dédié `BUILD-ANDROID.md`**

**Windows : voir le guide dédié `BUILD-WINDOWS.md`** (scripts .bat un-clic,
association .tibo, notes SmartScreen).

## Prérequis (une seule fois)

1. **Node.js** ≥ 18 — https://nodejs.org
2. **Rust** (stable) — https://rustup.rs
3. Dépendances système :
   - **Windows** : WebView2 (déjà présent sur Windows 10/11) + outils de
     compilation C++ (« Desktop development with C++ » de Visual Studio
     Build Tools).
   - **macOS** : Xcode Command Line Tools (`xcode-select --install`).
   - **Linux (Debian/Ubuntu)** :
     `sudo apt install libwebkit2gtk-4.1-dev build-essential curl wget file libxdo-dev libssl-dev libayatana-appindicator3-dev librsvg2-dev`

## Lancer en développement

```bash
cd desktop
npm install
npm run dev
```

Première compilation Rust : quelques minutes ; ensuite c'est instantané.

## Construire les installeurs

```bash
npm run build
```

Les paquets sortent dans `desktop/src-tauri/target/release/bundle/` :
`.msi`/`.exe` (Windows), `.dmg`/`.app` (macOS), `.deb`/`.rpm`/`.AppImage` (Linux).

Icône macOS : générer le `.icns` avec `npm run icon` (à lancer une fois
sur macOS, ou sur n'importe quel OS — la commande régénère tout le jeu
d'icônes depuis `src-tauri/icons/icon.png`).

## Mettre à jour l'application

Le frontend de l'app de bureau est `desktop/src/index.html`, produit par
le bundler du projet : à chaque modification des sources, relancer à la
racine :

```bash
node build.js
```

(il recompile le fichier unique **et** synchronise `desktop/src/index.html`),
puis `npm run dev` / `npm run build` dans `desktop/`.

## Notes honnêtes par plateforme

- **Entrée MIDI USB (Web MIDI)** : garantie sous **Windows** (WebView2 est
  basé sur Chromium). Sous macOS (WKWebView) et Linux (WebKitGTK), le
  Web MIDI n'est pas exposé par la vue web : le **clavier musical ⌨**
  reste disponible partout. Un pont MIDI natif (Rust `midir` → événements
  Tauri) est la solution propre — candidate pour une version future.
- **VST natifs** : l'app de bureau est le prérequis, pas la solution
  complète. Héberger des .vst3 demande un hôte natif (scan, instanciation,
  GUI embarquée, compensation de latence) — un chantier de type JUCE.
  En attendant, les plugins TIBO (.js) fonctionnent à l'identique en
  bureau et en navigateur.
- La version navigateur (`dist/studio-tibo-v1.5.html`) reste pleinement
  fonctionnelle : c'est le même fichier.
