@echo off
chcp 65001 >nul
echo ============================================
echo   STUDIO TIBO — compilation Windows (.exe)
echo ============================================
where cargo >nul 2>nul || (echo [ERREUR] Rust introuvable. Installez-le : https://rustup.rs && pause && exit /b 1)
where node  >nul 2>nul || (echo [ERREUR] Node.js introuvable. Installez-le : https://nodejs.org && pause && exit /b 1)
echo.
echo [1/2] Dependances...
call npm install || (pause && exit /b 1)
echo.
echo [2/2] Compilation (quelques minutes la premiere fois)...
call npm run build || (pause && exit /b 1)
echo.
echo ============================================
echo   TERMINE !
echo   Installeur : src-tauri\target\release\bundle\nsis\*.exe
echo   MSI        : src-tauri\target\release\bundle\msi\*.msi
echo   Executable : src-tauri\target\release\studio-tibo.exe
echo ============================================
pause
