# STUDIO TIBO — Compiler le .exe Windows

Guide pas à pas pour produire une vraie application Windows : un installeur
`.exe` (NSIS, en français), un `.msi`, et l'exécutable portable.

## 1. Prérequis (à installer une seule fois)

1. **Node.js** ≥ 18 → https://nodejs.org (installeur Windows, options par défaut)
2. **Rust** → https://rustup.rs (lancez `rustup-init.exe`, options par défaut)
3. **Outils C++ de Visual Studio** : rustup vous le proposera ; sinon installez
   « Build Tools for Visual Studio » et cochez **« Développement Desktop en C++ »**.
4. **WebView2** : déjà présent sur Windows 10/11 (rien à faire).

Redémarrez le terminal après ces installations.

## 2. Compiler

Double-cliquez **`build-windows.bat`** dans ce dossier. C'est tout.
(Ou en ligne de commande : `npm install` puis `npm run build`.)

La première compilation prend quelques minutes (Rust compile tout) ;
les suivantes sont rapides.

## 3. Récupérer l'application

Dans `src-tauri\target\release\` :

| Fichier | Usage |
|---|---|
| `bundle\nsis\STUDIO TIBO_2.x.0_x64-setup.exe` | **Installeur** (français) — à distribuer |
| `bundle\msi\STUDIO TIBO_2.x.0_x64_fr-FR.msi` | Installeur MSI (déploiement entreprise) |
| `studio-tibo.exe` | Exécutable **portable** (fonctionne seul) |

## 4. Ce que fait l'installeur

- Icône STUDIO TIBO dans le menu Démarrer et sur le Bureau.
- **Association du format `.tibo`** : double-cliquer un projet ouvre
  l'application **avec le projet chargé** (réglages + samples).
- Installation par utilisateur (pas besoin d'être administrateur).
- Désinstallation propre via Paramètres Windows.

## 5. Notes importantes et honnêtes

- **SmartScreen** : l'application n'étant pas signée numériquement, Windows
  affichera « Windows a protégé votre ordinateur » au premier lancement chez
  d'autres utilisateurs → cliquer « Informations complémentaires » puis
  « Exécuter quand même ». Pour supprimer cet avertissement, il faut un
  **certificat de signature de code** (payant, ~200-400 €/an chez DigiCert,
  Sectigo…) — à envisager seulement pour une distribution large.
- **MIDI USB** : fonctionne (WebView2 est basé sur Chromium). Branchez votre
  clavier ou votre boîte à rythmes avant ou après le lancement.
- **Micro** : Windows demandera l'autorisation au premier enregistrement 🎤.
- **Mise à jour de l'application** : à la racine du projet, `node build.js`
  recompile le fichier unique, synchronise `desktop/src/index.html` **et les
  numéros de version** (tauri.conf.json, package.json, Cargo.toml) — puis
  relancez `build-windows.bat`.

## 6. Dépannage

- `cargo introuvable` → réinstallez Rust via rustup et rouvrez le terminal.
- Erreur `link.exe` → les outils C++ de Visual Studio manquent (étape 1.3).
- Compilation très longue → normal la première fois uniquement.
- Antivirus qui bloque → ajoutez le dossier du projet aux exclusions le
  temps de la compilation.
