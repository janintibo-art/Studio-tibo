@echo off
chcp 65001 >nul
echo === STUDIO TIBO — mode developpement ===
where cargo >nul 2>nul || (echo [ERREUR] Rust introuvable : https://rustup.rs && pause && exit /b 1)
where node  >nul 2>nul || (echo [ERREUR] Node.js introuvable : https://nodejs.org && pause && exit /b 1)
call npm install || (pause && exit /b 1)
call npm run dev
pause
