@echo off
chcp 65001 >nul
echo ============================================
echo   STUDIO TIBO — compilation Android (.apk)
echo ============================================
where node >nul 2>nul || (echo [ERREUR] Node.js introuvable : https://nodejs.org && pause && exit /b 1)
where rustup >nul 2>nul || (echo [ERREUR] Rust introuvable : https://rustup.rs && pause && exit /b 1)
if "%ANDROID_HOME%"=="" (echo [ERREUR] ANDROID_HOME non defini. Installez Android Studio puis le SDK+NDK ^(voir BUILD-ANDROID.md^) && pause && exit /b 1)
if "%JAVA_HOME%"=="" (echo [ATTENTION] JAVA_HOME non defini : le JDK 17 d'Android Studio sera peut-etre introuvable.)
echo.
echo [1/4] Cibles Rust Android (rapide si deja installees)...
rustup target add aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android
echo.
echo [2/4] Dependances Node...
call npm install || (pause && exit /b 1)
echo.
if not exist src-tauri\gen\android (
  echo [3/4] Premiere fois : generation du projet Android...
  call npx tauri android init || (pause && exit /b 1)
  echo.
  echo [INFO] Pensez a ajouter la permission micro dans
  echo        src-tauri\gen\android\app\src\main\AndroidManifest.xml :
  echo        ^<uses-permission android:name="android.permission.RECORD_AUDIO"/^>
  echo.
) else (
  echo [3/4] Projet Android deja genere.
)
echo [4/4] Compilation APK (debug, installable directement)...
call npx tauri android build --apk --debug || (pause && exit /b 1)
echo.
echo ============================================
echo   TERMINE !
echo   APK : src-tauri\gen\android\app\build\outputs\apk\universal\debug\
echo   Copiez le .apk sur le telephone/la tablette et ouvrez-le,
echo   ou : adb install chemin\vers\app-universal-debug.apk
echo ============================================
pause
