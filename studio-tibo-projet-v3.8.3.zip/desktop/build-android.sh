#!/usr/bin/env bash
set -e
echo "=== STUDIO TIBO — compilation Android (.apk) ==="
command -v node >/dev/null || { echo "[ERREUR] Node.js introuvable : https://nodejs.org"; exit 1; }
command -v rustup >/dev/null || { echo "[ERREUR] Rust introuvable : https://rustup.rs"; exit 1; }
[ -n "$ANDROID_HOME" ] || { echo "[ERREUR] ANDROID_HOME non défini (voir BUILD-ANDROID.md)"; exit 1; }
echo "[1/4] Cibles Rust Android…"
rustup target add aarch64-linux-android armv7-linux-androideabi i686-linux-android x86_64-linux-android
echo "[2/4] Dépendances Node…"
npm install
if [ ! -d src-tauri/gen/android ]; then
  echo "[3/4] Première fois : génération du projet Android…"
  npx tauri android init
  echo "[INFO] Ajoutez la permission micro dans src-tauri/gen/android/app/src/main/AndroidManifest.xml :"
  echo '       <uses-permission android:name="android.permission.RECORD_AUDIO"/>'
else
  echo "[3/4] Projet Android déjà généré."
fi
echo "[4/4] Compilation APK (debug, installable directement)…"
npx tauri android build --apk --debug
echo "=== TERMINÉ ! APK : src-tauri/gen/android/app/build/outputs/apk/universal/debug/ ==="
