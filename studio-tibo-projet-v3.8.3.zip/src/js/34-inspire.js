/* ---------- ✨ Inspiration : générateur euclidien + mélodie dans la gamme ---------- */
function euclid(k,n){
  const out=[]; let acc=0;
  for(let i=0;i<n;i++){ acc+=k; if(acc>=n){acc-=n;out.push(true);} else out.push(false); }
  return out;
}
function inspire(){
  pushUndo();
  const pat=patterns[curPat], R=Math.random;
  const find=k=>tracks.findIndex(t=>t.kind===k);
  const fill=(ti,arr)=>{ if(ti>=0) pat.steps[ti]=arr.map(on=>on?(R()<0.25?2:3):0); };
  /* batterie */
  fill(find('kick'),euclid(3+Math.floor(R()*3),16));
  const sn=Array(16).fill(false); sn[4]=sn[12]=true; if(R()<0.35) sn[14]=true;
  fill(find('snare'),sn);
  const hat=Array.from({length:16},(_,i)=>R()<0.18?false:i%(R()<0.5?2:1)===0);
  fill(find('hat'),hat);
  const cl=Array(16).fill(false); if(R()<0.6) cl[7]=true; if(R()<0.5) cl[15]=true;
  fill(find('clap'),cl);
  /* mélodie dans la gamme, contour en marche aléatoire bornée */
  const iv=SCALES[scaleKey].iv;
  const tone=(deg,oct)=>{
    const d=((deg%iv.length)+iv.length)%iv.length;
    const o=oct+Math.floor(deg/iv.length);
    let p=48+((scaleRoot+iv[d])%12)+o*12;
    while(p>TOPNOTE) p-=12;
    while(p<BOTNOTE) p+=12;
    return p;
  };
  const arr=[]; let deg=0, step=0;
  while(step<LOOP){
    const dur=[1,2,2,3,4][Math.floor(R()*5)];
    if(R()<0.82) arr.push({pitch:tone(deg,1),start:step,
      dur:Math.min(dur,LOOP-step),vel:+(0.55+R()*0.4).toFixed(2)});
    deg+=Math.floor(R()*5)-2;
    deg=Math.max(-3,Math.min(10,deg));
    step+=dur+(R()<0.2?1:0);
  }
  /* cadence : finir sur la fondamentale */
  if(arr.length) arr[arr.length-1].pitch=tone(0,1);
  pat.melo[curInst]=arr; notes=arr;
  renderTracks(); renderNotes();
  setStatus(`✨ Inspiration : « ${pat.name} » régénéré en ${dispNote(scaleRoot)} ${SCALES[scaleKey].label} (${curIns().name}). Relancez pour une autre idée — ⌘Z pour revenir.`);
}
function humanize(){
  pushUndo();
  const pat=patterns[curPat];
  let n=0;
  pat.melo.forEach(arr=>arr.forEach(nt=>{
    nt.vel=Math.min(1,Math.max(0.15,+(nt.vel*(0.88+Math.random()*0.24)).toFixed(2))); n++;
  }));
  renderNotes();
  setStatus(`Vélocités humanisées (±12 %) : ${n} note(s) dans ${pat.name}.`);
}
function vary(){
  pushUndo();
  const pat=patterns[curPat], R=Math.random;
  /* drums : micro-jitter — les charleys gagnent/perdent des pas, les autres varient en nuance */
  tracks.forEach((tr,ti)=>{
    const st=pat.steps[ti]; if(!st) return;
    const hatLike=tr.kind==='hat'||
      (tr.kind==='mach'&&/^(CH|OH|TIK|OHX)$/.test(MACHINES[tr.mach.kit].sounds[tr.mach.si][0]));
    st.forEach((v,si)=>{
      if(hatLike&&R()<0.12) st[si]=v?0:(R()<0.5?2:3);
      else if(v&&R()<0.18) st[si]=Math.max(1,Math.min(3,v+(R()<0.5?-1:1)));
    });
  });
  /* mélodie de l'instrument courant : 2 échanges de hauteurs, 1 micro-décalage, nuances */
  const arr=pat.melo[curInst]||[];
  if(arr.length>1){
    for(let k=0;k<2;k++){
      const a=arr[Math.floor(R()*arr.length)], b=arr[Math.floor(R()*arr.length)];
      const tmp=a.pitch; a.pitch=b.pitch; b.pitch=tmp;
    }
    const n=arr[Math.floor(R()*arr.length)];
    n.start=Math.max(0,Math.min(LOOP-n.dur,+(n.start+(R()<0.5?-gridRes:gridRes)).toFixed(4)));
    arr.forEach(nt=>nt.vel=Math.min(1,Math.max(0.2,+(nt.vel*(0.9+R()*0.2)).toFixed(2))));
  }
  renderTracks(); renderNotes();
  setStatus('⚄ Variation appliquée à '+pat.name+' — l\'idée reste, le détail bouge. Relancez ou ⌘Z.');
}
$('#mVary').onclick=vary;
$('#mInspire').onclick=inspire;
$('#mHuman').onclick=humanize;
