/* ---------- Outils de pattern (instrument courant) ---------- */
function patTool(label,fn){
  if(!notes) return;
  pushUndo();
  fn();
  renderNotes();
  setStatus(label+' — '+curIns().name+' / '+patterns[curPat].name+' (⌘Z pour revenir).');
}
const clampPitch=p=>Math.max(BOTNOTE,Math.min(TOPNOTE,p));
const targetNotes=()=>(typeof sel!=='undefined'&&sel.size)?[...sel].map(i=>notes[i]).filter(Boolean):notes;
function toolTranspose(n){
  patTool('Transposition '+(n>0?'+':'')+n+(sel.size?' (sélection)':''),()=>targetNotes().forEach(nt=>nt.pitch=clampPitch(nt.pitch+n)));
}
function toolShift(dir){
  patTool('Décalage '+(dir>0?'→':'←')+' d\'un pas de grille'+(sel.size?' (sélection)':''),()=>{
    targetNotes().forEach(nt=>{
      nt.start=((nt.start+dir*gridRes)%LOOP+LOOP)%LOOP;
      nt.dur=Math.min(nt.dur,LOOP-nt.start);
    });
  });
}
function toolInvert(){
  patTool('Rétrograde (miroir temporel)',()=>{
    notes.forEach(nt=>{ nt.start=Math.max(0,LOOP-(nt.start+nt.dur)); });
  });
}
function toolLegato(){
  patTool('Legato',()=>{
    const arr=[...notes].sort((a,b)=>a.start-b.start);
    arr.forEach((nt,i)=>{
      let next=LOOP;
      for(let j=i+1;j<arr.length;j++) if(arr[j].start>nt.start+1e-6){ next=arr[j].start; break; }
      nt.dur=Math.max(gridRes,Math.min(next-nt.start,LOOP-nt.start));
    });
  });
}
function toolDouble(){
  patTool('Première moitié doublée vers la seconde',()=>{
    const H=LOOP/2;
    const keep=notes.filter(n=>n.start<H);
    const out=keep.concat(keep.map(n=>({...n,start:n.start+H,dur:Math.min(n.dur,LOOP-(n.start+H))})));
    patterns[curPat].melo[curInst]=out; notes=out;
  });
}
function toolVel(kind){
  const lbl={up:'Vélocités en rampe ↗',down:'Vélocités en rampe ↘',uni:'Vélocités uniformisées'}[kind];
  patTool(lbl,()=>{
    notes.forEach(n=>{
      const f=n.start/LOOP;
      if(kind==='up')   n.vel=+(0.35+0.65*f).toFixed(2);
      if(kind==='down') n.vel=+(1-0.65*f).toFixed(2);
      if(kind==='uni')  n.vel=defaultVel;
    });
  });
}
function toolQuantize(strength){
  patTool('Quantisation '+Math.round(strength*100)+' % vers la grille',()=>{
    notes.forEach(n=>{
      const target=Math.round(n.start/gridRes)*gridRes;
      n.start=+(n.start+(target-n.start)*strength).toFixed(4);
      n.start=Math.max(0,Math.min(LOOP-gridRes,n.start));
      n.dur=Math.min(n.dur,LOOP-n.start);
    });
  });
}
$('#mQ100').onclick=()=>toolQuantize(1);
$('#mQ50').onclick=()=>toolQuantize(0.5);
$('#mCapture').onclick=()=>captureTake();
$('#mTrU').onclick=()=>toolTranspose(1);
$('#mTrD').onclick=()=>toolTranspose(-1);
$('#mTrOU').onclick=()=>toolTranspose(12);
$('#mTrOD').onclick=()=>toolTranspose(-12);
$('#mShL').onclick=()=>toolShift(-1);
$('#mShR').onclick=()=>toolShift(1);
$('#mInv').onclick=toolInvert;
$('#mLeg').onclick=toolLegato;
$('#mDbl').onclick=toolDouble;
$('#mVRU').onclick=()=>toolVel('up');
$('#mVRD').onclick=()=>toolVel('down');
$('#mVUni').onclick=()=>toolVel('uni');
/* Raccourcis : ⌥ + flèches (⇧ pour l'octave) — inactifs en mode clavier musical */
document.addEventListener('keydown',e=>{
  if(!e.altKey||kbdOn||e.target.tagName==='INPUT') return;
  if(e.code==='ArrowUp'){ e.preventDefault(); toolTranspose(e.shiftKey?12:1); }
  else if(e.code==='ArrowDown'){ e.preventDefault(); toolTranspose(e.shiftKey?-12:-1); }
  else if(e.code==='ArrowLeft'){ e.preventDefault(); toolShift(-1); }
  else if(e.code==='ArrowRight'){ e.preventDefault(); toolShift(1); }
});
