/* ---------- Vues détachables : chaque module dans sa fenêtre (multi-écrans) ----------
   Le DOM de la vue est déplacé dans une fenêtre fille ; tout le JavaScript, l'état
   et l'audio restent dans la fenêtre principale. Fermer la fenêtre réintègre la vue. */
const POPVIEWS={pr:'Piano roll',mix:'Mixeur',pl:'Playlist',auto:'Automation',seq:'Séquenceur',tuto:'Tutoriel',vst:'VST & Plugins'};
const popups={};
function popOut(id){
  const ex=popups[id];
  if(ex&&ex.win&&!ex.win.closed){ try{ex.win.focus();}catch(e){} return; }
  const el=document.getElementById('view-'+id);
  if(!el) return;
  let w=null;
  try{ w=window.open('','tibo_'+id,'width=1150,height=680'); }catch(e){}
  if(!w){
    setStatus('Le navigateur a bloqué l\'ouverture — autorisez les fenêtres contextuelles pour STUDIO TIBO. (Dans l\'app de bureau, cette fonction dépend de la version : utilisez la version navigateur si besoin.)');
    return;
  }
  try{
    w.document.title='STUDIO TIBO — '+POPVIEWS[id];
    w.document.head.innerHTML='';
    document.querySelectorAll('style').forEach(s=>w.document.head.appendChild(w.document.importNode(s,true)));
    w.document.documentElement.style.cssText=document.documentElement.style.cssText;
    w.document.body.style.margin='0';
    const ph=document.createElement('div'); ph.style.display='none';
    el.parentNode.insertBefore(ph,el);
    w.document.body.appendChild(el);
    el.classList.add('active','popped');
    DOCS.push(w.document);
    _docL.forEach(([t,f,o])=>{ try{ w.document.addEventListener(t,f,o); }catch(e){} });
    const iv=setInterval(()=>{ if(w.closed) popIn(id); },400);
    popups[id]={win:w,ph,iv,el};
    if(!document.querySelector('.view.active')) switchView('seq');
    syncPopTabs();
    setStatus(POPVIEWS[id]+' détaché dans sa propre fenêtre — glissez-la sur votre second écran ; la fermer le réintègre ici.');
  }catch(err){
    try{ w.close(); }catch(e){}
    setStatus('Détachement impossible : '+err);
  }
}
function popIn(id){
  const p=popups[id]; if(!p) return;
  delete popups[id];
  clearInterval(p.iv);
  const di=DOCS.indexOf(p.win.document); if(di>0) DOCS.splice(di,1);
  try{ p.ph.parentNode.insertBefore(p.el,p.ph); p.ph.remove(); }catch(e){}
  p.el.classList.remove('popped','active');
  if(!p.win.closed){ try{ p.win.close(); }catch(e){} }
  syncPopTabs();
  switchView(id);
  setStatus(POPVIEWS[id]+' réintégré dans la fenêtre principale.');
}
function syncPopTabs(){
  document.querySelectorAll('.tab[data-view]').forEach(t=>{
    const p=popups[t.dataset.view];
    t.classList.toggle('popped',!!(p&&p.win&&!p.win.closed));
  });
}
/* bouton ⧉ dans l'en-tête de chaque vue détachable */
Object.keys(POPVIEWS).forEach(id=>{
  const h=document.querySelector('#view-'+id+' h2');
  if(!h) return;
  const b=document.createElement('button');
  b.className='pchip tool popbtn'; b.textContent='⧉ Fenêtre';
  b.title='Ouvrir « '+POPVIEWS[id]+' » dans une fenêtre séparée — parfait en multi-écrans ; fermer la fenêtre le réintègre';
  b.onclick=()=>popOut(id);
  h.append(b);
});
window.addEventListener('beforeunload',()=>{
  Object.values(popups).forEach(p=>{ try{ p.win.close(); }catch(e){} });
});
