/* ---------- Presets du synthé interne ---------- */
const SYNTHS={
  lead :{label:'Lead',  w1:'sawtooth', w2:'square',   det:7,  cut:2600, cutEnd:900,  q:1,   atk:0.012, rel:0.10, lvl:0.24},
  bass :{label:'Bass',  w1:'sawtooth', w2:'triangle', det:4,  cut:700,  cutEnd:220,  q:2,   atk:0.006, rel:0.12, lvl:0.30},
  pad  :{label:'Pad',   w1:'sawtooth', w2:'sawtooth', det:14, cut:1500, cutEnd:1100, q:0.7, atk:0.18,  rel:0.50, lvl:0.16},
  pluck:{label:'Pluck', w1:'square',   w2:'triangle', det:6,  cut:5200, cutEnd:300,  q:3,   atk:0.004, rel:0.18, lvl:0.26},
  keys :{label:'Keys',  w1:'triangle', w2:'sine',     det:3,  cut:3200, cutEnd:1600, q:0.8, atk:0.010, rel:0.22, lvl:0.30},
};
function setSynthPreset(k,preview=true){
  if(!SYNTHS[k]||!curIns()) return;
  curIns().preset=k;
  $$('#synthSel .pchip').forEach(b=>b.classList.toggle('sel',b.dataset.k===k));
  renderMixer();
  if(preview){ audio(); playSynth(ctx,chanOf(curIns()).g,ctx.currentTime+0.02,60,0.35,0.8,1,SYNTHS[k]); }
}
function renderSynthSel(){
  const box=$('#synthSel'); if(!box) return;
  box.innerHTML='';
  const lab=document.createElement('span'); lab.className='plab'; lab.textContent='SON';
  box.append(lab);
  Object.entries(SYNTHS).forEach(([k,p])=>{
    const b=document.createElement('button');
    b.className='pchip'+(curIns()&&k===curIns().preset?' sel':''); b.dataset.k=k;
    b.innerHTML=`<span class="sw" style="background:#3EC8FF"></span>${p.label}`;
    b.onclick=()=>setSynthPreset(k);
    box.append(b);
  });
}
