/* ---------- Sauvegarde / ouverture ---------- */
async function applyTiboBuffer(ab,label){
  if(typeof resetSaveTarget==='function') resetSaveTarget();
  const entries=unzipStore(ab);
  if(!entries['projet.json']) throw 'projet.json manquant';
  const data=JSON.parse(new TextDecoder().decode(entries['projet.json']));
  if(data.app!=='studio-un') throw 'format inconnu';
  applyProject(data);
  let nS=0;
  for(const t of tracks){
    if(t.kind==='sample'&&t.tid!=null&&entries[`samples/${t.tid}.wav`]){
      const u8=entries[`samples/${t.tid}.wav`];
      t.buffer=await ctx.decodeAudioData(u8.slice().buffer);
      bufReg[t.tid]=t.buffer; nS++;
      tidSeq=Math.max(tidSeq,t.tid);
    }
  }
  renderTracks(); renderMixer();
  setStatus(`Projet complet ouvert : ${label} — ${nS} sample(s) restaurés, rien à réimporter.`);
}
function buildProjectData(){
  /* attribuer un identifiant aux pistes sample qui n'en ont pas encore */
  tracks.forEach(t=>{
    if(t.kind==='sample'&&t.buffer&&t.tid==null){t.tid=++tidSeq;bufReg[t.tid]=t.buffer;}
  });
  return {app:'studio-un',version:7,name:projName,bpm,swing,loop:LOOP,autoTarget,noteFr,songMarks,accent:curAccent,extraPlugins:installedGallery,
    theme:curTheme,
    scale:{root:scaleRoot,key:scaleKey,snap:scaleSnap,grid:gridRes},
    automation,
    master:{gain:masterCh.gain},
    fx:{rev:{...fx.rev},dly:{...fx.dly}},
    insts:insts.map(s=>({name:s.name,preset:s.preset,arp:s.arp||'off',mute:s.mute,solo:s.solo,gain:s.gain,pan:s.pan,eq:s.eq,send:s.send,fxIns:s.fxIns})),
    tracks:tracks.map(t=>({name:t.name,kind:t.kind,mach:t.mach,mute:t.mute,solo:t.solo,gain:t.gain,pan:t.pan,eq:t.eq,send:t.send,tid:t.tid,fxIns:t.fxIns,spd:t.spd,pitch:t.pitch,keep:t.keep,off:t.off})),
    patterns:patterns.map(p=>({name:p.name,steps:p.steps,melo:p.melo,clips:p.clips}))};
}
function saveProject(){
  dlBlob(new Blob([JSON.stringify(buildProjectData(),null,1)],{type:'application/json'}),
         projSlug()+'.json');
  setStatus('Projet léger sauvegardé (.json, sans les données audio des samples).');
}
function saveProjectTibo(){
  const data=buildProjectData();
  const files=[{name:'projet.json',data:new TextEncoder().encode(JSON.stringify(data))}];
  let nS=0;
  for(const t of tracks){
    if(t.kind==='sample'&&t.buffer&&t.tid!=null){
      files.push({name:`samples/${t.tid}.wav`,data:new Uint8Array(encodeWavBytes(t.buffer))});
      nS++;
    }
  }
  return writeProjectFile(zipStore(files),' (réglages + '+nS+' sample(s) embarqués)');
}
async function saveProjectTiboAs(){ resetSaveTarget(); return saveProjectTibo(); }
$('#fileProj').addEventListener('change',async e=>{
  const f=e.target.files[0]; if(!f) return;
  try{
    if(/\.(tibo|zip)$/i.test(f.name)){
      audio();
      await applyTiboBuffer(await f.arrayBuffer(),f.name);
    } else {
      const data=JSON.parse(await f.text());
      if(data.app!=='studio-un') throw 0;
      applyProject(data);
      setStatus(`Projet ouvert : ${f.name}. Réimportez vos samples si besoin (ou utilisez le format .tibo).`);
    }
  }catch(err){ setStatus('Ouverture impossible : fichier non reconnu. '+(typeof err==='string'?err:'')); }
  e.target.value='';
});
function applyProject(data){
  if(typeof resetSaveTarget==='function') resetSaveTarget();
  if(Array.isArray(data.extraPlugins)&&typeof installGalleryPlugin==='function'){
    installedGallery=[];
    data.extraPlugins.forEach(id=>installGalleryPlugin(id,true));
  }
  stop();
  bpm=data.bpm||120; $('#bpm').value=bpm;
  tracks=data.tracks.map(t=>normCh({mute:false,solo:false,gain:0.9,pan:0,...t,buffer:null,_ch:null}));
  if(data.version>=3){
    patterns=data.patterns.map(p=>({
      name:p.name,
      steps:p.steps,
      melo:p.melo||[p.notes||[]],
      clips:(p.clips&&p.clips.length===PLSLOTS)?p.clips:Array(PLSLOTS).fill(false)
    }));
  } else {
    const steps=data.tracks.map(t=>t.steps||Array(NSTEPS).fill(0));
    patterns=[{name:'PAT 1',steps,melo:[data.notes||[]],clips:Array(PLSLOTS).fill(false)}];
    patterns[0].clips[0]=true;
  }
  if(data.master) masterCh.gain=data.master.gain;
  if(data.version>=7&&data.insts){
    insts=data.insts.map(s=>normCh({mute:false,solo:false,gain:0.9,pan:0,preset:'lead',...s,_ch:null}));
  } else {
    const s=data.synth||{};
    insts=[normCh({name:'Lead 1',preset:data.synthPreset||'lead',
      gain:(s.gain!=null?s.gain:0.9),pan:s.pan||0,mute:!!s.mute,solo:!!s.solo,eq:s.eq,send:s.send})];
  }
  curInst=0;
  autoTarget=Math.min(Math.max(0,data.autoTarget||0),insts.length-1);
  patterns.forEach(p=>{p.melo=p.melo||[];while(p.melo.length<insts.length)p.melo.push([]);p.melo.length=insts.length;});
  if(data.fx){Object.assign(fx.rev,data.fx.rev||{});Object.assign(fx.dly,data.fx.dly||{});applyFxLive();applyRevSize();}
  Object.keys(automation).forEach(k=>automation[k]=(data.automation&&data.automation[k])||[]);
  swing=Math.min(60,Math.max(0,data.swing||0)); $('#swing').value=swing;
  if([16,32,64].includes(data.loop)) LOOP=data.loop;
  const h=$('#prTitle'); if(h) h.textContent='Piano roll — '+(LOOP/16)+' mesure'+(LOOP>16?'s':'');
  curAccent=(typeof data.accent==='string'&&/^#[0-9a-fA-F]{6}$/.test(data.accent))?data.accent:null;
  if(data.theme) applyTheme(data.theme); else applyAccent();
  noteFr=!!data.noteFr;
  projName=(data.name||'Mon morceau').slice(0,24); renderProjName();
  songMarks=(data.songMarks||[]).slice(0,PLSLOTS).map(x=>(''+(x||'')).slice(0,10));
  while(songMarks.length<PLSLOTS) songMarks.push('');
  $$('.menu [data-notation]').forEach(b=>{b.querySelector('.kbd').textContent=((b.dataset.notation==='fr')===noteFr?'✓':'');});
  if(data.scale){
    scaleRoot=data.scale.root||0;
    if(SCALES[data.scale.key]) scaleKey=data.scale.key;
    scaleSnap=!!data.scale.snap;
    const G=[1,0.5,1/3,0.25].find(g=>Math.abs(g-(data.scale.grid||1))<1e-6);
    if(G) gridRes=G;
  }
  selectPattern(0); selectInst(0); buildPianoRoll(); renderMixer(); renderAuto(); clearUndo();
}
