/* ---------- Enregistrement de fichiers : natif (Tauri) ou navigateur ---------- */
const isTauri=typeof window!=='undefined'&&!!window.__TAURI__;
async function dlBlob(blob,name){
  if(isTauri&&window.__TAURI__.dialog&&window.__TAURI__.fs){
    try{
      const ext=name.split('.').pop();
      const path=await window.__TAURI__.dialog.save({
        defaultPath:name,
        filters:[{name:ext.toUpperCase(),extensions:[ext]}],
      });
      if(!path){ setStatus('Enregistrement annulé.'); return; }
      const bytes=new Uint8Array(await blob.arrayBuffer());
      await window.__TAURI__.fs.writeFile(path,bytes);
      setStatus('Fichier enregistré : '+path);
      return;
    }catch(e){ /* repli navigateur ci-dessous */ }
  }
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download=name;
  a.click();
}
