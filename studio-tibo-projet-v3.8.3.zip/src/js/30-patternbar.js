/* ---------- Barre de patterns (séquenceur + piano roll) ---------- */
function renderPatBars(){
  $$('[data-patbar]').forEach(bar=>{
    bar.innerHTML='';
    const lab=document.createElement('span'); lab.className='plab'; lab.textContent='PATTERNS';
    bar.append(lab);
    patterns.forEach((p,i)=>{
      const b=document.createElement('button');
      b.className='pchip'+(i===curPat?' sel':'');
      if(i===curPat) b.style.color=patColor(i);
      b.innerHTML=`<span class="sw" style="background:${patColor(i)}"></span>${p.name}`;
      if(i===pendingPat) b.classList.add('queued');
      b.onclick=()=>{
        if(playing&&mode==='pat'&&i!==curPat){
          pendingPat=(pendingPat===i)?null:i;
          renderPatBars();
          setStatus(pendingPat==null
            ?'File d\'attente annulée.'
            :'« '+patterns[i].name+' » en file — bascule au début de la prochaine boucle (re-cliquez pour annuler).');
        } else selectPattern(i);
      };
      b.ondblclick=()=>inlineRename(b,()=>p.name,v=>p.name=v,
        ()=>{renderPatBars();renderPlaylist();},14);
      bar.append(b);
    });
    const add=document.createElement('button');
    add.className='pchip tool'; add.textContent='＋ Nouveau';
    add.onclick=()=>{
      pushUndo();
      patterns.push(newPattern('PAT '+(patterns.length+1)));
      selectPattern(patterns.length-1);
      setStatus('Pattern créé. Il est vide : posez vos pas et vos notes, puis placez-le dans la Playlist.');
    };
    const dup=document.createElement('button');
    dup.className='pchip tool'; dup.textContent='⧉ Dupliquer';
    dup.onclick=()=>{
      pushUndo();
      const src=patterns[curPat];
      patterns.push({name:(src.name+' copie').slice(0,14),
        steps:src.steps.map(r=>[...r]),
        melo:src.melo.map(a=>a.map(n=>({...n}))),
        clips:Array(PLSLOTS).fill(false)});
      selectPattern(patterns.length-1);
      setStatus('Pattern dupliqué — modifiez la copie pour créer une variation.');
    };
    bar.append(add,dup);
    if(patterns.length>1){
      const del=document.createElement('button');
      del.className='pchip tool'; del.textContent='✕ Supprimer';
      del.onclick=()=>{
        pushUndo();
        patterns.splice(curPat,1);
        selectPattern(Math.max(0,curPat-1));
        setStatus('Pattern supprimé.');
      };
      bar.append(del);
    }
  });
}
