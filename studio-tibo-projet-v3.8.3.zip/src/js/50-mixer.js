/* ---------- Mixeur ---------- */
const gainToDb=g=>g<=0.001?'-∞':(20*Math.log10(g)).toFixed(1);
/* Potentiomètre rotatif : glisser verticalement, double-clic = valeur par défaut */
function mkKnob(lbl,get,set,min,max,fmt,def=0,commit){
  const w=document.createElement('div'); w.className='knb';
  const k=document.createElement('div'); k.className='k';
  const i=document.createElement('i'); k.append(i);
  const s=document.createElement('span'); s.textContent=lbl;
  const upd=()=>{
    const f=(get()-min)/(max-min);
    i.style.transform=`rotate(${-135+f*270}deg)`;
    k.title=lbl+' : '+fmt(get());
  };
  let st=null;
  k.addEventListener('pointerdown',e=>{st={y:e.clientY,v:get()};k.setPointerCapture(e.pointerId);e.preventDefault();});
  k.addEventListener('pointermove',e=>{
    if(!st) return;
    const nv=Math.min(max,Math.max(min,st.v+(st.y-e.clientY)*(max-min)/120));
    set(+nv.toFixed(2)); upd();
  });
  k.addEventListener('pointerup',()=>{if(st){st=null;commit&&commit();}});
  k.addEventListener('dblclick',()=>{set(def);upd();commit&&commit();});
  w.append(k,s); upd();
  return w;
}
function makeFxStrip(title,type,build){
  const s=document.createElement('div'); s.className='strip fxs';
  const nm=document.createElement('div'); nm.className='snm'; nm.textContent=title;
  const tp=document.createElement('div'); tp.className='stype'; tp.textContent=type;
  s.append(nm,tp);
  build(s);
  return s;
}
let stripRefs=[];
let insDrag=null;   /* {obj,si} pendant un glisser d'insert */
function makeStrip(obj,opts){
  const s=document.createElement('div');
  s.className='strip'+(opts.master?' master':'')+(opts.synth?' synth':'');
  const nm=document.createElement('div'); nm.className='snm'; nm.textContent=obj.name;
  const tp=document.createElement('div'); tp.className='stype'; tp.textContent=opts.type;
  s.append(nm,tp);
  if(!opts.master){
    const pan=document.createElement('input');
    pan.type='range'; pan.className='pan'; pan.min=-100; pan.max=100; pan.value=(obj.pan||0)*100;
    const pl=document.createElement('div'); pl.className='panlbl';
    const plbl=v=>v===0?'C':(v<0?'G '+Math.abs(v):'D '+v);
    pl.textContent=plbl(Math.round((obj.pan||0)*100));
    pan.oninput=()=>{obj.pan=pan.value/100;pl.textContent=plbl(+pan.value);
      if(obj._ch&&obj._ch.p.pan)obj._ch.p.pan.value=obj.pan;};
    pan.ondblclick=()=>{pan.value=0;pan.oninput();};
    s.append(pan,pl);
    const eqRow=document.createElement('div'); eqRow.className='row';
    eqRow.append(
      mkKnob('LOW', ()=>obj.eq.lo, v=>{obj.eq.lo=v; if(obj._ch)obj._ch.lo.gain.value=v;}, -12,12, v=>v.toFixed(1)+' dB'),
      mkKnob('MID', ()=>obj.eq.mid,v=>{obj.eq.mid=v;if(obj._ch)obj._ch.mid.gain.value=v;},-12,12, v=>v.toFixed(1)+' dB'),
      mkKnob('HIGH',()=>obj.eq.hi, v=>{obj.eq.hi=v; if(obj._ch)obj._ch.hi.gain.value=v;}, -12,12, v=>v.toFixed(1)+' dB'));
    const sdRow=document.createElement('div'); sdRow.className='row';
    sdRow.append(
      mkKnob('REV',()=>obj.send.rev,v=>{obj.send.rev=v;if(obj._ch)obj._ch.sR.gain.value=v;if(obj===insts[autoTarget])autoWrite('srev',v);},0,1,v=>Math.round(v*100)+' %'),
      mkKnob('DLY',()=>obj.send.dly,v=>{obj.send.dly=v;if(obj._ch)obj._ch.sD.gain.value=v;if(obj===insts[autoTarget])autoWrite('sdly',v);},0,1,v=>Math.round(v*100)+' %'));
    s.append(eqRow,sdRow);
    const insCol=document.createElement('div'); insCol.className='inscol';
    [0,1,2,3].forEach(si=>{
      const b=document.createElement('button');
      const cur=obj.fxIns&&obj.fxIns[si];
      b.className='insbtn'+(cur?' on':'')+(cur&&cur.byp?' byp':'');
      b.textContent=cur?((PLUGINS[cur.id]&&PLUGINS[cur.id].name)||cur.id+' ?'):'＋ FX';
      b.title='Insert '+(si+1)+(cur?' — clic droit : bypass · glissez pour réordonner la chaîne':'');
      b.draggable=!!cur;
      b.ondragstart=()=>{ insDrag={obj,si}; };
      b.ondragend=()=>{ insDrag=null; };
      b.ondragover=e=>{ if(insDrag&&insDrag.obj===obj&&insDrag.si!==si){ e.preventDefault(); b.classList.add('dropfx'); } };
      b.ondragleave=()=>b.classList.remove('dropfx');
      b.ondrop=e=>{
        if(!insDrag||insDrag.obj!==obj) return;
        e.preventDefault();
        pushUndo();
        const it=obj.fxIns.splice(insDrag.si,1)[0];
        obj.fxIns.splice(si,0,it);
        insDrag=null;
        rebuildChan(obj); renderMixer();
        setStatus('Chaîne d\'effets réordonnée — l\'ordre des inserts change le son (drive avant ou après le filtre, etc.).');
      };
      b.onclick=()=>openInsEditor(obj,si);
      b.oncontextmenu=e=>{
        e.preventDefault();
        if(!cur) return;
        pushUndo(); cur.byp=!cur.byp;
        rebuildChan(obj); renderMixer();
      };
      insCol.append(b);
    });
    s.append(insCol);
  }
  const mz=document.createElement('div'); mz.className='meterzone';
  const vu=document.createElement('div'); vu.className='vu';
  vu.innerHTML='<i></i><div class="pk"></div>';
  const fader=document.createElement('div'); fader.className='fader';
  const thumb=document.createElement('div'); thumb.className='thumb';
  fader.append(thumb);
  mz.append(vu,fader); s.append(mz);
  const db=document.createElement('div'); db.className='db';
  s.append(db);
  const GMAX=1.25;
  const setThumb=()=>{
    const h=fader.clientHeight||158;
    thumb.style.top=Math.round((1-Math.min(obj.gain,GMAX)/GMAX)*(h-16))+'px';
    db.textContent=gainToDb(obj.gain)+' dB';
  };
  let fd=null;
  const mv=e=>{
    if(!fd) return;
    const r=fader.getBoundingClientRect();
    const f=1-Math.min(1,Math.max(0,(e.clientY-r.top-8)/(r.height-16)));
    obj.gain=+(f*GMAX).toFixed(3);
    if(opts.master) autoWrite('master',f);   /* map v→v×1.25 et GMAX=1.25 : f est la valeur exacte */
    if(obj._ch) obj._ch.g.gain.value=obj.gain;
    if(opts.master&&masterIn) masterIn.gain.value=obj.gain;
    setThumb();
  };
  fader.addEventListener('pointerdown',e=>{fd=true;fader.setPointerCapture(e.pointerId);mv(e);});
  fader.addEventListener('pointermove',mv);
  fader.addEventListener('pointerup',()=>fd=null);
  fader.addEventListener('dblclick',()=>{obj.gain=1;
    if(obj._ch)obj._ch.g.gain.value=1; if(opts.master&&masterIn)masterIn.gain.value=1; setThumb();});
  if(!opts.master){
    const row=document.createElement('div'); row.className='row';
    const m=document.createElement('button');
    m.className='mini'+(obj.mute?' on':''); m.textContent='M';
    m.onclick=()=>{obj.mute=!obj.mute;m.classList.toggle('on',obj.mute);renderTracks();};
    const so=document.createElement('button');
    so.className='mini'+(obj.solo?' on solo':''); so.textContent='S';
    so.onclick=()=>{obj.solo=!obj.solo;so.classList.toggle('on',obj.solo);so.classList.toggle('solo',obj.solo);renderTracks();};
    row.append(m,so); s.append(row);
  }
  requestAnimationFrame(setThumb);
  stripRefs.push({obj,fill:vu.querySelector('i'),pk:vu.querySelector('.pk'),master:opts.master,peak:0});
  return s;
}
function renderMixer(){
  const rack=$('#mixRack'); rack.innerHTML=''; stripRefs=[];
  rack.append(makeStrip(masterCh,{master:true,type:'sortie'}));
  rack.append(makeFxStrip('Reverb','retour d\'effet',s=>{
    const r=document.createElement('div'); r.className='row';
    r.append(
      mkKnob('SIZE',()=>fx.rev.size,v=>{fx.rev.size=v;},0.6,4,v=>v.toFixed(1)+' s',2.2,applyRevSize),
      mkKnob('RET',()=>fx.rev.ret,v=>{fx.rev.ret=v;applyFxLive();},0,1.25,v=>Math.round(v*100)+' %',0.9));
    s.append(r);
    const h=document.createElement('div'); h.className='db';
    h.textContent='alimenté par REV'; s.append(h);
  }));
  rack.append(makeFxStrip('Delay','retour d\'effet',s=>{
    const r=document.createElement('div'); r.className='row';
    r.append(
      mkKnob('FB',()=>fx.dly.fb,v=>{fx.dly.fb=v;applyFxLive();},0,0.85,v=>Math.round(v*100)+' %',0.38),
      mkKnob('RET',()=>fx.dly.ret,v=>{fx.dly.ret=v;applyFxLive();},0,1.25,v=>Math.round(v*100)+' %',0.85));
    s.append(r);
    const r2=document.createElement('div'); r2.className='row';
    [[2,'1/8'],[3,'3/16'],[4,'1/4']].forEach(([d,l])=>{
      const b=document.createElement('button');
      b.className='divbtn'+(fx.dly.div===d?' on':''); b.textContent=l; b.title='Temps du delay';
      b.onclick=()=>{fx.dly.div=d;applyFxLive();
        r2.querySelectorAll('.divbtn').forEach(x=>x.classList.toggle('on',x===b));};
      r2.append(b);
    });
    s.append(r2);
    const h=document.createElement('div'); h.className='db';
    h.textContent='alimenté par DLY'; s.append(h);
  }));
  insts.forEach(ins=>rack.append(makeStrip(ins,{synth:true,type:'instr · '+(SYNTHS[ins.preset]||SYNTHS.lead).label})));
  tracks.forEach(tr=>rack.append(makeStrip(tr,{type:tr.kind==='sample'?'sample':tr.kind==='mach'?MACHINES[tr.mach.kit].tag:'drum'})));
}
const buf512=new Float32Array(512);
const specEl=$('#spec'), specG=specEl?specEl.getContext('2d'):null, fdat=new Uint8Array(256);
function levelOf(an){
  if(!an) return 0;
  an.getFloatTimeDomainData(buf512);
  let p=0; for(let i=0;i<buf512.length;i++){const a=Math.abs(buf512[i]); if(a>p)p=a;}
  return Math.min(1,p);
}
let clipUntil=0; const tdat=new Uint8Array(512);
function meters(){
  if(ctx){
    for(const r of stripRefs){
      const an=r.master?masterAn:(r.obj._ch&&r.obj._ch.ctx===ctx?r.obj._ch.an:null);
      const lv=playing?levelOf(an):0;
      r.peak=Math.max(lv,r.peak*0.96);
      r.fill.style.height=(lv*100)+'%';
      r.pk.style.bottom=(r.peak*100)+'%';
    }
    if(masterAn){
      masterAn.getByteTimeDomainData(tdat);
      let pk=0;
      for(let i=0;i<tdat.length;i++){ const a=Math.abs(tdat[i]-128)/128; if(a>pk) pk=a; }
      if(pk>0.985) clipUntil=performance.now()+1500;
      const led=$('#clipLed');
      if(led) led.classList.toggle('on',performance.now()<clipUntil);
    }
    const m=playing?levelOf(masterAn):0;
    $('#mvuL').style.height=(m*100)+'%';
    $('#mvuR').style.height=(Math.max(0,m*100-4))+'%';
    if(specG&&masterAn){
      masterAn.getByteFrequencyData(fdat);
      specG.clearRect(0,0,420,52);
      for(let i=0;i<84;i++){
        const v=(playing?fdat[i*3]:0)/255, h=Math.max(1,v*50);
        specG.fillStyle=`hsl(${310-i*2.8} 85% ${38+v*32}%)`;
        specG.fillRect(i*5,52-h,4,h);
      }
    }
  }
  requestAnimationFrame(meters);
}
requestAnimationFrame(meters);
