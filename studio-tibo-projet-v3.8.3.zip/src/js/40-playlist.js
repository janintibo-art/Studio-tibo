/* ---------- Playlist ---------- */
/* Déplacer une section (colonne) : rotation des clips + des points d'automation.
   Maj au dépôt : duplication (la colonne source écrase la destination). */
function moveCol(s,d,copy){
  if(s===d&&!copy) return;
  pushUndo();
  if(copy){
    patterns.forEach(p=>{ p.clips[d]=p.clips[s]; });
    songMarks[d]=songMarks[s];
    for(const k in automation){
      const pts=automation[k];
      for(let i=pts.length-1;i>=0;i--) if(pts[i].x>=d&&pts[i].x<d+1) pts.splice(i,1);
      pts.filter(pt=>pt.x>=s&&pt.x<s+1).map(pt=>({x:+(pt.x+(d-s)).toFixed(2),v:pt.v}))
         .forEach(np=>pts.push(np));
      pts.sort((a,b)=>a.x-b.x);
    }
    setStatus('Section '+(s+1)+' dupliquée sur la colonne '+(d+1)+' (clips et automation).');
  } else {
    patterns.forEach(p=>{ const c=p.clips.splice(s,1)[0]; p.clips.splice(d,0,c); });
    const mk=songMarks.splice(s,1)[0]; songMarks.splice(d,0,mk);
    for(const k in automation){
      for(const pt of automation[k]){
        if(pt.x>=s&&pt.x<s+1) pt.x=+(pt.x+(d-s)).toFixed(2);
        else if(s<d&&pt.x>=s+1&&pt.x<d+1) pt.x=+(pt.x-1).toFixed(2);
        else if(d<s&&pt.x>=d&&pt.x<s) pt.x=+(pt.x+1).toFixed(2);
      }
      automation[k].sort((a,b)=>a.x-b.x);
    }
    setStatus('Section déplacée : colonne '+(s+1)+' → '+(d+1)+' — clips et automation suivent.');
  }
  renderPlaylist(); renderAuto(); updateStats();
}
let dragCol=null;
let loopA=null, loopB=null;          /* boucle de section (mode SONG) */
function setLoopRegion(s){
  if(loopA==null||loopB!=null){ loopA=s; loopB=null;
    setStatus('Borne A posée : section '+(s+1)+' — cliquez une autre colonne pour fermer la boucle (clic droit : annuler).');
  } else {
    loopB=Math.max(loopA,s); loopA=Math.min(loopA,s);
    setStatus('Boucle de section : '+(loopA+1)+' → '+(loopB+1)+' — la lecture SONG tourne dessus (l\'export reste le morceau entier).');
  }
  renderPlaylist();
}
function clearLoopRegion(){
  if(loopA==null&&loopB==null) return;
  loopA=loopB=null;
  renderPlaylist();
  setStatus('Boucle de section libérée — le morceau joue en entier.');
}
function renderPlaylist(){
  const wrap=$('#plWrap'); wrap.innerHTML='';
  const head=document.createElement('div'); head.className='pl-headrow';
  for(let s=0;s<PLSLOTS;s++){
    if(s>0&&s%4===0){const g=document.createElement('div');g.className='gap';head.append(g);}
    const n=document.createElement('div'); n.className='num';
    n.textContent=songMarks[s]||((s*2+1)+'–'+(s*2+2));
    if(songMarks[s]) n.classList.add('named');
    n.ondblclick=()=>inlineRename(n,()=>songMarks[s]||'',v=>songMarks[s]=v.slice(0,10),()=>renderPlaylist(),10);
    n.draggable=true;
    n.title='Mesures '+(s*2+1)+'–'+(s*2+2)+' · clic : boucle de section (A puis B, clic droit : libérer) · double-clic : nommer · glissez : déplacer (Maj : dupliquer)';
    n.ondragstart=e=>{ dragCol=s; n.classList.add('dragsrc'); try{e.dataTransfer.setData('text/plain',''+s);}catch(err){} };
    n.ondragend=()=>{ dragCol=null; $$('.pl-headrow .num').forEach(x=>x.classList.remove('dragsrc','dropcol')); };
    n.ondragover=e=>{ if(dragCol!=null){ e.preventDefault(); e.stopPropagation(); n.classList.add('dropcol'); } };
    n.ondragleave=()=>n.classList.remove('dropcol');
    n.ondrop=e=>{ if(dragCol==null) return; e.preventDefault(); e.stopPropagation(); moveCol(dragCol,s,e.shiftKey); dragCol=null; };
    n.onclick=()=>setLoopRegion(s);
    n.oncontextmenu=e=>{ e.preventDefault(); clearLoopRegion(); };
    if(loopA!=null&&(loopB!=null?(s>=loopA&&s<=loopB):s===loopA)) n.classList.add('inloop');
    head.append(n);
  }
  wrap.append(head);
  patterns.forEach((p,pi)=>{
    const row=document.createElement('div'); row.className='pl-row';
    const name=document.createElement('button');
    name.className='pl-name'+(pi===curPat?' sel':'');
    if(pi===curPat) name.style.color=patColor(pi);
    name.innerHTML=`<span class="sw" style="background:${patColor(pi)}"></span>${p.name}`;
    name.onclick=()=>selectPattern(pi);
    name.ondblclick=()=>inlineRename(name,()=>p.name,v=>p.name=v,
      ()=>{renderPatBars();renderPlaylist();},14);
    row.append(name);
    p.clips.forEach((on,si)=>{
      if(si>0&&si%4===0){const g=document.createElement('div');g.className='gap';row.append(g);}
      const slot=document.createElement('div');
      slot.className='pl-slot'+(on?' on':''); slot.dataset.slot=si;
      const clip=document.createElement('div'); clip.className='clip';
      clip.style.background=`linear-gradient(180deg, ${patColor(pi)}, ${patColor(pi)}88)`;
      slot.append(clip);
      slot.onclick=()=>{
        pushUndo();
        p.clips[si]=!p.clips[si];
        slot.classList.toggle('on',p.clips[si]);
        updateStats(); renderAuto();
      };
      row.append(slot);
    });
    wrap.append(row);
  });
}
