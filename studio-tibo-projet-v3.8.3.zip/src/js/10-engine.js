/* ---------- Contexte audio + canaux ---------- */
let ctx=null, masterIn=null, masterAn=null, liveNoise=null, liveFx=null;
function audio(){
  if(!ctx){
    ctx=new (window.AudioContext||window.webkitAudioContext)();
    masterIn=ctx.createGain(); masterIn.gain.value=masterCh.gain;
    const comp=ctx.createDynamicsCompressor();
    comp.threshold.value=-8; comp.ratio.value=4;
    masterAn=ctx.createAnalyser(); masterAn.fftSize=512;
    const lim=ctx.createDynamicsCompressor();   /* limiteur brickwall anti-saturation */
    lim.threshold.value=-1; lim.ratio.value=20; lim.knee.value=0;
    lim.attack.value=0.002; lim.release.value=0.08;
    masterIn.connect(comp); comp.connect(lim); lim.connect(masterAn); masterAn.connect(ctx.destination);
    liveNoise=mkNoise(ctx);
    liveFx=mkFxBuses(ctx,masterIn);
  }
  if(ctx.state==='suspended') ctx.resume();
  return ctx;
}
function mkNoise(c){
  const b=c.createBuffer(1,c.sampleRate*1.2,c.sampleRate), d=b.getChannelData(0);
  for(let i=0;i<d.length;i++) d[i]=Math.random()*2-1;
  return b;
}
/* Réponse impulsionnelle stéréo pour la reverb (bruit à décroissance exponentielle) */
function makeIR(c,dur,decay){
  const len=Math.max(1,Math.floor(c.sampleRate*dur));
  const b=c.createBuffer(2,len,c.sampleRate);
  for(let ch=0;ch<2;ch++){
    const d=b.getChannelData(ch);
    for(let i=0;i<len;i++) d[i]=(Math.random()*2-1)*Math.pow(1-i/len,decay);
  }
  return b;
}
/* Bus d'effets partagés : reverb à convolution + delay synchronisé avec feedback */
function mkFxBuses(c,out){
  const revIn=c.createGain();
  const conv=c.createConvolver(); conv.buffer=makeIR(c,fx.rev.size,2.6);
  const revRet=c.createGain(); revRet.gain.value=fx.rev.ret;
  revIn.connect(conv); conv.connect(revRet); revRet.connect(out);
  const dlyIn=c.createGain();
  const dly=c.createDelay(2.0); dly.delayTime.value=fx.dly.div*(60/bpm/4);
  const df=c.createBiquadFilter(); df.type='lowpass'; df.frequency.value=3200;
  const fb=c.createGain(); fb.gain.value=fx.dly.fb;
  const dlyRet=c.createGain(); dlyRet.gain.value=fx.dly.ret;
  dlyIn.connect(dly); dly.connect(df); df.connect(fb); fb.connect(dly);
  df.connect(dlyRet); dlyRet.connect(out);
  return {revIn,conv,revRet,dlyIn,dly,fb,dlyRet};
}
function applyFxLive(){
  if(!liveFx) return;
  liveFx.revRet.gain.value=fx.rev.ret;
  liveFx.dlyRet.gain.value=fx.dly.ret;
  liveFx.fb.gain.value=fx.dly.fb;
  liveFx.dly.delayTime.value=fx.dly.div*spStep();
}
function applyRevSize(){
  if(liveFx&&ctx) liveFx.conv.buffer=makeIR(ctx,fx.rev.size,2.6);
}
function chanOf(obj){
  if(!obj._ch||obj._ch.ctx!==ctx){
    const g=ctx.createGain();
    const lo=ctx.createBiquadFilter(); lo.type='lowshelf';  lo.frequency.value=200;
    const mid=ctx.createBiquadFilter(); mid.type='peaking'; mid.frequency.value=1000; mid.Q.value=0.9;
    const hi=ctx.createBiquadFilter(); hi.type='highshelf'; hi.frequency.value=4200;
    const p=(ctx.createStereoPanner?ctx.createStereoPanner():ctx.createGain());
    const an=ctx.createAnalyser(); an.fftSize=512;
    const sR=ctx.createGain(), sD=ctx.createGain();
    g.connect(lo); lo.connect(mid); mid.connect(hi);
    const built=buildInserts(ctx,hi,obj.fxIns);
    built.last.connect(p); p.connect(an); an.connect(masterIn);
    built.last.connect(sR); sR.connect(liveFx.revIn);
    built.last.connect(sD); sD.connect(liveFx.dlyIn);
    obj._ch={ctx,g,p,an,lo,mid,hi,sR,sD,inserts:built.inserts};
  }
  const c=obj._ch;
  c.g.gain.value=obj.gain;
  if(c.p.pan) c.p.pan.value=obj.pan||0;
  c.lo.gain.value=obj.eq.lo; c.mid.gain.value=obj.eq.mid; c.hi.gain.value=obj.eq.hi;
  const autoSends=playing&&mode==='song'&&obj===insts[autoTarget];
  if(!(autoSends&&autoHas('srev'))) c.sR.gain.value=obj.send.rev;
  if(!(autoSends&&autoHas('sdly'))) c.sD.gain.value=obj.send.dly;
  return c;
}
