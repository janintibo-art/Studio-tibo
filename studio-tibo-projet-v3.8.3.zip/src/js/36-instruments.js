/* ---------- Instruments (pistes de synthé multiples) ---------- */
function addInst(name,preset='lead'){
  const ins=normCh({name:name.slice(0,16),preset,mute:false,solo:false,gain:0.9,pan:0});
  insts.push(ins);
  patterns.forEach(p=>p.melo.push([]));
  return ins;
}
function selectInst(i){
  curInst=Math.max(0,Math.min(insts.length-1,i));
  notes=patterns[curPat].melo[curInst]||(patterns[curPat].melo[curInst]=[]);
  if(typeof clearSel==='function') clearSel(false);
  renderInstBar(); renderSynthSel(); renderNotes();
}
function renderInstBar(){
  const bar=$('#instBar'); if(!bar) return;
  bar.innerHTML='';
  const lab=document.createElement('span'); lab.className='plab'; lab.textContent='INSTRUMENTS';
  bar.append(lab);
  insts.forEach((ins,i)=>{
    const b=document.createElement('button');
    b.className='pchip'+(i===curInst?' sel':'');
    if(i===curInst) b.style.color=instColor(i);
    b.innerHTML=`<span class="sw" style="background:${instColor(i)}"></span>${ins.name}`;
    b.onclick=()=>selectInst(i);
    b.ondblclick=()=>inlineRename(b,()=>ins.name,v=>ins.name=v,
      ()=>{renderInstBar();renderMixer();},16);
    bar.append(b);
  });
  const ARP_MODES=[['off','ARP OFF'],['up','ARP ↑'],['down','ARP ↓'],['alea','ARP ⚄']];
  const arp=document.createElement('button');
  const cur=curIns().arp||'off';
  arp.className='pchip'+(cur!=='off'?' sel':'');
  if(cur!=='off') arp.style.color='#B08CFF';
  arp.innerHTML='<span class="sw" style="background:#B08CFF"></span>'+ARP_MODES.find(m=>m[0]===cur)[1];
  arp.title='Arpégiateur de '+curIns().name+' : les accords et notes tenues sont égrenés en doubles-croches';
  arp.onclick=()=>{
    pushUndo();
    const i=ARP_MODES.findIndex(m=>m[0]===(curIns().arp||'off'));
    curIns().arp=ARP_MODES[(i+1)%ARP_MODES.length][0];
    renderInstBar();
  };
  bar.append(arp);
  const add=document.createElement('button');
  add.className='pchip tool'; add.textContent='＋ Nouveau';
  add.onclick=()=>{
    pushUndo();
    addInst('Synth '+(insts.length+1));
    selectInst(insts.length-1);
    renderMixer();
    setStatus('Instrument créé — choisissez son preset (SON) et posez ses notes : chaque pattern lui réserve un piano roll.');
  };
  bar.append(add);
  const dup=document.createElement('button');
  dup.className='pchip tool'; dup.textContent='⧉ Dupliquer';
  dup.title='Copie '+curIns().name+' : preset, EQ, envois, effets, arpégiateur ET ses notes dans tous les patterns';
  dup.onclick=()=>{
    pushUndo();
    const src=curIns(), srcIdx=curInst;
    const cl=normCh(JSON.parse(JSON.stringify({
      name:(src.name+' 2').slice(0,16),preset:src.preset,arp:src.arp||'off',
      mute:false,solo:false,gain:src.gain,pan:src.pan,eq:src.eq,send:src.send,fxIns:src.fxIns
    })));
    insts.push(cl);
    patterns.forEach(p=>p.melo.push((p.melo[srcIdx]||[]).map(n=>({...n}))));
    selectInst(insts.length-1);
    renderMixer();
    setStatus('Instrument dupliqué : '+cl.name+' — mêmes réglages, mêmes notes, prêt à varier.');
  };
  bar.append(dup);
  if(insts.length>1){
    const del=document.createElement('button');
    del.className='pchip tool'; del.textContent='✕ Supprimer';
    del.onclick=()=>{
      pushUndo();
      insts.splice(curInst,1);
      patterns.forEach(p=>p.melo.splice(curInst,1));
      autoTarget=Math.min(autoTarget,insts.length-1);
      selectInst(Math.max(0,curInst-1));
      renderMixer();
      setStatus('Instrument supprimé (avec ses notes dans tous les patterns).');
    };
    bar.append(del);
  }
}
