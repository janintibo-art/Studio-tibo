/* ---------- Gammes : éclairage du piano roll + aimant ---------- */
const SCALES={
  maj:  {label:'Majeure',          iv:[0,2,4,5,7,9,11]},
  min:  {label:'Mineure',          iv:[0,2,3,5,7,8,10]},
  hmin: {label:'Min. harmonique',  iv:[0,2,3,5,7,8,11]},
  dor:  {label:'Dorien',           iv:[0,2,3,5,7,9,10]},
  pmaj: {label:'Penta majeure',    iv:[0,2,4,7,9]},
  pmin: {label:'Penta mineure',    iv:[0,3,5,7,10]},
  blues:{label:'Blues',            iv:[0,3,5,6,7,10]},
};
let scaleRoot=0, scaleKey='min', scaleSnap=false;
const inScale=p=>SCALES[scaleKey].iv.includes(((p-scaleRoot)%12+12)%12);
function snapToScale(p){
  if(inScale(p)) return p;
  for(let d=1;d<7;d++){
    if(p-d>=BOTNOTE&&inScale(p-d)) return p-d;
    if(p+d<=TOPNOTE&&inScale(p+d)) return p+d;
  }
  return p;
}
const maybeSnap=p=>scaleSnap?snapToScale(p):p;

/* Fond de grille : lignes + teinte des rangées selon la gamme (cycle de 12) */
function setGridBackground(grid){
  const stops=[];
  for(let r=0;r<12;r++){
    const cls=((pitchOf(r)-scaleRoot)%12+12)%12;
    const c=cls===0?'#17263D':(inScale(pitchOf(r))?'#121A28':'#0C1018');
    stops.push(`${c} ${r*ROWH}px, ${c} ${(r+1)*ROWH}px`);
  }
  grid.style.background=`
    repeating-linear-gradient(90deg, transparent 0, transparent ${COLW*4-1}px, #2A3140 ${COLW*4-1}px, #2A3140 ${COLW*4}px),
    repeating-linear-gradient(90deg, transparent 0, transparent ${COLW-1}px, #1B2029 ${COLW-1}px, #1B2029 ${COLW}px),
    repeating-linear-gradient(180deg, transparent 0, transparent ${ROWH-1}px, #1B2029 ${ROWH-1}px, #1B2029 ${ROWH}px),
    repeating-linear-gradient(180deg, ${stops.join(', ')})`;
}
function refreshKeyScale(){
  $$('#prKeys .pr-key').forEach((k,r)=>{
    const m=pitchOf(r), cls=((m-scaleRoot)%12+12)%12;
    k.classList.toggle('ins',inScale(m));
    k.classList.toggle('root',cls===0);
  });
}
function refreshScale(){
  setGridBackground($('#prGrid'));
  refreshKeyScale();
  renderScaleBar();
}
function setLoopLen(n){
  if(LOOP===n||![16,32,64].includes(n)) return;
  pushUndo();
  LOOP=n;
  buildPianoRoll(); renderNotes(); renderAuto();
  const h=$('#prTitle');
  if(h) h.textContent='Piano roll — '+(LOOP/16)+' mesure'+(LOOP>16?'s':'');
  setStatus('Patterns de '+(LOOP/16)+' mesure'+(LOOP>16?'s':'')+' ('+LOOP+' pas). Les notes au-delà sont conservées : elles réapparaissent si vous rallongez.');
}
function renderScaleBar(){
  const bar=$('#scaleBar'); if(!bar) return;
  bar.innerHTML='';
  const lab=document.createElement('span'); lab.className='plab'; lab.textContent='GAMME';
  bar.append(lab);
  const selR=document.createElement('select'); selR.className='msel';
  NAMES.forEach((n,i)=>{
    const o=document.createElement('option'); o.value=i; o.textContent=dispNote(i);
    if(i===scaleRoot) o.selected=true;
    selR.append(o);
  });
  selR.onchange=()=>{scaleRoot=+selR.value;refreshScale();};
  const selS=document.createElement('select'); selS.className='msel';
  Object.entries(SCALES).forEach(([k,s])=>{
    const o=document.createElement('option'); o.value=k; o.textContent=s.label;
    if(k===scaleKey) o.selected=true;
    selS.append(o);
  });
  selS.onchange=()=>{scaleKey=selS.value;refreshScale();};
  const snap=document.createElement('button');
  snap.className='pchip'+(scaleSnap?' sel':'');
  if(scaleSnap) snap.style.color='#7CE3B8';
  snap.innerHTML='<span class="sw" style="background:#7CE3B8"></span>Aimanter';
  snap.title='Les notes posées ou déplacées s\'alignent sur la gamme';
  snap.onclick=()=>{scaleSnap=!scaleSnap;renderScaleBar();
    setStatus(scaleSnap?'Aimant de gamme activé : impossible de jouer faux.':'Aimant de gamme désactivé.');};
  bar.append(selR,selS,snap);
  const glab=document.createElement('span'); glab.className='plab'; glab.textContent='GRILLE';
  bar.append(glab);
  [[1,'1 pas','double-croche (1/16)'],[0.5,'1/2','triple-croche (1/32)'],[1/3,'1/3','triolet — 3 notes par temps'],[0.25,'1/4','quadruple-croche (1/64)']]
    .forEach(([g,l,d])=>{
      const b=document.createElement('button');
      b.className='pchip'+(Math.abs(gridRes-g)<1e-9?' sel':'');
      if(Math.abs(gridRes-g)<1e-9) b.style.color='var(--amber)';
      b.textContent=l;
      b.title='Placement des notes à la '+d;
      b.onclick=()=>{
        gridRes=g; renderScaleBar();
        setStatus('Grille du piano roll : '+l+' — '+d+'. Placement, redimensionnement, vélocité, enregistrement et import MIDI suivent cette finesse.');
      };
      bar.append(b);
    });
  const zlab=document.createElement('span'); zlab.className='plab'; zlab.textContent='ZOOM';
  bar.append(zlab);
  const llab=document.createElement('span'); llab.className='plab'; llab.textContent='LONG';
  bar.append(llab);
  [[16,'1 mes'],[32,'2 mes'],[64,'4 mes']].forEach(([n,l])=>{
    const b=document.createElement('button');
    b.className='pchip'+(LOOP===n?' sel':'');
    if(LOOP===n) b.style.color='var(--mag)';
    b.textContent=l;
    b.title='Longueur des patterns : '+l+'ure'+(n>16?'s':'')+' ('+n+' pas)';
    b.onclick=()=>setLoopLen(n);
    bar.append(b);
  });
  [['−',-1],['+',1]].forEach(([l,d])=>{
    const ZOOMS=[18,26,36,50];
    const b=document.createElement('button');
    b.className='pchip tool'; b.textContent=l;
    b.title='Zoom horizontal du piano roll';
    b.onclick=()=>{
      const i=ZOOMS.indexOf(COLW);
      const ni=Math.max(0,Math.min(ZOOMS.length-1,(i<0?1:i)+d));
      if(ZOOMS[ni]!==COLW){ COLW=ZOOMS[ni]; buildPianoRoll(); }
    };
    bar.append(b);
  });
}
