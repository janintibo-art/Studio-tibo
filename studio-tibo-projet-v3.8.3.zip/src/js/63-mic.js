/* ---------- Enregistrement au micro ---------- */
let micRec=null, micStream=null, micChunks=[], micT0=0, micTimer=null, micCount=0;
async function micToggle(){
  if(micRec){ micRec.stop(); return; }
  if(!navigator.mediaDevices||!navigator.mediaDevices.getUserMedia){
    setStatus('Micro indisponible dans cet environnement (HTTPS ou application de bureau requis).');
    return;
  }
  try{
    micStream=await navigator.mediaDevices.getUserMedia({
      audio:{echoCancellation:false,noiseSuppression:false,autoGainControl:false}
    });
  }catch(e){
    setStatus('Accès au micro refusé — autorisez le microphone dans le navigateur puis réessayez.');
    return;
  }
  audio();
  micChunks=[];
  try{ micRec=new MediaRecorder(micStream); }
  catch(e){ setStatus('Enregistreur indisponible : '+e); micStream.getTracks().forEach(t=>t.stop()); return; }
  micRec.ondataavailable=e=>{ if(e.data&&e.data.size) micChunks.push(e.data); };
  micRec.onstop=async()=>{
    micStream.getTracks().forEach(t=>t.stop());
    clearInterval(micTimer);
    $('#btnMic').classList.remove('active');
    const blob=new Blob(micChunks,{type:micRec.mimeType||'audio/webm'});
    micRec=null;
    try{
      const buf=await ctx.decodeAudioData(await blob.arrayBuffer());
      pushUndo();
      micCount++;
      addSampleTrack('Micro '+micCount,buf);
      const ti=tracks.length-1;
      patterns[curPat].steps[ti][0]=3;        /* la prise démarre avec le pattern */
      renderTracks(); renderMixer(); switchView('seq');
      setStatus('🎤 Prise de '+buf.duration.toFixed(1)+' s ajoutée : piste « Micro '+micCount+' », déclenchée au pas 1 — ⚙ pour le décalage, la vitesse, la hauteur et l\'EQ. ⌘Z pour jeter la prise.');
    }catch(e){ setStatus('Prise illisible ('+e+') — réessayez.'); }
  };
  micRec.start();
  micT0=performance.now();
  $('#btnMic').classList.add('active');
  if(!playing) start();                       /* on enregistre en écoutant le morceau */
  micTimer=setInterval(()=>{
    setStatus('🎤 Enregistrement… '+((performance.now()-micT0)/1000).toFixed(1)+' s — recliquez 🎤 pour terminer. Casque conseillé (évite la repisse des enceintes).');
  },200);
}
$('#btnMic').onclick=micToggle;
