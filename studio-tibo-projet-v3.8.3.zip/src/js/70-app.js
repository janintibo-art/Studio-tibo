/* ---------- Menus, onglets, raccourcis ---------- */
function setStatus(m){$('#status').textContent=m;}
function updateStats(){
  const ns=tracks.filter(t=>t.kind==='sample').length;
  const totNotes=patterns.reduce((a,p)=>a+p.melo.reduce((b,m)=>b+m.length,0),0);
  $('#statRight').textContent=
    `${patterns.length} pattern${patterns.length>1?'s':''} · ${songLen()*2} mesures · ${ns} sample${ns>1?'s':''} · ${totNotes} note${totNotes>1?'s':''}`;
}
function switchView(id){
  if(typeof popups!=='undefined'&&popups[id]&&popups[id].win&&!popups[id].win.closed){
    try{ popups[id].win.focus(); }catch(e){}
    setStatus(POPVIEWS[id]+' est ouvert dans sa propre fenêtre (fermez-la pour le réintégrer).');
    return;
  }
  $$('.view').forEach(v=>{
    if(v.classList.contains('popped')) return;   /* les vues détachées restent visibles chez elles */
    v.classList.toggle('active',v.id==='view-'+id);
  });
  $$('.tab[data-view]').forEach(t=>t.classList.toggle('active',t.dataset.view===id));
}
$$('.tab[data-view]').forEach(t=>t.onclick=()=>switchView(t.dataset.view));
$$('[data-goto]').forEach(b=>b.onclick=()=>switchView(b.dataset.goto));
$$('.menu').forEach(m=>{
  m.querySelector(':scope>button').onclick=e=>{
    e.stopPropagation();
    const was=m.classList.contains('open');
    $$('.menu').forEach(x=>x.classList.remove('open'));
    if(!was) m.classList.add('open');
  };
});
document.addEventListener('click',()=>$$('.menu').forEach(m=>m.classList.remove('open')));
$('#btnPlay').onclick=()=>playing?stop():start();
$('#btnStop').onclick=stop;
$('#modePat').onclick=()=>setMode('pat');
$('#modeSong').onclick=()=>setMode('song');
$('#btnPlaySong').onclick=()=>{setMode('song'); if(!playing) start();};
$('#swing').addEventListener('change',e=>{
  swing=Math.min(60,Math.max(0,+e.target.value||0)); e.target.value=swing;
});
$('#btnMet').oncontextmenu=e=>{
  e.preventDefault();
  const old=$('#metPop'); if(old){ old.remove(); return; }
  const pop=document.createElement('div'); pop.id='metPop';
  pop.innerHTML='<div class="plab">MÉTRONOME</div>';
  const vol=document.createElement('input');
  vol.type='range'; vol.min=0; vol.max=150; vol.value=Math.round(metVol*100);
  vol.title='Volume du métronome';
  const vl=document.createElement('span'); vl.className='plab'; vl.textContent=vol.value+' %';
  vol.oninput=()=>{ metVol=vol.value/100; vl.textContent=vol.value+' %'; };
  const row=document.createElement('div'); row.className='row'; row.append(vol,vl);
  pop.append(row);
  const cb=document.createElement('div'); cb.className='row';
  const lb=document.createElement('span'); lb.className='plab'; lb.textContent='PRÉCOMPTE';
  cb.append(lb);
  [1,2].forEach(n=>{
    const b=document.createElement('button');
    b.className='pchip'+(countBars===n?' sel':'');
    b.textContent=n+' mes';
    b.onclick=()=>{ countBars=n; pop.remove(); $('#btnMet').oncontextmenu(e); };
    cb.append(b);
  });
  pop.append(cb);
  document.body.append(pop);
  const r=$('#btnMet').getBoundingClientRect();
  pop.style.left=r.left+'px'; pop.style.top=(r.bottom+6)+'px';
  setTimeout(()=>document.addEventListener('pointerdown',function h(ev){
    if(!pop.contains(ev.target)){ pop.remove(); document.removeEventListener('pointerdown',h); }
  }),0);
};
$('#btnMet').onclick=()=>{
  metro=!metro;
  $('#btnMet').classList.toggle('active',metro);
  if(metro) audio();
};
$('#autoClear').onclick=()=>{
  pushUndo();
  automation[autoKey]=[];
  renderAuto();
  setStatus('Courbe « '+AUTOP[autoKey].label+' » vidée.');
};
function renderProjName(){
  const el=$('#projName'); if(!el) return;
  el.textContent=projName;
  document.title='STUDIO TIBO — '+projName;
}
$('#projName').onclick=function(){
  inlineRename(this,()=>projName,v=>projName=v,()=>renderProjName(),24);
};
renderProjName();
let tapTimes=[];
$('#btnTap').onclick=()=>{
  const now=performance.now();
  tapTimes=tapTimes.filter(t=>now-t<2500);
  tapTimes.push(now);
  if(tapTimes.length>8) tapTimes.shift();
  if(tapTimes.length>=3){
    const iv=[];
    for(let i=1;i<tapTimes.length;i++) iv.push(tapTimes[i]-tapTimes[i-1]);
    const avg=iv.reduce((a,b)=>a+b,0)/iv.length;
    bpm=Math.min(300,Math.max(40,Math.round(600000/avg)/10));
    $('#bpm').value=bpm; applyFxLive();
    setStatus('TAP : '+bpm+' BPM (moyenne sur '+iv.length+' intervalle'+(iv.length>1?'s':'')+').');
  } else setStatus('TAP… encore '+(3-tapTimes.length)+' frappe(s) pour estimer le tempo.');
};
$('#bpm').addEventListener('change',e=>{
  bpm=Math.min(300,Math.max(40,Math.round((+e.target.value||120)*10)/10)); e.target.value=bpm;
  applyFxLive();
});
document.addEventListener('keydown',e=>{
  if(e.target.tagName==='INPUT') return;
  if(e.code==='Space'){e.preventDefault();playing?stop():start();}
  if(e.shiftKey&&!kbdOn&&/^Digit[1-8]$/.test(e.code)&&e.target.tagName!=='INPUT'){
    const i=+e.code.slice(5)-1;
    if(i<patterns.length){
      e.preventDefault();
      if(playing&&mode==='pat'&&i!==curPat){
        pendingPat=(pendingPat===i)?null:i;
        renderPatBars();
        setStatus(pendingPat==null?'File annulée.':'« '+patterns[i].name+' » en file (⇧'+(i+1)+') — bascule à la prochaine boucle.');
      } else selectPattern(i);
    }
    return;
  }
  if(!kbdOn){
    if(e.key==='1') switchView('seq');
    if(e.key==='2') switchView('pr');
    if(e.key==='3') switchView('pl');
    if(e.key==='4') switchView('mix');
    if(e.key==='5') switchView('lib');
    if(e.key==='6') switchView('auto');
    if(e.key==='7') switchView('tuto');
    if(e.key==='8') switchView('vst');
  }
});
$('#mSample').onclick=()=>$('#fileSample').click();
$('#btnAddSample').onclick=()=>$('#fileSample').click();
$('#mMidi').onclick=()=>$('#fileMidi').click();
$('#btnImportMidi').onclick=()=>$('#fileMidi').click();
$('#mSave').onclick=saveProject;
$('#mSaveTibo').onclick=saveProjectTibo;
$('#mSaveAs').onclick=saveProjectTiboAs;
$('#mOpen').onclick=()=>$('#fileProj').click();
$('#mNew').onclick=()=>{
  stop();
  pushUndo();   /* le nouveau projet est annulable */
  Object.keys(automation).forEach(k=>automation[k]=[]);
  swing=0; $('#swing').value=0;
  tracks=tracks.filter(t=>t.kind!=='sample');
  tracks.forEach(t=>{t.mute=false;t.solo=false;t.gain=0.9;t.pan=0;
    t.eq={lo:0,mid:0,hi:0};t.send={rev:0,dly:0};t.fxIns=[null,null];t._ch=null;});
  tracks[0].gain=1.0;
  insts=[normCh({name:'Lead 1',preset:'lead',mute:false,solo:false,gain:0.9,pan:0})];
  curInst=0;
  patterns=[newPattern('PAT 1')];
  bpm=120; $('#bpm').value=120; LOOP=32; autoTarget=0; projName='Mon morceau'; renderProjName(); songMarks=Array(PLSLOTS).fill(''); resetSaveTarget(); curAccent=null; applyTheme(curTheme); setMode('pat');
  buildPianoRoll();
  selectPattern(0); selectInst(0); buildPianoRoll(); renderMixer(); renderAuto();
  setStatus('Nouveau projet — annulable avec ⌘Z si c\'était une fausse manœuvre.');
};
$('#mClearSeq').onclick=()=>{
  patterns[curPat].steps=emptySteps();
  renderTracks(); setStatus(`Pattern rythmique de ${patterns[curPat].name} effacé.`);
};
$('#mClearPr').onclick=()=>{
  pushUndo();
  patterns[curPat].melo[curInst]=[]; notes=patterns[curPat].melo[curInst];
  renderNotes(); setStatus(`Piano roll de ${curIns().name} (${patterns[curPat].name}) effacé.`);
};
$('#mClearPl').onclick=()=>{
  patterns.forEach(p=>p.clips=Array(PLSLOTS).fill(false));
  renderPlaylist(); updateStats(); setStatus('Playlist vidée.');
};
$('#btnClearNotes').onclick=()=>{
  pushUndo();
  patterns[curPat].melo[curInst]=[]; notes=patterns[curPat].melo[curInst]; renderNotes();
};
$('#mAbout').onclick=()=>$('#aboutBg').classList.add('open');
$('#aboutClose').onclick=()=>$('#aboutBg').classList.remove('open');
$('#aboutBg').onclick=e=>{if(e.target.id==='aboutBg')e.target.classList.remove('open');};
const openExp=()=>$('#expBg').classList.add('open');
$('#mExport').onclick=openExp;
$('#btnExport').onclick=openExp;
$('#expClose').onclick=()=>$('#expBg').classList.remove('open');
$('#expBg').onclick=e=>{if(e.target.id==='expBg')e.target.classList.remove('open');};
$$('#expChoices .btn').forEach(b=>b.onclick=()=>{
  expReps=+b.dataset.rep;
  $$('#expChoices .btn').forEach(x=>x.classList.toggle('sel',x===b));
});
$$('#expSrc .btn').forEach(b=>b.onclick=()=>{
  expSrc=b.dataset.src;
  $$('#expSrc .btn').forEach(x=>x.classList.toggle('sel',x===b));
});
$$('#expFmt .btn').forEach(b=>b.onclick=()=>{
  expFmt=b.dataset.fmt;
  $$('#expFmt .btn').forEach(x=>x.classList.toggle('sel',x===b));
});
$('#expGo').onclick=async()=>{
  $('#expBg').classList.remove('open');
  audio();
  try{ if(expFmt==='stems') await exportStems(); else await exportWav(); }
  catch(err){ setStatus('Échec de l\'export : '+err); }
};
/* Panneau des raccourcis */
$('#mKeys').onclick=()=>$('#keysBg').classList.add('open');
$('#keysClose').onclick=()=>$('#keysBg').classList.remove('open');
$('#keysBg').onclick=e=>{ if(e.target.id==='keysBg') e.target.classList.remove('open'); };
document.addEventListener('keydown',e=>{
  if(e.key==='?'&&!kbdOn&&e.target.tagName!=='INPUT'){ e.preventDefault(); $('#keysBg').classList.toggle('open'); }
});
