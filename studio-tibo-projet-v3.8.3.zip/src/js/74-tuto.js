/* ---------- Tutoriel : sommaire + recherche instantanée ---------- */
function buildTutoNav(){
  const nav=$('#tutoNav'); if(!nav) return;
  nav.innerHTML='';
  document.querySelectorAll('#tutoBody .tuto-sec').forEach((sec,i)=>{
    const b=document.createElement('button');
    b.className='pchip tuto-link';
    b.textContent=sec.querySelector('h3').textContent;
    b.onclick=()=>{
      const q=$('#tutoSearch'); if(q&&q.value){ q.value=''; tutoFilter(''); }
      sec.scrollIntoView({behavior:'smooth',block:'start'});
    };
    nav.append(b);
  });
}
function tutoFilter(q){
  q=(q||'').trim().toLowerCase();
  document.querySelectorAll('#tutoBody .tuto-sec').forEach(sec=>{
    /* retirer les surlignages précédents */
    sec.querySelectorAll('mark.tt').forEach(m=>m.replaceWith(m.textContent));
    sec.normalize&&sec.normalize();
    if(!q){ sec.style.display=''; return; }
    const hay=(sec.textContent+' '+(sec.dataset.t||'')).toLowerCase();
    const hit=hay.includes(q);
    sec.style.display=hit?'':'none';
    if(hit&&q.length>=2){
      /* surligner dans les paragraphes */
      sec.querySelectorAll('p').forEach(p=>{
        for(const node of [...p.childNodes]){
          if(node.nodeType!==3) continue;
          const txt=node.textContent, low=txt.toLowerCase();
          let i=low.indexOf(q);
          if(i<0) continue;
          const frag=document.createDocumentFragment();
          let pos=0;
          while(i>=0){
            frag.append(txt.slice(pos,i));
            const mk=document.createElement('mark'); mk.className='tt'; mk.textContent=txt.slice(i,i+q.length);
            frag.append(mk);
            pos=i+q.length;
            i=low.indexOf(q,pos);
          }
          frag.append(txt.slice(pos));
          node.replaceWith(frag);
        }
      });
    }
  });
}
{
  const s=$('#tutoSearch');
  if(s) s.oninput=()=>tutoFilter(s.value);
}
buildTutoNav();
