/* ---------- Ouverture par double-clic d'un .tibo (application de bureau) ---------- */
let pendingTibo=null;
function b64ToU8(b64){
  const bin=atob(b64), u8=new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++) u8[i]=bin.charCodeAt(i);
  return u8;
}
(async()=>{
  if(!isTauri||!window.__TAURI__.core||!window.__TAURI__.core.invoke) return;
  try{
    const r=await window.__TAURI__.core.invoke('read_open_file');
    if(r&&r.b64) pendingTibo={name:r.name,u8:b64ToU8(r.b64)};
  }catch(e){ /* commande absente : version desktop antérieure, on ignore */ }
})();
async function applyPendingTibo(){
  if(!pendingTibo) return;
  const p=pendingTibo; pendingTibo=null;
  try{ await applyTiboBuffer(p.u8.buffer,p.name); }
  catch(e){ setStatus('Ouverture du projet impossible : '+e); }
}
