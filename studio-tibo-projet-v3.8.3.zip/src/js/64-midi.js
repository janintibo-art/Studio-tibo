/* ---------- Lecture de fichier MIDI ---------- */
function parseMidi(ab){
  const d=new DataView(ab); let p=0;
  const str=n=>{let s='';for(let i=0;i<n;i++)s+=String.fromCharCode(d.getUint8(p++));return s;};
  const u32=()=>{const v=d.getUint32(p);p+=4;return v;};
  const u16=()=>{const v=d.getUint16(p);p+=2;return v;};
  const u8=()=>d.getUint8(p++);
  const varlen=()=>{let v=0,b;do{b=u8();v=(v<<7)|(b&0x7F);}while(b&0x80);return v;};
  if(str(4)!=='MThd') throw 'pas un fichier MIDI';
  u32(); u16(); const ntrk=u16(), div=u16();
  const out=[];
  for(let t=0;t<ntrk;t++){
    if(str(4)!=='MTrk') throw 'piste invalide';
    const len=u32(), end=p+len;
    let tick=0, run=0; const open={};
    while(p<end){
      tick+=varlen();
      let st=u8();
      if(st<0x80){p--;st=run;} else run=st;
      const type=st&0xF0;
      if(type===0x90||type===0x80){
        const note=u8(), vel=u8();
        if(type===0x90&&vel>0) open[note]={tick,vel};
        else if(open[note]){
          out.push({tick:open[note].tick,pitch:note,vel:open[note].vel/127,durTick:tick-open[note].tick});
          delete open[note];
        }
      }
      else if(type===0xA0||type===0xB0||type===0xE0) p+=2;
      else if(type===0xC0||type===0xD0) p+=1;
      else if(st===0xFF){u8();p+=varlen();}
      else if(st===0xF0||st===0xF7) p+=varlen();
    }
    p=end;
  }
  return {notes:out,div};
}
function midiToNotes(raw,div){
  const stepTicks=div/4, minTick=Math.min(...raw.map(n=>n.tick));
  const arr=[];
  for(const n of raw.slice(0,300)){
    let pitch=n.pitch;
    while(pitch>TOPNOTE) pitch-=12;
    while(pitch<BOTNOTE) pitch+=12;
    const q=gridRes;
    const start=Math.round((n.tick-minTick)/stepTicks/q)*q;
    if(start>=LOOP) continue;
    const dur=Math.max(q,Math.min(LOOP-start,Math.round(n.durTick/stepTicks/q)*q));
    arr.push({pitch,start,dur,vel:Math.max(0.3,n.vel)});
  }
  return arr;
}
$('#fileMidi').addEventListener('change',async e=>{
  const f=e.target.files[0]; if(!f) return;
  try{
    const {notes:raw,div}=parseMidi(await f.arrayBuffer());
    if(!raw.length){setStatus('Aucune note trouvée dans ce fichier MIDI.');return;}
    const arr=midiToNotes(raw,div);
    pushUndo();
    patterns[curPat].melo[curInst]=arr; notes=arr;
    renderNotes(); switchView('pr');
    setStatus(`MIDI importé dans ${patterns[curPat].name} : ${arr.length} note(s).`);
  }catch(err){ setStatus('Fichier MIDI illisible : '+err); }
  e.target.value='';
});
