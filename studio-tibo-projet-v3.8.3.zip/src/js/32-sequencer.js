/* ---------- UI séquenceur ---------- */
function renderTracks(){
  const list=$('#trackList'); list.innerHTML='';
  const pat=patterns[curPat];
  tracks.forEach((tr,ti)=>{
    const row=document.createElement('div'); row.className='track';
    const info=document.createElement('div'); info.className='info';
    const mute=document.createElement('button');
    mute.className='mini'+(tr.mute?' on':''); mute.textContent='M'; mute.title='Muet';
    mute.onclick=()=>{tr.mute=!tr.mute;mute.classList.toggle('on',tr.mute);renderMixer();};
    const solo=document.createElement('button');
    solo.className='mini'+(tr.solo?' on solo':''); solo.textContent='S'; solo.title='Solo';
    solo.onclick=()=>{tr.solo=!tr.solo;solo.classList.toggle('on',tr.solo);solo.classList.toggle('solo',tr.solo);renderMixer();};
    const prev=document.createElement('button');
    prev.className='mini'; prev.textContent='▶'; prev.title='Pré-écoute';
    prev.onclick=()=>{audio();const t=ctx.currentTime+0.02,d=chanOf(tr).g;
      if(tr.kind==='sample'){ trigSample(ctx,d,tr,t,1); }
      else if(tr.kind==='mach') trigMach(tr,ctx,liveNoise,d,t,1);
      else VOICES[tr.kind](ctx,liveNoise,d,t,1);};
    const nm=document.createElement('div'); nm.className='name';
    nm.innerHTML=`${tr.name}<small>${tr.kind==='sample'?'sample importé':tr.kind==='mach'?MACHINES[tr.mach.kit].label:'synthèse interne'}</small>`;
    let ico;
    if(tr.kind==='mach'){
      ico=document.createElement('div');
      ico.className='tico tico-sw';
      ico.style.background=MACHINES[tr.mach.kit].color;
      ico.textContent=MACHINES[tr.mach.kit].sounds[tr.mach.si][0];
    } else {
      ico=document.createElement('img');
      ico.className='tico'; ico.alt='';
      ico.src=ICONS[tr.kind]||ICONS.sample;
    }
    const cog=document.createElement('button');
    cog.className='mini'; cog.textContent='⚙';
    cog.title='Réglages du son : volume, graves, médiums, aigus'+(tr.kind==='sample'?', vitesse, hauteur':'');
    cog.onclick=()=>openChanSettings(tr);
    info.append(ico,mute,solo,prev,cog,nm);
    if(tr.kind==='sample'||tr.kind==='mach'){
      const del=document.createElement('button');
      del.className='mini'; del.textContent='✕'; del.title='Supprimer la piste';
      del.onclick=()=>{
        pushUndo();
        tracks.splice(ti,1);
        patterns.forEach(p=>p.steps.splice(ti,1));
        renderTracks();renderMixer();
      };
      info.append(del);
    }
    const steps=document.createElement('div'); steps.className='steps';
    pat.steps[ti].forEach((v,si)=>{
      if(si>0&&si%4===0){const g=document.createElement('div');g.className='gap';steps.append(g);}
      const c=document.createElement('div');
      c.className='cell'+(si%4===0?' beat':''); c.dataset.v=v;
      c.innerHTML='<div class="fill"></div>';
      c.onclick=e=>{
        pushUndo();
        const st=pat.steps[ti];
        if(e.shiftKey) st[si]=(st[si]<=1)?3:st[si]-1;
        else st[si]=st[si]?0:3;
        c.dataset.v=st[si];
      };
      c.oncontextmenu=e=>{
        e.preventDefault();
        if(pat.steps[ti][si]){ pushUndo(); pat.steps[ti][si]=0; c.dataset.v=0; }
      };
      steps.append(c);
    });
    row.append(info,steps); list.append(row);
  });
  updateStats();
}
