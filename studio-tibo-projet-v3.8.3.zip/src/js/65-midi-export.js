/* ---------- Export MIDI (.mid format 1, PPQ 96 : triolets et 1/24 exacts) ---------- */
function midiVLQ(n){
  const out=[n&0x7F];
  while(n>>=7) out.unshift((n&0x7F)|0x80);
  return out;
}
function midiTrack(events){
  /* events : [{tick,bytes:[...]}] triés ; note-off avant note-on à tick égal */
  events.sort((a,b)=>a.tick-b.tick||a.prio-b.prio);
  const body=[];
  let last=0;
  for(const e of events){
    body.push(...midiVLQ(Math.max(0,e.tick-last)),...e.bytes);
    last=e.tick;
  }
  body.push(0x00,0xFF,0x2F,0x00);   /* fin de piste */
  const len=body.length;
  return [0x4D,0x54,0x72,0x6B,(len>>>24)&255,(len>>>16)&255,(len>>>8)&255,len&255,...body];
}
const MIDI_PPQ=96, MIDI_TPS=MIDI_PPQ/4;   /* 24 ticks par pas : 1/3 → 8, 1/4 → 6, 1/24 → 1 */
function exportMidiSegments(segments,fname,label){
  /* segments : [{pat, off}] — off en ticks ; les notes de chaque instrument
     sont fusionnées à travers les segments (pattern seul = 1 segment à 0). */
  const used=insts.map((ins,i)=>{
    const ev=[];
    for(const seg of segments){
      for(const n of (seg.pat.melo[i]||[])){
        if(n.start>=LOOP) continue;
        const on=seg.off+Math.round(n.start*MIDI_TPS);
        const off=seg.off+Math.round(Math.min(LOOP,n.start+n.dur)*MIDI_TPS);
        const vel=Math.max(1,Math.min(127,Math.round(n.vel*127)));
        ev.push({tick:on,prio:1,vel,pitch:n.pitch,kind:0x90});
        ev.push({tick:Math.max(on+1,off),prio:0,vel:0,pitch:n.pitch,kind:0x80});
      }
    }
    return {ins,ev};
  }).filter(x=>x.ev.length);
  if(!used.length){ setStatus('Rien à exporter : aucune note '+label+'.'); return; }
  const bytes=[];
  const ntrk=1+used.length;
  bytes.push(0x4D,0x54,0x68,0x64,0,0,0,6,0,1,(ntrk>>8)&255,ntrk&255,(MIDI_PPQ>>8)&255,MIDI_PPQ&255);
  const us=Math.round(60000000/bpm);
  bytes.push(...midiTrack([
    {tick:0,prio:0,bytes:[0xFF,0x51,0x03,(us>>>16)&255,(us>>>8)&255,us&255]},
    {tick:0,prio:0,bytes:[0xFF,0x58,0x04,4,2,24,8]},
  ]));
  const enc=new TextEncoder();
  used.forEach(({ins,ev},ti)=>{
    const ch=ti%16;
    const name=enc.encode(ins.name);
    const tev=[{tick:0,prio:0,bytes:[0xFF,0x03,name.length,...name]}]
      .concat(ev.map(e=>({tick:e.tick,prio:e.prio,bytes:[e.kind|ch,e.pitch,e.vel]})));
    bytes.push(...midiTrack(tev));
  });
  dlBlob(new Blob([new Uint8Array(bytes)],{type:'audio/midi'}),fname);
  setStatus('MIDI exporté '+label+' : '+used.length+' piste(s) ('+used.map(u=>u.ins.name).join(', ')+'), tempo '+bpm+' BPM, PPQ 96 — triolets préservés au tick près.');
}
function exportMidi(){
  const pat=patterns[curPat];
  exportMidiSegments([{pat,off:0}],
    projSlug()+'_'+pat.name.replace(/\s+/g,'-')+'.mid',
    'du pattern '+pat.name);
}
function exportMidiSong(){
  const L=songLen();
  if(!L){ setStatus('La playlist est vide : activez des patterns dans la vue Playlist (touche 3) avant d\'exporter le morceau.'); return; }
  const segments=[];
  for(let s=0;s<L;s++)
    for(const p of patterns)
      if(p.clips[s]) segments.push({pat:p,off:s*LOOP*MIDI_TPS});
  exportMidiSegments(segments,projSlug()+'_morceau.mid','du morceau ('+L*(LOOP/16)+' mesures)');
}
$('#mExportMidi').onclick=exportMidi;
$('#mExportMidiSong').onclick=exportMidiSong;
