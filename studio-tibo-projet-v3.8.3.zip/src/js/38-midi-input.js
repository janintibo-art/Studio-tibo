/* ---------- Entrée MIDI : périphériques, clavier musical, enregistrement ---------- */
let midiAccess=null, recArm=false, recDirty=false;
let recSplit='cur';            /* 'cur' | 'note' | 'chan' */
let recFree=false;             /* enregistrement non quantisé (précision 1/24 de pas) */
let countIn=false;             /* décompte avant l'enregistrement */
let countBars=1;               /* longueur du décompte : 1 ou 2 mesures */
let captureLog=[];             /* tout ce qui est joué pendant la lecture, armé ou non */
let stepInput=false, stepCur=0, stepHold=false, stepGroupPos=0, stepDirty=false;
let noteRoute={}, chanRoute={};
/* Table General MIDI percussions (noms des pads des boîtes à rythmes) */
const GM={35:'Kick',36:'Kick',37:'Rim',38:'Snare',39:'Clap',40:'Snare',41:'Tom',42:'HH fermé',
  43:'Tom',44:'HH pédale',45:'Tom',46:'HH ouvert',47:'Tom',48:'Tom',49:'Crash',50:'Tom',
  51:'Ride',52:'Crash',53:'Ride',54:'Tambourin',55:'Crash',56:'Cowbell',57:'Crash',59:'Ride'};
const PRESET_FOR=n=>!GM[n]?'pluck':(/Kick|Tom/.test(GM[n])?'bass':/HH|Ride|Crash|Tamb/.test(GM[n])?'pluck':'keys');
function routeInst(pitch0,ch){
  if(!recArm) return curInst;
  if(recSplit==='note'){
    if(noteRoute[pitch0]==null){
      const nm=((GM[pitch0]||'Note')+' '+pitch0).slice(0,16);
      let i=insts.findIndex(s=>s.name===nm);
      if(i<0){
        if(!recDirty){ pushUndo(); recDirty=true; }
        addInst(nm,PRESET_FOR(pitch0)); i=insts.length-1;
        renderInstBar(); renderMixer();
        setStatus('Nouvel instrument : '+nm+' — ce pad a maintenant son propre piano roll.');
      }
      noteRoute[pitch0]=i;
    }
    return noteRoute[pitch0];
  }
  if(recSplit==='chan'){
    if(chanRoute[ch]==null){
      const nm='Canal '+(ch+1);
      let i=insts.findIndex(s=>s.name===nm);
      if(i<0){
        if(!recDirty){ pushUndo(); recDirty=true; }
        addInst(nm,'pluck'); i=insts.length-1;
        renderInstBar(); renderMixer();
      }
      chanRoute[ch]=i;
    }
    return chanRoute[ch];
  }
  return curInst;
}
let kbdOn=false, kbdOct=0;
const heldNotes={};   /* pitch -> {voice, tOn, vel} */

/* Voix tenue : attaque puis sustain, relâchée au note-off */
function synthOn(pitch,vel,ins){
  audio();
  ins=ins||curIns();
  const P=SYNTHS[ins.preset]||SYNTHS.lead, dest=chanOf(ins).g;
  const t=ctx.currentTime+0.005;
  const o1=ctx.createOscillator(), o2=ctx.createOscillator();
  o1.type=P.w1; o2.type=P.w2;
  const f=440*Math.pow(2,(pitch-69)/12);
  o1.frequency.value=f; o2.frequency.value=f; o2.detune.value=P.det;
  const flt=ctx.createBiquadFilter();
  flt.type='lowpass'; flt.Q.value=P.q;
  flt.frequency.setValueAtTime(Math.max(120,P.cut),t);
  flt.frequency.exponentialRampToValueAtTime(Math.max(90,P.cutEnd),t+0.5);
  const g=ctx.createGain();
  g.gain.setValueAtTime(0,t);
  g.gain.linearRampToValueAtTime(vel*P.lvl,t+P.atk);
  o1.connect(flt); o2.connect(flt); flt.connect(g).connect(dest);
  o1.start(t); o2.start(t);
  return {
    stop(){
      const te=ctx.currentTime+0.005;
      g.gain.cancelScheduledValues(te);
      g.gain.setValueAtTime(Math.max(0.0001,g.gain.value),te);
      g.gain.linearRampToValueAtTime(0.0001,te+P.rel+0.05);
      o1.stop(te+P.rel+0.25); o2.stop(te+P.rel+0.25);
    }
  };
}
function noteOn(pitch,vel,ch=0,src='kbd'){
  const pitch0=Math.round(pitch);
  pitch=pitch0;
  while(pitch>TOPNOTE) pitch-=12;
  while(pitch<BOTNOTE) pitch+=12;
  const key=ch+':'+pitch;
  if(heldNotes[key]) return;
  const inst=(src==='midi')?routeInst(pitch0,ch):curInst;
  const h={voice:synthOn(pitch,vel,insts[inst]),tOn:ctx.currentTime,vel,pitch,inst};
  heldNotes[key]=h;
  if(playing){
    h.cap={pitch,tOn:h.tOn,tOff:0,vel:+vel.toFixed(2)};
    captureLog.push(h.cap);
    if(captureLog.length>256) captureLog.shift();
  }
  if(stepInput&&!playing){
    if(!stepDirty){ pushUndo(); stepDirty=true; }
    if(!stepHold){ stepHold=true; stepGroupPos=stepCur; }
    notes.push({pitch,start:stepGroupPos,
      dur:Math.min(LOOP-stepGroupPos,Math.max(gridRes,defaultDur)),vel:+vel.toFixed(2)});
    renderNotes();
  }
}
function noteOff(pitch,ch=0){
  pitch=Math.round(pitch);
  while(pitch>TOPNOTE) pitch-=12;
  while(pitch<BOTNOTE) pitch+=12;
  const key=ch+':'+pitch;
  const h=heldNotes[key]; if(!h) return;
  h.voice.stop();
  if(h.cap) h.cap.tOff=ctx.currentTime;
  if(stepInput&&!playing){
    delete heldNotes[key];
    if(!Object.keys(heldNotes).length&&stepHold){
      stepHold=false;
      stepCur=(stepGroupPos+Math.max(gridRes,defaultDur))%LOOP;
      drawStepCursor();
    }
    return;
  }
  if(recArm&&playing){
    if(!recDirty){ pushUndo(); recDirty=true; }
    const sp=spStep(), q=recFree?1/24:gridRes;
    let start=Math.round((h.tOn-playT0)/sp/q)*q;
    start=((start%LOOP)+LOOP)%LOOP;
    const dur=Math.max(q,Math.min(LOOP-start,Math.round((ctx.currentTime-h.tOn)/sp/q)*q));
    const arr=patterns[curPat].melo[h.inst]||(patterns[curPat].melo[h.inst]=[]);
    arr.push({pitch:h.pitch,start,dur,vel:+h.vel.toFixed(2)});
    if(h.inst===curInst) notes=arr;
    renderNotes();
  }
  delete heldNotes[key];
}
function allNotesOff(){
  Object.keys(heldNotes).forEach(k=>{ const i=k.indexOf(':'); noteOff(+k.slice(i+1),+k.slice(0,i)); });
}

/* ----- Périphériques MIDI (Web MIDI API) ----- */
function midiInputCount(){
  if(!midiAccess) return 0;
  let n=0; midiAccess.inputs.forEach(()=>n++);
  return n;
}
function bindMidiInputs(){
  if(!midiAccess) return;
  midiAccess.inputs.forEach(inp=>{
    inp.onmidimessage=msg=>{
      const [st,d1,d2]=msg.data, type=st&0xF0, ch=st&0x0F;
      if(type===0x90&&d2>0) noteOn(d1,Math.max(0.1,d2/127),ch,'midi');
      else if(type===0x80||(type===0x90&&d2===0)) noteOff(d1,ch);
    };
  });
  renderMidiBar();
}
function initMidi(){
  if(midiAccess||!navigator.requestMIDIAccess){ renderMidiBar(); return; }
  navigator.requestMIDIAccess({sysex:false}).then(acc=>{
    midiAccess=acc;
    bindMidiInputs();
    acc.onstatechange=()=>{ bindMidiInputs();
      setStatus(`Périphériques MIDI : ${midiInputCount()} entrée(s) connectée(s).`); };
    if(midiInputCount()) setStatus(`Clavier MIDI détecté (${midiInputCount()} entrée(s)) — jouez, c'est branché sur l'instrument sélectionné.`);
  }).catch(()=>renderMidiBar());
}

/* ----- Clavier musical (positions physiques : compatible AZERTY/QWERTY) ----- */
const KMAP={
  KeyZ:0,KeyS:1,KeyX:2,KeyD:3,KeyC:4,KeyV:5,KeyG:6,KeyB:7,KeyH:8,KeyN:9,KeyJ:10,KeyM:11,
  KeyQ:12,Digit2:13,KeyW:14,Digit3:15,KeyE:16,KeyR:17,Digit5:18,KeyT:19,Digit6:20,KeyY:21,Digit7:22,KeyU:23,KeyI:24,
};
const kbdBase=()=>60+kbdOct*12;
document.addEventListener('keydown',e=>{
  if(!kbdOn||e.repeat||e.target.tagName==='INPUT'||e.ctrlKey||e.metaKey) return;
  if(e.code in KMAP){ e.preventDefault(); noteOn(kbdBase()+KMAP[e.code],defaultVel); }
  else if(e.code==='ArrowDown'){ e.preventDefault(); kbdOct=Math.max(-1,kbdOct-1); renderMidiBar(); }
  else if(e.code==='ArrowUp'){ e.preventDefault(); kbdOct=Math.min(2,kbdOct+1); renderMidiBar(); }
  else if(e.code==='Escape'){ setKbd(false); }
});
document.addEventListener('keyup',e=>{
  if(!kbdOn) return;
  if(e.code in KMAP) noteOff(kbdBase()+KMAP[e.code]);
});
function setKbd(on){
  kbdOn=on;
  if(!on) allNotesOff();
  renderMidiBar();
  setStatus(on
    ?'Clavier musical activé : rangée du bas = octave grave, rangée du haut = aiguë · ↑/↓ : octave · Échap : quitter. (Les raccourcis 1-6 sont suspendus.)'
    :'Clavier musical désactivé — raccourcis de vues rétablis.');
}
function setRec(on){
  recArm=on; recDirty=false;
  noteRoute={}; chanRoute={};
  $('#btnRec').classList.toggle('active',on);
  const dest=recSplit==='note'?'un instrument par note (boîte à rythmes)'
            :recSplit==='chan'?'un instrument par canal MIDI'
            :curIns().name;
  if(on&&!playing) setStatus('Armé : lancez la lecture (espace) puis jouez — enregistrement vers '+dest+'.');
  else if(on) setStatus('Enregistrement en cours vers '+dest+'…');
  else setStatus('Enregistrement désarmé.');
}

/* ----- Capture en différé (« vous avez joué sans armer ? tout est là ») ----- */
function captureTake(){
  const take=captureLog.filter(e=>e.tOff&&e.tOn>=playT0-0.01);
  if(!take.length){
    setStatus('Rien à capturer : jouez pendant la lecture (même sans REC), puis capturez la prise.');
    return;
  }
  pushUndo();
  const sp=spStep(), q=recFree?1/24:gridRes;
  take.forEach(e=>{
    let start=Math.round((e.tOn-playT0)/sp/q)*q;
    start=((start%LOOP)+LOOP)%LOOP;
    const dur=Math.max(q,Math.min(LOOP-start,Math.round((e.tOff-e.tOn)/sp/q)*q));
    notes.push({pitch:e.pitch,start,dur,vel:e.vel});
  });
  captureLog=[];
  renderNotes();
  setStatus('💡 Prise capturée : '+take.length+' note(s) écrites dans '+curIns().name+' — comme si REC avait été armé.');
}
/* ----- Curseur de saisie pas à pas ----- */
function drawStepCursor(){
  const grid=$('#prGrid'); if(!grid) return;
  let el=$('#stepCursor');
  if(!stepInput){ if(el) el.remove(); return; }
  if(!el){ el=document.createElement('div'); el.id='stepCursor'; grid.append(el); }
  el.style.left=(stepCur*COLW)+'px';
}
function setStepInput(on){
  stepInput=on; stepHold=false; stepDirty=false;
  if(on){ stepCur=0; allNotesOff(); }
  drawStepCursor(); renderMidiBar();
  setStatus(on
    ?'Saisie pas à pas : lecture arrêtée, jouez (clavier ⌨ ou MIDI) — chaque note ou accord s\'écrit au curseur puis avance. ‹ › déplacent le curseur.'
    :'Saisie pas à pas terminée.');
}

/* ----- Barre MIDI du piano roll ----- */
function renderMidiBar(){
  const bar=$('#midiBar'); if(!bar) return;
  bar.innerHTML='';
  const lab=document.createElement('span'); lab.className='plab'; lab.textContent='JOUER';
  bar.append(lab);
  const kb=document.createElement('button');
  kb.className='pchip'+(kbdOn?' sel':'');
  if(kbdOn) kb.style.color='#FFD166';
  kb.innerHTML='<span class="sw" style="background:#FFD166"></span>⌨ Clavier musical';
  kb.onclick=()=>setKbd(!kbdOn);
  bar.append(kb);
  if(kbdOn){
    const om=document.createElement('button'); om.className='pchip tool'; om.textContent='OCT −';
    om.onclick=()=>{kbdOct=Math.max(-1,kbdOct-1);renderMidiBar();};
    const lab2=document.createElement('button'); lab2.className='pchip';
    lab2.textContent='C'+(4+kbdOct); lab2.disabled=true; lab2.style.opacity=.8;
    const op=document.createElement('button'); op.className='pchip tool'; op.textContent='OCT +';
    op.onclick=()=>{kbdOct=Math.min(2,kbdOct+1);renderMidiBar();};
    bar.append(om,lab2,op);
  }
  const si=document.createElement('button');
  si.className='pchip'+(stepInput?' sel':'');
  if(stepInput) si.style.color='var(--amber)';
  si.innerHTML='<span class="sw" style="background:var(--amber)"></span>✎ Pas à pas';
  si.title='Saisie pas à pas (Logic : Step Input) : à l\'arrêt, chaque note jouée s\'écrit au curseur et avance d\'une longueur de plume';
  si.onclick=()=>setStepInput(!stepInput);
  bar.append(si);
  if(stepInput){
    [['‹',-1],['›',1]].forEach(([l,d])=>{
      const b=document.createElement('button');
      b.className='pchip tool'; b.textContent=l; b.title='Déplacer le curseur d\'un pas de grille';
      b.onclick=()=>{ stepCur=((stepCur+d*gridRes)%LOOP+LOOP)%LOOP; drawStepCursor(); };
      bar.append(b);
    });
  }
  const fr=document.createElement('button');
  fr.className='pchip'+(recFree?' sel':'');
  if(recFree) fr.style.color='#7CE3B8';
  fr.innerHTML='<span class="sw" style="background:#7CE3B8"></span>'+(recFree?'REC libre':'REC quantisé');
  fr.title='Libre : votre jeu est enregistré tel quel (précision 1/24 de pas) — quantisez ensuite via Édition › Quantiser';
  fr.onclick=()=>{ recFree=!recFree; renderMidiBar();
    setStatus(recFree?'Enregistrement libre : le micro-timing de votre jeu est conservé. Édition › Quantiser (100 % ou 50 %) pour recaler.'
                     :'Enregistrement quantisé sur la grille.'); };
  bar.append(fr);
  const ci=document.createElement('button');
  ci.className='pchip'+(countIn?' sel':'');
  if(countIn) ci.style.color='var(--red)';
  ci.innerHTML='<span class="sw" style="background:var(--red)"></span>Décompte';
  ci.title='Une mesure de métronome avant que l\'enregistrement démarre (Logic : Count-in)';
  ci.onclick=()=>{ countIn=!countIn; renderMidiBar(); };
  bar.append(ci);
  const cap=document.createElement('button');
  cap.className='pchip';
  cap.innerHTML='<span class="sw" style="background:#FFD166"></span>💡 Capturer';
  cap.title='Capture en différé (Logic : Capture as recording) : récupère ce que vous venez de jouer pendant la lecture, même sans REC';
  cap.onclick=captureTake;
  bar.append(cap);
  const SPLITS=[
    ['cur','REC → courant','Tout est enregistré dans l\'instrument sélectionné'],
    ['note','REC → par note','Boîte à rythmes (Electribe, TR…) : chaque pad/note crée automatiquement son instrument et son piano roll'],
    ['chan','REC → par canal','Matériel multitimbral : un instrument par canal MIDI (1-16)'],
  ];
  const sm=document.createElement('button');
  const cs=SPLITS.find(s=>s[0]===recSplit);
  sm.className='pchip'+(recSplit!=='cur'?' sel':'');
  if(recSplit!=='cur') sm.style.color='var(--red)';
  sm.innerHTML='<span class="sw" style="background:var(--red)"></span>'+cs[1];
  sm.title=cs[2];
  sm.onclick=()=>{
    const i=SPLITS.findIndex(s=>s[0]===recSplit);
    recSplit=SPLITS[(i+1)%SPLITS.length][0];
    noteRoute={}; chanRoute={};
    renderMidiBar();
    const ns=SPLITS.find(s=>s[0]===recSplit);
    setStatus(ns[1]+' — '+ns[2]+'.');
  };
  bar.append(sm);
  const st=document.createElement('button');
  st.className='pchip'; st.disabled=true; st.style.opacity=.8;
  const n=midiInputCount();
  st.innerHTML=`<span class="sw" style="background:${n?'var(--green)':'var(--line)'}"></span>`+
    (navigator.requestMIDIAccess?(midiAccess?`MIDI : ${n} entrée(s)`:'MIDI : autorisation…'):'MIDI : non supporté ici');
  bar.append(st);
}
$('#btnRec').onclick=()=>setRec(!recArm);
renderMidiBar();
