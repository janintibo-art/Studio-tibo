/* ---------- Écran d'accueil ---------- */
let _entered=false;
function enterStudio(){
  if(_entered) return;           // évite le double déclenchement (tactile + clic synthétique)
  _entered=true;
  /* masquage immédiat et certain de l'écran d'accueil — ne dépend d'aucune transition */
  const _sp=document.getElementById('splash');
  if(_sp){ _sp.classList.add('hide'); _sp.style.display='none'; }
  /* Chaque étape est isolée : sur mobile/WebView, une API absente (MIDI…) ne doit
     jamais empêcher l'entrée dans le studio. */
  try{ audio(); }catch(e){}      // geste utilisateur : déverrouille le moteur audio
  try{ initMidi(); }catch(e){}   // MIDI absent sur Android : on ignore proprement
  try{ applyPendingTibo(); }catch(e){}
  if(window._resume){
    try{
      applyProject(window._resume);
      setStatus('Session précédente restaurée — réglages, patterns et notes. (Les samples audio ne sont pas dans l\'autosauvegarde : sauvegardez en .tibo pour tout conserver.)');
    }catch(e){ setStatus('Reprise impossible : '+e); }
    window._resume=null;
  }
  if(_sp){ setTimeout(()=>{ try{_sp.remove();}catch(e){} },50); }
  try{ setStatus(isTauri?'Bienvenue dans STUDIO TIBO — bonne production !':'Bienvenue dans STUDIO TIBO. Appuyez sur espace (ou ▶) pour écouter la démo.'); }catch(e){}
  if(isTauri){ const v=$('.logo .ver'); if(v) v.textContent+=' · app'; }
}
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&$('#splash')&&!$('#splash').classList.contains('hide')) enterStudio();
});
window.enterStudio=enterStudio;   // accessible depuis les attributs onclick/ontouchend du HTML
{
  const se=$('#splashEnter');
  if(se){
    try{ se.addEventListener('pointerup',ev=>{ ev.preventDefault&&ev.preventDefault(); enterStudio(); },{passive:false}); }catch(e){}
    try{ se.addEventListener('touchend', ev=>{ ev.preventDefault&&ev.preventDefault(); enterStudio(); },{passive:false}); }catch(e){}
    try{ se.addEventListener('click', enterStudio); }catch(e){}
  }
}
