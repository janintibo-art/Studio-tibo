/* ---------- Autosauvegarde locale (réglages + notes ; samples exclus) ---------- */
const AUTOSAVE_KEY='studio-tibo-autosave';
function lsOK(){
  try{ localStorage.setItem('_tibo_t','1'); localStorage.removeItem('_tibo_t'); return true; }
  catch(e){ return false; }
}
if(lsOK()){
  const save=()=>{ try{
    localStorage.setItem(AUTOSAVE_KEY,JSON.stringify({t:Date.now(),data:buildProjectData()}));
  }catch(e){} };
  setInterval(save,20000);
  window.addEventListener('beforeunload',save);
  try{
    const raw=localStorage.getItem(AUTOSAVE_KEY);
    if(raw){
      const saved=JSON.parse(raw);
      if(saved&&saved.data&&saved.data.app==='studio-un'){
        const age=Math.round((Date.now()-saved.t)/60000);
        const b=document.createElement('button');
        b.className='btn'; b.id='btnResume';
        b.textContent='↻ Reprendre la session ('+(age<1?'à l\'instant':'il y a '+age+' min')+')';
        b.onclick=e=>{ e.stopPropagation(); window._resume=saved.data; $('#splashEnter').click(); };
        const anchor=$('#splashEnter');
        if(anchor&&anchor.insertAdjacentElement) anchor.insertAdjacentElement('afterend',b);
      }
    }
  }catch(e){}
}
