/* ---------- Sélection : Suppr, copier, couper, coller ---------- */
document.addEventListener('keydown',e=>{
  if((e.metaKey||e.ctrlKey)&&(e.key==='s'||e.key==='S')){ e.preventDefault(); $(e.shiftKey?'#mSaveAs':'#mSaveTibo').click(); return; }
  if(kbdOn||e.target.tagName==='INPUT'||!prVisible()) return;
  const mod=e.metaKey||e.ctrlKey;
  if((e.key==='Delete'||e.key==='Backspace')&&sel.size){
    e.preventDefault(); pushUndo();
    patterns[curPat].melo[curInst]=notes.filter((n,i)=>!sel.has(i));
    notes=patterns[curPat].melo[curInst];
    clearSel(false); renderNotes();
    setStatus('Sélection supprimée (⌘Z pour revenir).');
  }
  else if(mod&&(e.key==='c'||e.key==='x')){
    const src=sel.size?[...sel].map(i=>notes[i]).filter(Boolean):notes;
    if(!src.length) return;
    e.preventDefault();
    clipNotes=src.map(n=>({...n}));
    if(e.key==='x'){
      pushUndo();
      patterns[curPat].melo[curInst]=notes.filter((n,i)=>sel.size?!sel.has(i):false);
      if(!sel.size) patterns[curPat].melo[curInst]=[];
      notes=patterns[curPat].melo[curInst];
      clearSel(false); renderNotes();
    }
    setStatus(clipNotes.length+' note(s) '+(e.key==='x'?'coupée(s)':'copiée(s)')+' — ⌘V pour coller ici ou dans un autre pattern/instrument.');
  }
  else if(mod&&e.key==='v'&&clipNotes.length){
    e.preventDefault(); pushUndo();
    const first=notes.length;
    clipNotes.forEach(n=>notes.push({...n}));
    sel=new Set(Array.from({length:clipNotes.length},(_,k)=>first+k));
    renderNotes();
    setStatus(clipNotes.length+' note(s) collée(s) dans '+curIns().name+' (sélectionnées : déplacez-les au besoin).');
  }
  else if(mod&&e.key==='d'&&sel.size){
    e.preventDefault(); pushUndo();
    const src=[...sel].map(i=>notes[i]).filter(Boolean);
    const s0=Math.min(...src.map(n=>n.start));
    const e1=Math.max(...src.map(n=>n.start+n.dur));
    const span=Math.max(gridRes,Math.ceil((e1-s0)/gridRes)*gridRes);
    const first=notes.length;
    let added=0;
    src.forEach(n=>{
      const ns=n.start+span;
      if(ns>=LOOP) return;
      notes.push({...n,start:ns,dur:Math.min(n.dur,LOOP-ns)});
      added++;
    });
    sel=new Set(Array.from({length:added},(_,k)=>first+k));
    renderNotes();
    setStatus(added
      ?added+' note(s) dupliquée(s) à la suite (⌘D) — la copie est sélectionnée.'
      :'Pas de place après la sélection pour dupliquer.');
  }
  else if(e.key==='Escape'&&sel.size) clearSel();
});
