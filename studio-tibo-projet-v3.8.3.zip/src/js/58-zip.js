/* ---------- ZIP maison (stored, sans compression) ---------- */
/* Sert au format projet .tibo (JSON + samples WAV) et à l'export de stems. */
const CRC_T=(()=>{
  const t=new Uint32Array(256);
  for(let n=0;n<256;n++){
    let c=n;
    for(let k=0;k<8;k++) c=(c&1)?(0xEDB88320^(c>>>1)):(c>>>1);
    t[n]=c;
  }
  return t;
})();
function crc32(u8){
  let c=0xFFFFFFFF;
  for(let i=0;i<u8.length;i++) c=CRC_T[(c^u8[i])&255]^(c>>>8);
  return (c^0xFFFFFFFF)>>>0;
}
/* files : [{name:'a/b.wav', data:Uint8Array}] → Blob zip */
function zipStore(files){
  const enc=new TextEncoder();
  const parts=[], cd=[];
  let off=0;
  for(const f of files){
    const nm=enc.encode(f.name), crc=crc32(f.data), sz=f.data.length;
    const lh=new DataView(new ArrayBuffer(30));
    lh.setUint32(0,0x04034b50,true);
    lh.setUint16(4,20,true);      /* version requise */
    lh.setUint16(6,0x0800,true);  /* drapeau UTF-8 */
    lh.setUint16(8,0,true);       /* stored */
    lh.setUint32(14,crc,true);
    lh.setUint32(18,sz,true); lh.setUint32(22,sz,true);
    lh.setUint16(26,nm.length,true);
    parts.push(new Uint8Array(lh.buffer),nm,f.data);
    const ch=new DataView(new ArrayBuffer(46));
    ch.setUint32(0,0x02014b50,true);
    ch.setUint16(4,20,true); ch.setUint16(6,20,true);
    ch.setUint16(8,0x0800,true);  /* UTF-8 */
    ch.setUint16(10,0,true);      /* stored */
    ch.setUint32(16,crc,true);
    ch.setUint32(20,sz,true); ch.setUint32(24,sz,true);
    ch.setUint16(28,nm.length,true);
    ch.setUint32(42,off,true);    /* offset du local header */
    cd.push(new Uint8Array(ch.buffer),nm);
    off+=30+nm.length+sz;
  }
  const cdSize=cd.reduce((a,p)=>a+p.length,0);
  const eo=new DataView(new ArrayBuffer(22));
  eo.setUint32(0,0x06054b50,true);
  eo.setUint16(8,files.length,true); eo.setUint16(10,files.length,true);
  eo.setUint32(12,cdSize,true); eo.setUint32(16,off,true);
  return new Blob([...parts,...cd,new Uint8Array(eo.buffer)],{type:'application/zip'});
}
/* ArrayBuffer zip → {nom: Uint8Array} (entrées stored uniquement) */
function unzipStore(buf){
  const dv=new DataView(buf), u8=new Uint8Array(buf), td=new TextDecoder();
  let p=buf.byteLength-22;
  while(p>=0&&dv.getUint32(p,true)!==0x06054b50) p--;
  if(p<0) throw 'archive invalide';
  const n=dv.getUint16(p+10,true);
  let cd=dv.getUint32(p+16,true);
  const out={};
  for(let i=0;i<n;i++){
    if(dv.getUint32(cd,true)!==0x02014b50) throw 'répertoire central invalide';
    const method=dv.getUint16(cd+10,true);
    const size=dv.getUint32(cd+20,true);
    const nl=dv.getUint16(cd+28,true), el=dv.getUint16(cd+30,true), cl=dv.getUint16(cd+32,true);
    const lho=dv.getUint32(cd+42,true);
    const name=td.decode(u8.subarray(cd+46,cd+46+nl));
    if(method!==0) throw 'archive compressée non gérée (utilisez un .tibo)';
    const lnl=dv.getUint16(lho+26,true), lel=dv.getUint16(lho+28,true);
    const start=lho+30+lnl+lel;
    out[name]=u8.slice(start,start+size);
    cd+=46+nl+el+cl;
  }
  return out;
}
const sanitizeName=s=>s.replace(/[^\wÀ-ÿ .-]+/g,'_').slice(0,40)||'piste';
