/* ---------- Piano roll ---------- */
const TOPNOTE=84, BOTNOTE=48, NROWS=TOPNOTE-BOTNOTE+1, ROWH=18;
let COLW=26;
const NAMES=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
const NAMES_FR=['Do','Do#','Ré','Ré#','Mi','Fa','Fa#','Sol','Sol#','La','La#','Si'];
let noteFr=false;
const dispNote=i=>noteFr?NAMES_FR[i]:NAMES[i];
const isBlack=m=>[1,3,6,8,10].includes(m%12);
const noteName=m=>dispNote(m%12)+(Math.floor(m/12)-1);
const rowOf=m=>TOPNOTE-m, pitchOf=r=>TOPNOTE-r;
function buildPianoRoll(){
  const keys=$('#prKeys'); keys.innerHTML='';
  for(let r=0;r<NROWS;r++){
    const m=pitchOf(r), k=document.createElement('div');
    k.className='pr-key'+(isBlack(m)?' black':'')+(m%12===0?' c':'');
    k.textContent=noteName(m);
    k.onclick=()=>{audio();playSynth(ctx,chanOf(curIns()).g,ctx.currentTime+0.02,m,0.3,0.8,1,SYNTHS[curIns().preset]);};
    keys.append(k);
  }
  const grid=$('#prGrid');
  grid.style.width=(LOOP*COLW)+'px';
  grid.style.height=(NROWS*ROWH)+'px';
  setGridBackground(grid);
  refreshKeyScale();
  renderScaleBar();
  const lane=$('#prVel');
  lane.style.width=(LOOP*COLW)+'px';
  lane.style.backgroundImage=`
    repeating-linear-gradient(90deg, transparent 0, transparent ${COLW*4-1}px, #221C38 ${COLW*4-1}px, #221C38 ${COLW*4}px)`;
  renderNotes();
}
function renderNotes(){
  $$('.pr-note').forEach(n=>n.remove());
  const grid=$('#prGrid');
  /* notes fantômes des autres instruments (lecture seule) */
  patterns[curPat].melo.forEach((arr,ii)=>{
    if(ii===curInst||!arr) return;
    for(const n of arr){
      if(n.start>=LOOP) continue;
      const el=document.createElement('div');
      el.className='pr-note ghost';
      el.style.left=(n.start*COLW)+'px';
      el.style.top=(rowOf(n.pitch)*ROWH)+'px';
      el.style.width=(n.dur*COLW-3)+'px';
      el.style.background=instColor(ii);
      grid.append(el);
    }
  });
  sel=new Set([...sel].filter(i=>i<notes.length));
  const col=instColor(curInst);
  notes.forEach((n,i)=>{
    if(n.start>=LOOP) return;
    const el=document.createElement('div');
    el.className='pr-note';
    el.style.left=(n.start*COLW)+'px';
    el.style.top=(rowOf(n.pitch)*ROWH)+'px';
    el.style.width=(n.dur*COLW-3)+'px';
    el.style.opacity=(0.45+0.55*n.vel).toFixed(2);
    el.style.background=`linear-gradient(180deg, ${col}, color-mix(in srgb, ${col} 70%, #000))`;
    el.style.borderColor=col;
    el.style.boxShadow=`0 1px 5px ${col}66`;
    el.dataset.i=i;
    if(sel.has(i)) el.classList.add('selnote');
    el.title='Vélocité : '+Math.round(n.vel*100)+' %';
    el.innerHTML='<div class="rsz"></div>';
    grid.append(el);
  });
  renderVel();
  updateStats();
  drawStepCursor();
}
function renderVel(){
  const lane=$('#prVel'); if(!lane) return;
  lane.querySelectorAll('.vbar').forEach(b=>b.remove());
  notes.forEach((n,i)=>{
    const b=document.createElement('div');
    b.className='vbar'; b.dataset.i=i;
    b.style.left=(n.start*COLW+2)+'px';
    b.style.width=Math.max(4,COLW*Math.min(n.dur,1)-6)+'px';
    b.style.height=Math.max(4,Math.round(n.vel*62))+'px';
    b.title=Math.round(n.vel*100)+' %';
    b.style.background=`linear-gradient(180deg, ${instColor(curInst)}, color-mix(in srgb, ${instColor(curInst)} 60%, #000))`;
    lane.append(b);
  });
}
let drag=null, defaultVel=0.85, defaultDur=1, vpaint=false;
let sel=new Set(), marq=null, clipNotes=[];
function clearSel(render=true){ if(sel.size){ sel.clear(); if(render) renderNotes(); } }
const prVisible=()=>{ const g=$('#prGrid'); return g&&g.offsetParent!==null; };
function gpos(e){
  const r=$('#prGrid').getBoundingClientRect();
  return {col:Math.floor((e.clientX-r.left)/(COLW*gridRes))*gridRes, row:Math.floor((e.clientY-r.top)/ROWH)};
}
let wheelDirty=0;
document.addEventListener('wheel',e=>{
  const el=e.target.closest&&e.target.closest('.pr-note');
  if(!el||el.classList.contains('ghost')) return;
  e.preventDefault();
  const i=+el.dataset.i, n=notes[i]; if(!n) return;
  if(performance.now()>wheelDirty){ pushUndo(); }
  wheelDirty=performance.now()+600;
  const step=e.shiftKey?0.02:0.06;
  n.vel=Math.min(1,Math.max(0.05,+(n.vel+(e.deltaY<0?step:-step)).toFixed(2)));
  defaultVel=n.vel;
  el.style.opacity=(0.45+0.55*n.vel).toFixed(2);
  el.title='Vélocité : '+Math.round(n.vel*100)+' %';
  const vb=$(`#prVel .vbar[data-i="${i}"]`);
  if(vb){ vb.style.height=Math.max(4,Math.round(n.vel*62))+'px'; vb.title=Math.round(n.vel*100)+' %'; }
},{passive:false});
document.addEventListener('mousedown',e=>{
  const grid=$('#prGrid');
  /* clic droit-glisser dans la grille : rectangle de sélection */
  if(e.button===2&&grid&&(e.target===grid||e.target.closest('#prGrid'))){
    const r=grid.getBoundingClientRect();
    marq={x0:e.clientX-r.left,y0:e.clientY-r.top,x1:e.clientX-r.left,y1:e.clientY-r.top};
    let mv=$('#marq');
    if(!mv){ mv=document.createElement('div'); mv.id='marq'; grid.append(mv); }
    e.preventDefault(); return;
  }
  const noteEl=e.target.closest('.pr-note');
  if(noteEl){
    const i=+noteEl.dataset.i, n=notes[i], p=gpos(e);
    pushUndo();
    const resz=e.target.classList.contains('rsz');
    if(!resz&&sel.has(i)&&sel.size>1){
      drag={mode:'group',c0:p.col,r0:p.row,
        base:[...sel].map(j=>({j,start:notes[j].start,pitch:notes[j].pitch}))};
    } else {
      if(!sel.has(i)) clearSel();
      drag=resz?{mode:'resize',i}
               :{mode:'move',i,offCol:p.col-n.start,offRow:p.row-rowOf(n.pitch)};
    }
    e.preventDefault(); return;
  }
  if(e.target.id==='prGrid'){
    clearSel();
    const p=gpos(e);
    if(p.col<0||p.col>=LOOP||p.row<0||p.row>=NROWS) return;
    pushUndo();
    const n={pitch:maybeSnap(pitchOf(p.row)),start:p.col,dur:Math.min(LOOP-p.col,Math.max(gridRes,defaultDur)),vel:defaultVel};
    notes.push(n); renderNotes();
    drag={mode:'resize',i:notes.length-1};
    audio(); playSynth(ctx,chanOf(curIns()).g,ctx.currentTime+0.02,n.pitch,0.22,0.8,1,SYNTHS[curIns().preset]);
    e.preventDefault();
  }
});
document.addEventListener('mousemove',e=>{
  if(marq){
    const r=$('#prGrid').getBoundingClientRect();
    marq.x1=e.clientX-r.left; marq.y1=e.clientY-r.top;
    const mv=$('#marq');
    mv.style.left=Math.min(marq.x0,marq.x1)+'px';
    mv.style.top=Math.min(marq.y0,marq.y1)+'px';
    mv.style.width=Math.abs(marq.x1-marq.x0)+'px';
    mv.style.height=Math.abs(marq.y1-marq.y0)+'px';
    return;
  }
  if(!drag) return;
  if(drag.mode==='group'){
    const p=gpos(e);
    const dc=p.col-drag.c0, dr=p.row-drag.r0;
    for(const b of drag.base){
      const nt=notes[b.j]; if(!nt) continue;
      nt.start=Math.min(LOOP-nt.dur,Math.max(0,b.start+dc));
      nt.pitch=Math.min(TOPNOTE,Math.max(BOTNOTE,b.pitch-dr));
      const el=$(`#prGrid .pr-note[data-i="${b.j}"]`);
      if(el){ el.style.left=(nt.start*COLW)+'px'; el.style.top=(rowOf(nt.pitch)*ROWH)+'px'; }
      const vb=$(`#prVel .vbar[data-i="${b.j}"]`);
      if(vb) vb.style.left=(nt.start*COLW+2)+'px';
    }
    return;
  }
  const n=notes[drag.i], p=gpos(e);
  if(drag.mode==='move'){
    const ns=Math.min(LOOP-n.dur,Math.max(0,p.col-drag.offCol));
    const nr=Math.min(NROWS-1,Math.max(0,p.row-drag.offRow));
    const np=maybeSnap(pitchOf(nr));
    if(np!==n.pitch){audio();playSynth(ctx,chanOf(curIns()).g,ctx.currentTime+0.01,np,0.12,0.5,1,SYNTHS[curIns().preset]);}
    n.start=ns; n.pitch=np;
  } else n.dur=Math.max(gridRes,Math.min(LOOP-n.start,p.col-n.start+gridRes));
  /* mise à jour ciblée : seul l'élément déplacé bouge, le rendu complet attend le relâchement */
  const el=$(`#prGrid .pr-note[data-i="${drag.i}"]`);
  if(el){
    el.style.left=(n.start*COLW)+'px';
    el.style.top=(rowOf(n.pitch)*ROWH)+'px';
    el.style.width=(n.dur*COLW-3)+'px';
  }
  const vb=$(`#prVel .vbar[data-i="${drag.i}"]`);
  if(vb) vb.style.left=(n.start*COLW+2)+'px';
});
document.addEventListener('mouseup',()=>{
  if(marq){
    const x0=Math.min(marq.x0,marq.x1), x1=Math.max(marq.x0,marq.x1);
    const y0=Math.min(marq.y0,marq.y1), y1=Math.max(marq.y0,marq.y1);
    sel=new Set();
    notes.forEach((n,i)=>{
      const nx0=n.start*COLW, nx1=nx0+n.dur*COLW;
      const ny0=rowOf(n.pitch)*ROWH, ny1=ny0+ROWH;
      if(nx0<x1&&nx1>x0&&ny0<y1&&ny1>y0) sel.add(i);
    });
    const mv=$('#marq'); if(mv) mv.remove();
    marq=null; renderNotes();
    if(sel.size) setStatus(sel.size+' note(s) sélectionnée(s) — glissez pour déplacer le groupe, Suppr pour effacer, ⌘C/⌘X/⌘V pour copier, couper, coller (même vers un autre pattern ou instrument).');
    return;
  }
  if(drag){
    const d=drag; drag=null;
    if(d.mode==='resize'&&notes[d.i]) defaultDur=notes[d.i].dur;   /* plume intelligente */
    renderNotes();
  }
});
/* Lane de vélocité : pointerdown sur une barre ou la lane, glisser pour régler/peindre */
{
  const lane=$('#prVel');
  const velAt=e=>{
    const r=lane.getBoundingClientRect();
    return Math.min(1,Math.max(0.05,1-(e.clientY-r.top)/r.height));
  };
  const apply=e=>{
    const r=lane.getBoundingClientRect();
    const col=Math.floor((e.clientX-r.left)/(COLW*gridRes))*gridRes;
    const v=velAt(e);
    let hit=false;
    notes.forEach((n,i)=>{
      if(n.start<col||n.start>=col+gridRes) return;
      n.vel=+v.toFixed(2); hit=true;
      const vb=$(`#prVel .vbar[data-i="${i}"]`);
      if(vb){ vb.style.height=Math.max(4,Math.round(n.vel*62))+'px'; vb.title=Math.round(n.vel*100)+' %'; }
      const el=$(`#prGrid .pr-note[data-i="${i}"]`);
      if(el){ el.style.opacity=(0.45+0.55*n.vel).toFixed(2); el.title='Vélocité : '+Math.round(n.vel*100)+' %'; }
    });
    if(hit) defaultVel=+v.toFixed(2);
  };
  lane.addEventListener('pointerdown',e=>{
    pushUndo();
    vpaint=true; lane.setPointerCapture(e.pointerId);
    apply(e); e.preventDefault();
  });
  lane.addEventListener('pointermove',e=>{ if(vpaint) apply(e); });
  lane.addEventListener('pointerup',()=>vpaint=false);
}
document.addEventListener('dblclick',e=>{
  const el=e.target.closest('.pr-note');
  if(el){pushUndo();notes.splice(+el.dataset.i,1);renderNotes();}
});
document.addEventListener('contextmenu',e=>{
  const el=e.target.closest('.pr-note');
  if(el){e.preventDefault();pushUndo();notes.splice(+el.dataset.i,1);renderNotes();}
});
