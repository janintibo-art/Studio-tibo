/* ---------- Clavier à l'écran : 2 octaves jouables à la souris ----------
   Passe par noteOn/noteOff : synthé en direct, saisie pas à pas ✎,
   et même l'enregistrement ● — tout fonctionne à la souris. */
let skBase=60;                     /* Do de départ (C4) */
const skHeld=new Map();            /* pointerId → pitch */
function buildScreenKeys(){
  const bar=$('#screenKeys'); if(!bar) return;
  bar.innerHTML='';
  const oct=document.createElement('div'); oct.className='sk-oct';
  const lo=document.createElement('button'); lo.className='pchip tool'; lo.textContent='−';
  const hi=document.createElement('button'); hi.className='pchip tool'; hi.textContent='+';
  const lab=document.createElement('span'); lab.className='plab';
  lab.textContent=dispNote(skBase%12)+(Math.floor(skBase/12)-1);
  lo.title='Octave plus grave'; hi.title='Octave plus aiguë';
  lo.onclick=()=>{ skBase=Math.max(BOTNOTE,skBase-12); buildScreenKeys(); };
  hi.onclick=()=>{ skBase=Math.min(TOPNOTE-24,skBase+12); buildScreenKeys(); };
  oct.append(lo,lab,hi);
  bar.append(oct);
  const zone=document.createElement('div'); zone.className='sk-zone';
  const BLACK=[1,3,6,8,10];
  let white=0;
  for(let p=skBase;p<=skBase+24;p++){
    if(!BLACK.includes(p%12)) white++;
  }
  let wi=0;
  for(let p=skBase;p<=skBase+24;p++){
    const k=document.createElement('div');
    const black=BLACK.includes(p%12);
    k.className='skey'+(black?' black':'');
    k.dataset.pitch=p;
    if(!black){
      k.style.left=(wi/white*100)+'%';
      k.style.width=(100/white)+'%';
      if(p%12===0){ const o=document.createElement('span'); o.className='oc'; o.textContent=dispNote(0)+(Math.floor(p/12)-1); k.append(o); }
      wi++;
    } else {
      k.style.left=((wi-0.32)/white*100)+'%';
      k.style.width=(100/white*0.64)+'%';
    }
    zone.append(k);
  }
  bar.append(zone);
}
function skVel(e,k){
  const r=k.getBoundingClientRect();
  const f=Math.min(1,Math.max(0,(e.clientY-r.top)/Math.max(1,r.height)));
  return +(0.35+0.65*f).toFixed(2);     /* haut = doux, bas = fort */
}
document.addEventListener('pointerdown',e=>{
  const k=e.target.closest&&e.target.closest('.skey');
  if(!k) return;
  e.preventDefault(); audio();
  const p=+k.dataset.pitch;
  skHeld.set(e.pointerId,p);
  noteOn(p,skVel(e,k));
  k.classList.add('on');
});
document.addEventListener('pointerover',e=>{
  if(!skHeld.has(e.pointerId)) return;
  const k=e.target.closest&&e.target.closest('.skey');
  if(!k) return;
  const p=+k.dataset.pitch, prev=skHeld.get(e.pointerId);
  if(p===prev) return;
  noteOff(prev);
  const pk=$('.skey[data-pitch="'+prev+'"]'); if(pk) pk.classList.remove('on');
  skHeld.set(e.pointerId,p);
  noteOn(p,skVel(e,k));
  k.classList.add('on');
});
document.addEventListener('pointerup',e=>{
  if(!skHeld.has(e.pointerId)) return;
  const p=skHeld.get(e.pointerId);
  skHeld.delete(e.pointerId);
  noteOff(p);
  const k=$('.skey[data-pitch="'+p+'"]'); if(k) k.classList.remove('on');
});
buildScreenKeys();
