/* ---------- Ordonnanceur (PAT / SONG) ---------- */
let playing=false, gstep=0, nextTime=0, timer=null, drawQueue=[], lastStep=-1, playT0=0;
const AHEAD=0.12, TICK=25, spStep=()=>60/bpm/4;
function schedulePattern(p,local,t,liveCtx,noise,dests,instDests,cut=1){
  const s16=local%NSTEPS;
  tracks.forEach((tr,i)=>{
    const v=VELS[p.steps[i][s16]];
    if(!v||!audible(tr)) return;
    const dest=dests?dests[i]:chanOf(tr).g;
    if(tr.kind==='sample'){ trigSample(liveCtx,dest,tr,t,v); }
    else if(tr.kind==='mach') trigMach(tr,liveCtx,noise,dest,t,v);
    else VOICES[tr.kind](liveCtx,noise,dest,t,v);
    duckTrig(liveCtx,i,t);          /* sidechain réelle : les Pump qui suivent cette piste plongent */
  });
  insts.forEach((ins,ii)=>{
    if(!audible(ins)||!p.melo[ii]) return;
    const dest=instDests?instDests[ii]:chanOf(ins).g;
    const c2=(ii===autoTarget)?cut:1;   /* l'automation du filtre cible l'instrument choisi */
    const P=SYNTHS[ins.preset]||SYNTHS.lead;
    if(!ins.arp||ins.arp==='off'){
      for(const n of p.melo[ii]) if(n.start>=local&&n.start<local+1)
        playSynth(liveCtx,dest,t+(n.start-local)*spStep(),n.pitch,n.dur*spStep(),n.vel,c2,P);
    } else {
      /* arpégiateur : à chaque pas, une note du groupe actif (accord ou note tenue) */
      const act=p.melo[ii].filter(n=>local>=n.start&&local<n.start+n.dur);
      if(act.length){
        let pool=[...new Set(act.map(n=>n.pitch))].sort((a,b)=>a-b);
        if(pool.length===1) pool=[pool[0],Math.min(TOPNOTE,pool[0]+12)];
        const k=local-Math.min(...act.map(n=>n.start));
        let idx;
        if(ins.arp==='up') idx=k%pool.length;
        else if(ins.arp==='down') idx=(pool.length-1)-(k%pool.length);
        else idx=(k*7+local*3)%pool.length;          /* aléatoire déterministe */
        playSynth(liveCtx,dest,t,pool[idx],spStep()*0.92,act[0].vel,c2,P);
      }
    }
  });
}
function scheduleStep(step,t){
  const local=step%LOOP;
  const ts=t+((step%2)?(swing/100)*spStep()*0.6:0);   // swing : retarde les contretemps
  const cut=applyAutoLive(step,t);
  if(mode==='pat'){
    if(local===0&&pendingPat!=null&&pendingPat!==curPat&&pendingPat<patterns.length){
      const np=pendingPat; pendingPat=null;
      selectPattern(np);
    }
    schedulePattern(patterns[curPat],local,ts,ctx,liveNoise,null,null,cut);
  } else {
    const slot=Math.floor(step/LOOP);
    for(const p of patterns) if(p.clips[slot]) schedulePattern(p,local,ts,ctx,liveNoise,null,null,cut);
  }
  if(metro&&local%4===0) tick(ctx,masterIn,t,local%16===0);
  drawQueue.push({step,t});
}
function songBounds(){
  if(mode!=='song'||typeof loopA==='undefined'||loopA==null||loopB==null) return null;
  return [loopA*LOOP,(loopB+1)*LOOP];
}
function schedule(){
  const total=mode==='pat'?LOOP:LOOP*songLen();
  const b=songBounds();
  while(nextTime<ctx.currentTime+AHEAD){
    scheduleStep(gstep,nextTime);
    nextTime+=spStep();
    gstep++;
    if(b){ if(gstep>=b[1]) gstep=b[0]; }
    else gstep%=total;
  }
}
function start(){
  audio();
  if(playing) return;
  playing=true; drawQueue=[]; lastStep=-1;
  { const b=songBounds(); gstep=b?b[0]:0; }
  captureLog=[];
  let t0=ctx.currentTime+0.06;
  if(recArm&&countIn){
    const N=NSTEPS*Math.max(1,countBars);
    for(let i=0;i<N;i+=4) tick(ctx,masterIn,t0+i*spStep(),i%NSTEPS===0);
    t0+=N*spStep();
    setStatus('Décompte : '+(N/4)+' temps… l\'enregistrement démarre au prochain « 1 ».');
  }
  nextTime=t0; playT0=t0;
  timer=setInterval(schedule,TICK);
  $('#btnPlay').classList.add('active');
  requestAnimationFrame(draw);
  { const b=songBounds();
    setStatus(mode==='pat'?`Lecture du pattern ${patterns[curPat].name}…`
      :b?`Lecture en boucle : sections ${loopA+1} → ${loopB+1} (clic droit sur un en-tête pour libérer).`
       :`Lecture du morceau (${songLen()*2} mesures)…`); }
}
function stop(){
  playing=false; clearInterval(timer);
  pendingPat=null; renderPatBars&&renderPatBars();
  recDirty=false;
  $('#btnPlay').classList.remove('active');
  $$('.cell.now').forEach(c=>c.classList.remove('now'));
  $$('.pl-slot.now').forEach(c=>c.classList.remove('now'));
  $('#prLine').style.display='none';
  $('#pos').textContent='1.1.1';
  /* rendre la main aux réglages manuels après l'automation */
  if(ctx){
    masterIn.gain.cancelScheduledValues(0); masterIn.gain.value=masterCh.gain;
    for(const ins of insts) if(ins._ch){
      ins._ch.sR.gain.cancelScheduledValues(0); ins._ch.sR.gain.value=ins.send.rev;
      ins._ch.sD.gain.cancelScheduledValues(0); ins._ch.sD.gain.value=ins.send.dly;
    }
  }
  setStatus('Stop.');
}
function setMode(m){
  mode=m;
  $('#modePat').classList.toggle('on',m==='pat');
  $('#modeSong').classList.toggle('on',m==='song');
  if(playing){ gstep=0; lastStep=-1; }
}
function draw(){
  if(!playing) return;
  const now=ctx.currentTime;
  let cur=lastStep;
  while(drawQueue.length&&drawQueue[0].t<=now) cur=drawQueue.shift().step;
  if(cur!==lastStep&&cur>=0){
    lastStep=cur;
    const local=cur%LOOP, s16=local%NSTEPS;
    $$('.cell.now').forEach(c=>c.classList.remove('now'));
    $$('#trackList .track').forEach(row=>row.querySelectorAll('.cell')[s16]?.classList.add('now'));
    const line=$('#prLine');
    line.style.display='block';
    line.style.left=(local*COLW)+'px';
    $$('.pl-slot.now').forEach(c=>c.classList.remove('now'));
    if(mode==='song'){
      const slot=Math.floor(cur/LOOP);
      $$(`.pl-slot[data-slot="${slot}"]`).forEach(c=>c.classList.add('now'));
    }
    $('#pos').textContent=`${Math.floor(cur/16)+1}.${Math.floor((cur%16)/4)+1}.${cur%4+1}`;
  }
  requestAnimationFrame(draw);
}
