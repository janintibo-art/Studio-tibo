/* ---------- Démo : deux patterns + arrangement ---------- */
(function demo(){
  const p1=patterns[0];
  p1.steps[0][0]=3; p1.steps[0][4]=3; p1.steps[0][8]=3; p1.steps[0][12]=3;
  p1.steps[1][4]=3; p1.steps[1][12]=3;
  for(let i=0;i<16;i+=2) p1.steps[2][i]=i%4===0?3:2;
  p1.steps[3][7]=2; p1.steps[3][15]=2;
  [[60,0,2],[63,2,2],[67,4,3],[63,8,2],[60,10,2],[58,12,3],[60,16,4],[55,20,3],[58,24,2],[60,26,5]]
    .forEach(([p,s,d])=>p1.melo[0].push({pitch:p,start:s,dur:d,vel:0.85}));
  const p2=newPattern('PAT 2');
  for(let i=0;i<16;i+=2) p2.steps[2][i]=2;
  p2.steps[1][4]=3; p2.steps[1][12]=3; p2.steps[3][14]=3;
  [[63,0,4],[67,4,4],[70,8,4],[67,12,4],[72,16,8],[70,24,4],[67,28,4]]
    .forEach(([p,s,d])=>p2.melo[0].push({pitch:p,start:s,dur:d,vel:0.8}));
  patterns.push(p2);
  p1.clips[0]=p1.clips[1]=p1.clips[2]=p1.clips[3]=true;
  p2.clips[2]=p2.clips[3]=true;
  /* Envois d'effets de la démo */
  insts[0].send={rev:0.3,dly:0.28};
  /* Second instrument : une basse qui suit le kick */
  addInst('Bass','bass');
  insts[1].gain=0.95;
  [[48,0,3],[48,4,3],[51,8,3],[50,12,3]]
    .forEach(([p,s,d])=>{p1.melo[1].push({pitch:p,start:s,dur:d,vel:0.9});
                         p1.melo[1].push({pitch:p,start:s+16,dur:d,vel:0.9});});
  [[51,0,6],[53,8,6],[48,16,6],[50,24,6]]
    .forEach(([p,s,d])=>p2.melo[1].push({pitch:p,start:s,dur:d,vel:0.85}));
  /* Automation de démonstration : le filtre s'ouvre sur la durée du morceau,
     le delay du synthé monte sur la seconde moitié */
  automation.cutoff=[{x:0,v:0.30},{x:2,v:0.55},{x:4,v:1}];
  automation.sdly=[{x:2,v:0.15},{x:4,v:0.45}];
  tracks[1].send.rev=0.22;   /* snare */
  tracks[3].send.rev=0.3;    /* clap  */
})();

selectPattern(0);
selectInst(0);
buildPianoRoll();
renderMixer();
renderAuto();
