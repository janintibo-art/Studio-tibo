/* ---------- Automation (mode SONG) ---------- */
const AUTOP={
  cutoff:{label:'Filtre',            color:'#3EC8FF', map:v=>0.25*Math.pow(8,v)},
  master:{label:'Volume master',     color:'#FFA03F', map:v=>v*1.25},
  srev  :{label:'Envoi REV',         color:'#FF3DAE', map:v=>v},
  sdly  :{label:'Envoi DLY',         color:'#B08CFF', map:v=>v},
};
let autoKey='cutoff', autoTarget=0, autoWriteOn=false, _awR=0;
function autoWrite(key,v){
  if(!autoWriteOn||!playing||mode!=='song') return;
  const pos=Math.min(PLSLOTS,Math.max(0,lastStep/LOOP));
  const q=Math.round(pos*4)/4;
  const pts=automation[key]; if(!pts) return;
  const val=+Math.min(1,Math.max(0,v)).toFixed(2);
  const near=pts.find(pt=>Math.abs(pt.x-q)<0.125);
  if(near) near.v=val; else pts.push({x:q,v:val});
  pts.sort((a,b)=>a.x-b.x);
  if(performance.now()>_awR){ _awR=performance.now()+120; renderAuto(); }
}
const autoLabel=k=>k==='master'?AUTOP[k].label
  :AUTOP[k].label+' — '+((insts[autoTarget]&&insts[autoTarget].name)||'Inst 1');
const autoHas=k=>automation[k]&&automation[k].length>0;
/* Valeur interpolée (0..1) à la position pos (en emplacements de playlist), ou null si pas de courbe */
function autoVal(k,pos){
  const pts=automation[k];
  if(!pts||!pts.length) return null;
  if(pos<=pts[0].x) return pts[0].v;
  if(pos>=pts[pts.length-1].x) return pts[pts.length-1].v;
  for(let i=0;i<pts.length-1;i++){
    const a=pts[i],b=pts[i+1];
    if(pos>=a.x&&pos<=b.x){
      const f=(b.x===a.x)?0:(pos-a.x)/(b.x-a.x);
      return a.v+(b.v-a.v)*f;
    }
  }
  return pts[pts.length-1].v;
}
/* Application en lecture : rampes sur les nœuds live, retourne le multiplicateur de cutoff */
function applyAutoLive(step,t){
  if(mode!=='song') return 1;
  const pos=step/LOOP;
  const m=autoVal('master',pos);
  if(m!=null&&masterIn) masterIn.gain.linearRampToValueAtTime(AUTOP.master.map(m),t);
  const ti=insts[autoTarget];
  if(ti&&ti._ch){
    const r=autoVal('srev',pos);
    if(r!=null) ti._ch.sR.gain.linearRampToValueAtTime(r,t);
    const d=autoVal('sdly',pos);
    if(d!=null) ti._ch.sD.gain.linearRampToValueAtTime(d,t);
  }
  const c=autoVal('cutoff',pos);
  return c==null?1:AUTOP.cutoff.map(c);
}

/* ----- Éditeur ----- */
const AW=()=>PLSLOTS*40, AH=200;
const SVGNS='http://www.w3.org/2000/svg';
function svgEl(tag,attrs){
  const e=document.createElementNS(SVGNS,tag);
  for(const k in attrs) e.setAttribute(k,attrs[k]);
  return e;
}
function renderAutoSel(){
  const box=$('#autoSel'); if(!box) return;
  box.innerHTML='';
  const wb=document.createElement('button');
  wb.className='pchip'+(autoWriteOn?' sel':'');
  if(autoWriteOn) wb.style.color='var(--red)';
  wb.textContent='● ÉCRIRE';
  wb.title='Armé : pendant la lecture du morceau (SONG), tournez REV/DLY de l\'instrument CIBLE ou le volume MASTER — la courbe s\'écrit sous la tête de lecture';
  wb.onclick=()=>{
    autoWriteOn=!autoWriteOn;
    if(autoWriteOn) pushUndo();
    renderAuto();
    setStatus(autoWriteOn
      ?'Écriture armée ● — lancez le morceau (SONG) et tournez les potards : chaque geste pose des points sous la tête de lecture (⌘Z pour tout reprendre).'
      :'Écriture désarmée.');
  };
  box.append(wb);
  box.innerHTML='';
  const lab=document.createElement('span'); lab.className='plab'; lab.textContent='PARAMÈTRE';
  box.append(lab);
  Object.entries(AUTOP).forEach(([k,p])=>{
    const b=document.createElement('button');
    b.className='pchip'+(k===autoKey?' sel':'');
    if(k===autoKey) b.style.color=p.color;
    const n=automation[k]?automation[k].length:0;
    b.innerHTML=`<span class="sw" style="background:${p.color}"></span>${autoLabel(k)}${n?` · ${n}`:''}`;
    b.onclick=()=>{autoKey=k;renderAuto();};
    box.append(b);
  });
}
function renderAutoTarget(){
  const bar=$('#autoTgt'); if(!bar) return;
  bar.innerHTML='';
  const lab=document.createElement('span'); lab.className='plab'; lab.textContent='CIBLE';
  bar.append(lab);
  insts.forEach((ins,i)=>{
    const b=document.createElement('button');
    b.className='pchip'+(i===autoTarget?' sel':'');
    if(i===autoTarget) b.style.color=instColor(i);
    b.innerHTML=`<span class="sw" style="background:${instColor(i)}"></span>${ins.name}`;
    b.title='Le filtre et les envois automatisés pilotent cet instrument';
    b.onclick=()=>{ autoTarget=i; renderAuto(); setStatus('Automation : filtre et envois pilotent désormais '+ins.name+'.'); };
    bar.append(b);
  });
}
function renderAuto(){
  renderAutoTarget();
  const svg=$('#autoSvg'); if(!svg) return;
  renderAutoSel();
  svg.setAttribute('viewBox',`0 0 ${AW()} ${AH}`);
  svg.innerHTML='';
  /* zone du morceau */
  svg.append(svgEl('rect',{x:0,y:0,width:songLen()*40,height:AH,fill:'rgba(255,255,255,.035)'}));
  /* grille */
  for(let s=0;s<=PLSLOTS;s++){
    svg.append(svgEl('line',{x1:s*40,y1:0,x2:s*40,y2:AH,
      stroke:s%4===0?'#2A2440':'#201B33','stroke-width':1}));
  }
  for(const f of [0.25,0.5,0.75]){
    svg.append(svgEl('line',{x1:0,y1:AH*f,x2:AW(),y2:AH*f,stroke:'#201B33','stroke-width':1,'stroke-dasharray':'3 5'}));
  }
  const poly=pts=>pts.map(p=>`${p.x*40},${(1-p.v)*AH}`).join(' ');
  /* fantômes des autres paramètres */
  Object.entries(AUTOP).forEach(([k,p])=>{
    if(k===autoKey||!autoHas(k)) return;
    svg.append(svgEl('polyline',{points:poly(automation[k]),fill:'none',
      stroke:p.color,'stroke-width':1.5,opacity:0.18}));
  });
  /* courbe sélectionnée */
  const pts=automation[autoKey], col=AUTOP[autoKey].color;
  if(pts.length){
    const ext=[{x:0,v:pts[0].v},...pts,{x:PLSLOTS,v:pts[pts.length-1].v}];
    svg.append(svgEl('polyline',{points:poly(ext),fill:'none',
      stroke:col,'stroke-width':2.5,'stroke-linejoin':'round',
      style:`filter:drop-shadow(0 0 4px ${col})`}));
    pts.forEach((p,i)=>{
      const c=svgEl('circle',{cx:p.x*40,cy:(1-p.v)*AH,r:6,fill:col,
        stroke:'#0B0A12','stroke-width':2,'class':'aut-pt','data-i':i});
      svg.append(c);
    });
  } else {
    svg.append(svgEl('line',{x1:0,y1:AH/2,x2:AW(),y2:AH/2,stroke:col,
      'stroke-width':1.5,'stroke-dasharray':'6 7',opacity:0.4}));
    const txt=svgEl('text',{x:AW()/2,y:AH/2-14,'text-anchor':'middle',
      fill:'#8A84A0','font-size':12,'font-family':'Space Grotesk'});
    txt.textContent='Cliquez, ou dessinez à main levée en glissant — la courbe pilotera « '+autoLabel(autoKey)+' »';
    svg.append(txt);
  }
}
/* interactions */
let aDrag=null;
function autoPos(e){
  const svg=$('#autoSvg'), r=svg.getBoundingClientRect();
  return {
    x:Math.min(PLSLOTS,Math.max(0,(e.clientX-r.left)/r.width*PLSLOTS)),
    v:Math.min(1,Math.max(0,1-(e.clientY-r.top)/r.height)),
  };
}
document.addEventListener('pointerdown',e=>{
  const svg=$('#autoSvg'); if(!svg||!svg.contains(e.target)) return;
  pushUndo();
  const p=autoPos(e);
  if(e.target.classList&&e.target.classList.contains('aut-pt')){
    aDrag=automation[autoKey][+e.target.getAttribute('data-i')];
  } else {
    /* zone vide : dessin à main levée — chaque mouvement pose/ajuste un point au quart de slot */
    aDrag={paint:true};
    paintAt(p);
  }
  e.preventDefault();
});
function paintAt(p){
  const q=Math.min(PLSLOTS,Math.round(p.x*4)/4);   /* quantisé au 1/4 de slot */
  const pts=automation[autoKey];
  const near=pts.find(pt=>Math.abs(pt.x-q)<0.125);
  if(near) near.v=+p.v.toFixed(2);
  else pts.push({x:q,v:+p.v.toFixed(2)});
  pts.sort((a,b)=>a.x-b.x);
  renderAuto();
}
document.addEventListener('pointermove',e=>{
  if(!aDrag) return;
  const p=autoPos(e);
  if(aDrag.paint){ paintAt(p); return; }
  aDrag.x=+p.x.toFixed(2); aDrag.v=+p.v.toFixed(2);
  automation[autoKey].sort((a,b)=>a.x-b.x);
  renderAuto();
});
document.addEventListener('pointerup',()=>aDrag=null);
document.addEventListener('dblclick',e=>{
  if(e.target.classList&&e.target.classList.contains('aut-pt')){
    pushUndo();
    automation[autoKey].splice(+e.target.getAttribute('data-i'),1);
    renderAuto();
  }
});
