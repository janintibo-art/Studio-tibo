/* ---------- Annuler / Rétablir ---------- */
const undoStack=[], redoStack=[], UNDO_MAX=60;
function snapState(){
  return JSON.stringify({
    bpm, swing, loop:LOOP, autoTarget, songMarks:[...songMarks], curPat, curInst, automation, patterns,
    insts:insts.map(s=>({name:s.name,preset:s.preset,arp:s.arp||'off',mute:s.mute,solo:s.solo,gain:s.gain,pan:s.pan,eq:s.eq,send:s.send,fxIns:s.fxIns})),
    tracks:tracks.map(t=>({name:t.name,kind:t.kind,mach:t.mach,mute:t.mute,solo:t.solo,
      gain:t.gain,pan:t.pan,eq:t.eq,send:t.send,tid:t.tid,fxIns:t.fxIns,spd:t.spd,pitch:t.pitch,keep:t.keep,off:t.off})),
  });
}
function pushUndo(){
  undoStack.push(snapState());
  if(undoStack.length>UNDO_MAX) undoStack.shift();
  redoStack.length=0;
}
function clearUndo(){ undoStack.length=0; redoStack.length=0; }
function restoreState(s){
  const d=JSON.parse(s);
  if(d.bpm){ bpm=d.bpm; $('#bpm').value=bpm; }
  if(d.swing!=null){ swing=d.swing; $('#swing').value=swing; }
  if([16,32,64].includes(d.loop)&&d.loop!==LOOP){ LOOP=d.loop; buildPianoRoll(); }
  if(d.autoTarget!=null) autoTarget=d.autoTarget;
  if(d.songMarks) songMarks=[...d.songMarks];
  applyFxLive();
  tracks=d.tracks.map(t=>normCh({...t,
    buffer:(t.tid!=null)?(bufReg[t.tid]||null):null,_ch:null}));
  patterns=d.patterns.map(p=>({...p,
    clips:(p.clips&&p.clips.length===PLSLOTS)?p.clips:Array(PLSLOTS).fill(false)}));
  Object.keys(automation).forEach(k=>automation[k]=(d.automation&&d.automation[k])||[]);
  insts=d.insts.map(s=>normCh({...s,_ch:null}));
  patterns.forEach(p=>{p.melo=p.melo||[];while(p.melo.length<insts.length)p.melo.push([]);p.melo.length=insts.length;});
  curPat=Math.max(0,Math.min(d.curPat||0,patterns.length-1));
  curInst=Math.max(0,Math.min(d.curInst||0,insts.length-1));
  selectPattern(curPat);
  selectInst(curInst);
  renderMixer(); renderAuto(); updateStats();
}
function doUndo(){
  if(!undoStack.length){ setStatus('Rien à annuler.'); return; }
  redoStack.push(snapState());
  restoreState(undoStack.pop());
  setStatus('Annulé.');
}
function doRedo(){
  if(!redoStack.length){ setStatus('Rien à rétablir.'); return; }
  undoStack.push(snapState());
  restoreState(redoStack.pop());
  setStatus('Rétabli.');
}
document.addEventListener('keydown',e=>{
  if(e.target.tagName==='INPUT') return;
  const z=e.key.toLowerCase()==='z', y=e.key.toLowerCase()==='y';
  if((e.ctrlKey||e.metaKey)&&z&&!e.shiftKey){ e.preventDefault(); doUndo(); }
  else if((e.ctrlKey||e.metaKey)&&(y||(z&&e.shiftKey))){ e.preventDefault(); doRedo(); }
});
$('#mUndo').onclick=doUndo;
$('#mRedo').onclick=doRedo;
