/* ---------- Enregistrer / Enregistrer sous : ⌘S écrase le même fichier ---------- */
let saveHandle=null, tauriSavePath=null;
function resetSaveTarget(){ saveHandle=null; tauriSavePath=null; }
async function writeProjectFile(blob,extra){
  extra=extra||'';
  /* application de bureau : chemin mémorisé, écrasé silencieusement ensuite */
  if(isTauri&&window.__TAURI__.dialog&&window.__TAURI__.fs){
    try{
      if(!tauriSavePath){
        tauriSavePath=await window.__TAURI__.dialog.save({
          defaultPath:projSlug()+'.tibo',
          filters:[{name:'Projet STUDIO TIBO',extensions:['tibo']}],
        });
        if(!tauriSavePath){ setStatus('Enregistrement annulé.'); return false; }
      }
      await window.__TAURI__.fs.writeFile(tauriSavePath,new Uint8Array(await blob.arrayBuffer()));
      setStatus('Enregistré : '+tauriSavePath+extra+' — ⌘S écrasera ce fichier, « Enregistrer sous… » pour changer.');
      return true;
    }catch(e){ /* repli ci-dessous */ }
  }
  /* navigateur moderne : File System Access (Chrome/Edge) */
  if(typeof window!=='undefined'&&window.showSaveFilePicker){
    try{
      if(!saveHandle){
        saveHandle=await window.showSaveFilePicker({
          suggestedName:projSlug()+'.tibo',
          types:[{description:'Projet STUDIO TIBO',accept:{'application/zip':['.tibo']}}],
        });
      }
      const w=await saveHandle.createWritable();
      await w.write(blob); await w.close();
      setStatus('Enregistré : '+saveHandle.name+extra+' — ⌘S écrasera ce fichier, « Enregistrer sous… » pour changer.');
      return true;
    }catch(e){
      if(e&&e.name==='AbortError'){ setStatus('Enregistrement annulé.'); return false; }
      saveHandle=null;   /* permission perdue : repli téléchargement */
    }
  }
  /* repli universel : téléchargement */
  await dlBlob(blob,projSlug()+'.tibo');
  return true;
}
