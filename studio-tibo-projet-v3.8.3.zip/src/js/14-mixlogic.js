/* ---------- Mute / solo ---------- */
const anySolo=()=>tracks.some(t=>t.solo)||insts.some(s=>s.solo);
const audible=ch=>!ch.mute&&(!anySolo()||ch.solo);
