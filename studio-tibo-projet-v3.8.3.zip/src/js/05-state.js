/* ---------- État du projet ---------- */
const NSTEPS=16, PLSLOTS=16, VELS=[0,0.33,0.66,1];
let LOOP=32;                   // pas par pattern : 16 (1 mes), 32 (2 mes), 64 (4 mes)
let pendingPat=null;           // pattern en file d'attente (bascule au début de la boucle)
let projName='Mon morceau';
let songMarks=Array(16).fill('');   /* noms des sections de la playlist (Intro, Drop…) */
const projSlug=()=>projName.trim().toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'')||'studio-tibo';
let tracks=[
  {name:'Kick',  kind:'kick',  mute:false, solo:false, gain:1.0,  pan:0},
  {name:'Snare', kind:'snare', mute:false, solo:false, gain:0.9,  pan:0},
  {name:'Hat',   kind:'hat',   mute:false, solo:false, gain:0.8,  pan:0.15},
  {name:'Clap',  kind:'clap',  mute:false, solo:false, gain:0.85, pan:-0.1},
];
const instColor=i=>`hsl(${(i*73+185)%360} 80% 64%)`;
let insts=[], curInst=0;
const curIns=()=>insts[curInst];
const masterCh={name:'Master', gain:0.85};
const fx={rev:{ret:0.9,size:2.2},dly:{ret:0.85,div:3,fb:0.38}};
const normCh=o=>{o.eq=o.eq||{lo:0,mid:0,hi:0};o.send=o.send||{rev:0,dly:0};o.fxIns=Array.isArray(o.fxIns)?o.fxIns.slice(0,4):[];while(o.fxIns.length<4)o.fxIns.push(null);return o;};
tracks.forEach(normCh);
insts=[normCh({name:'Lead 1',preset:'lead',mute:false,solo:false,gain:0.9,pan:0})];
const emptySteps=()=>tracks.map(()=>Array(NSTEPS).fill(0));
const newPattern=name=>({name, steps:emptySteps(), melo:insts.map(()=>[]), clips:Array(PLSLOTS).fill(false)});
let patterns=[newPattern('PAT 1')];
let curPat=0;
let notes=patterns[0].melo[0];   // alias : notes du pattern courant, instrument courant
let bpm=120, mode='pat';
let swing=0, metro=false;
let gridRes=1;                 // 1 = pas (1/16), 0.5 = demi-pas (1/32), 0.25 = quart (1/64)
const automation={cutoff:[],master:[],srev:[],sdly:[]};   // courbes {x:0..16, v:0..1}
const bufReg={}; let tidSeq=0;                            // registre des buffers (pour annuler/rétablir)
const patColor=i=>`hsl(${(i*47+28)%360} 72% 62%)`;
const songLen=()=>{
  let last=-1;
  for(const p of patterns) p.clips.forEach((c,i)=>{if(c&&i>last)last=i;});
  return Math.max(1,last+1);
};
function selectPattern(i){
  curPat=Math.max(0,Math.min(patterns.length-1,i));
  notes=patterns[curPat].melo[curInst]||(patterns[curPat].melo[curInst]=[]);
  if(typeof clearSel==='function') clearSel(false);
  $('#patLed').textContent='P'+(curPat+1);
  renderPatBars(); renderTracks(); renderNotes(); renderPlaylist();
}
