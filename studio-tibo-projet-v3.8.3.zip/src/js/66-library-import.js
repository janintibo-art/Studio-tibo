/* ---------- Bibliothèque : import en lot (fichiers + glisser-déposer) ---------- */
function addSampleTrack(name,buf){
  const t=normCh({name:name.slice(0,22),kind:'sample',buffer:buf,tid:++tidSeq,
    mute:false,solo:false,gain:0.9,pan:0});
  bufReg[t.tid]=buf;
  tracks.push(t);
  patterns.forEach(p=>p.steps.push(Array(NSTEPS).fill(0)));
}
async function libImport(files){
  pushUndo();
  let nA=0,nM=0,nE=0;
  for(const f of files){
    try{
      if(/\.(mid|midi)$/i.test(f.name)){
        const {notes:raw,div}=parseMidi(await f.arrayBuffer());
        const arr=midiToNotes(raw,div);
        if(!arr.length){nE++;continue;}
        const pat=newPattern(f.name.replace(/\.[^.]+$/,'').slice(0,14)||('PAT '+(patterns.length+1)));
        pat.melo[Math.min(curInst,insts.length-1)]=arr;
        patterns.push(pat); nM++;
      } else {
        audio();
        const buf=await ctx.decodeAudioData(await f.arrayBuffer());
        addSampleTrack(f.name.replace(/\.[^.]+$/,''),buf); nA++;
      }
    }catch(err){ nE++; }
  }
  renderTracks(); renderMixer(); renderPatBars(); renderPlaylist(); updateStats();
  let msg=`Import terminé : ${nA} sample(s) → pistes, ${nM} MIDI → patterns.`;
  if(nE) msg+=` ${nE} fichier(s) non reconnu(s).`;
  setStatus(msg);
}
$('#fileMulti').addEventListener('change',e=>{libImport([...e.target.files]);e.target.value='';});
$('#mMulti').onclick=()=>$('#fileMulti').click();
{
  const dz=$('#libDrop');
  dz.onclick=()=>$('#fileMulti').click();
  dz.ondragover=e=>{e.preventDefault();dz.classList.add('over');};
  dz.ondragleave=()=>dz.classList.remove('over');
  dz.ondrop=e=>{e.preventDefault();dz.classList.remove('over');libImport([...e.dataTransfer.files]);};
}
