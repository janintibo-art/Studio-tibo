/* ---------- Vitesse & hauteur des samples sans détérioration ----------
   Time-stretch granulaire (OLA, fenêtre de Hann, grains ~46 ms, recouvrement 50 %).
   Même traitement en lecture live et à l'export (buffers indépendants du contexte). */
function stretchBuffer(c,buf,factor){
  if(Math.abs(factor-1)<0.002) return buf;
  const sr=buf.sampleRate, chs=buf.numberOfChannels;
  const grain=Math.round(sr*0.046)&~1, hopIn=grain>>1;
  const hopOut=Math.max(1,Math.round(hopIn*factor));
  const outLen=Math.max(grain,Math.round(buf.length*factor));
  const out=c.createBuffer(chs,outLen,sr);
  const win=new Float32Array(grain);
  for(let i=0;i<grain;i++) win[i]=0.5-0.5*Math.cos(2*Math.PI*i/grain);
  const norm=hopOut/hopIn;          /* compense le recouvrement variable */
  for(let ch=0;ch<chs;ch++){
    const src=buf.getChannelData(ch), dst=out.getChannelData(ch);
    for(let oi=0,ii=0; oi+grain<=outLen; oi+=hopOut, ii+=hopIn){
      const base=Math.max(0,Math.min(ii,src.length-grain));
      for(let k=0;k<grain;k++) dst[oi+k]+=src[base+k]*win[k]*norm;
    }
  }
  return out;
}
const _stretchCache={};
function sampleFor(c,tr){
  const spd=tr.spd||1, pitch=tr.pitch||0, keep=!!tr.keep;
  const rate=Math.pow(2,pitch/12)*(keep?1:spd);
  const f=rate/spd;
  if(Math.abs(f-1)<0.002||!tr.buffer) return {buf:tr.buffer,rate};
  const key=tr.tid+':'+f.toFixed(3);
  if(!_stretchCache[key]) _stretchCache[key]=stretchBuffer(c,tr.buffer,f);
  return {buf:_stretchCache[key],rate};
}
function trigSample(c,dest,tr,t,v){
  if(!tr.buffer) return;
  const r=sampleFor(c,tr);
  playSample(c,dest,r.buf,t,v,r.rate,(tr.off||0)/1000);
}
