/* ---------- Plugins (inserts par tranche, format ouvert .js) ---------- */
const PLUGINS={};
function registerPlugin(desc){
  if(!desc||!desc.id||!desc.create) throw 'plugin invalide : id et create() requis';
  desc.params=desc.params||[];
  PLUGINS[desc.id]=desc;
  return desc;
}

/* ===== 4 effets intégrés (nœuds Web Audio purs : identiques live et à l'export) ===== */
registerPlugin({
  id:'drive', name:'Drive', desc:'Saturation chaleureuse (waveshaper tanh).',
  params:[{key:'amount',label:'DRIVE',min:0,max:1,def:0.4,fmt:v=>Math.round(v*100)+' %'}],
  create(c){
    const inp=c.createGain(), ws=c.createWaveShaper(), out=c.createGain();
    out.gain.value=0.8;
    inp.connect(ws); ws.connect(out);
    const curve=a=>{
      const n=1024, cu=new Float32Array(n), k=1+a*30;
      for(let i=0;i<n;i++){const x=i/(n-1)*2-1; cu[i]=Math.tanh(k*x)/Math.tanh(k);}
      return cu;
    };
    ws.curve=curve(0.4);
    return {input:inp,output:out,set(k,v){ if(k==='amount') ws.curve=curve(v); }};
  }
});
registerPlugin({
  id:'crush', name:'Bitcrusher', desc:'Réduction de bits lo-fi (quantisation).',
  params:[{key:'bits',label:'BITS',min:2,max:12,def:6,fmt:v=>Math.round(v)+' bits'}],
  create(c){
    const inp=c.createGain(), ws=c.createWaveShaper(), out=c.createGain();
    inp.connect(ws); ws.connect(out);
    const curve=b=>{
      const n=4096, cu=new Float32Array(n), lv=Math.pow(2,Math.round(b));
      for(let i=0;i<n;i++){const x=i/(n-1)*2-1; cu[i]=Math.round(x*lv)/lv;}
      return cu;
    };
    ws.curve=curve(6);
    return {input:inp,output:out,set(k,v){ if(k==='bits') ws.curve=curve(v); }};
  }
});
registerPlugin({
  id:'chorus', name:'Chorus', desc:'Doublage modulé, élargit et épaissit.',
  params:[
    {key:'rate', label:'RATE', min:0.1,max:6,  def:1.2,fmt:v=>v.toFixed(1)+' Hz'},
    {key:'depth',label:'DEPTH',min:0,  max:1,  def:0.5,fmt:v=>Math.round(v*100)+' %'},
    {key:'mix',  label:'MIX',  min:0,  max:1,  def:0.5,fmt:v=>Math.round(v*100)+' %'},
  ],
  create(c){
    const inp=c.createGain(), out=c.createGain();
    const dry=c.createGain(), wet=c.createGain();
    const dl=c.createDelay(0.06); dl.delayTime.value=0.018;
    const lfo=c.createOscillator(), lg=c.createGain();
    lfo.frequency.value=1.2; lg.gain.value=0.004;
    lfo.connect(lg); lg.connect(dl.delayTime); lfo.start();
    inp.connect(dry); dry.connect(out);
    inp.connect(dl); dl.connect(wet); wet.connect(out);
    dry.gain.value=0.5; wet.gain.value=0.5;
    return {input:inp,output:out,set(k,v){
      if(k==='rate') lfo.frequency.value=v;
      if(k==='depth') lg.gain.value=v*0.008;
      if(k==='mix'){ wet.gain.value=v; dry.gain.value=1-v*0.5; }
    }};
  }
});
registerPlugin({
  id:'trem', name:'Tremolo', desc:'Volume pulsé par un LFO.',
  params:[
    {key:'rate', label:'RATE', min:0.5,max:14,def:5,  fmt:v=>v.toFixed(1)+' Hz'},
    {key:'depth',label:'DEPTH',min:0,  max:1, def:0.6,fmt:v=>Math.round(v*100)+' %'},
  ],
  create(c){
    const inp=c.createGain(), g=c.createGain(), out=c.createGain();
    const lfo=c.createOscillator(), lg=c.createGain();
    lfo.frequency.value=5; g.gain.value=0.7; lg.gain.value=0.3;
    lfo.connect(lg); lg.connect(g.gain); lfo.start();
    inp.connect(g); g.connect(out);
    return {input:inp,output:out,set(k,v){
      if(k==='rate') lfo.frequency.value=v;
      if(k==='depth'){ g.gain.value=1-v*0.5; lg.gain.value=v*0.5; }
    }};
  }
});
registerPlugin({
  id:'phaser', name:'Phaser', desc:'Quatre allpass en cascade balayés par un LFO — le tournoiement classique.',
  params:[
    {key:'rate', label:'RATE', min:0.05,max:4,def:0.5,fmt:v=>v.toFixed(2)+' Hz'},
    {key:'depth',label:'DEPTH',min:0,   max:1,def:0.7,fmt:v=>Math.round(v*100)+' %'},
  ],
  create(c){
    const inp=c.createGain(), out=c.createGain(), dry=c.createGain(), wet=c.createGain();
    let node=inp; const aps=[];
    for(let i=0;i<4;i++){
      const ap=c.createBiquadFilter(); ap.type='allpass'; ap.frequency.value=700; ap.Q.value=0.6;
      node.connect(ap); node=ap; aps.push(ap);
    }
    node.connect(wet); wet.connect(out); inp.connect(dry); dry.connect(out);
    dry.gain.value=0.55; wet.gain.value=0.55;
    const lfo=c.createOscillator(), lg=c.createGain();
    lfo.frequency.value=0.5; lg.gain.value=0.7*550;
    lfo.connect(lg); aps.forEach(ap=>lg.connect(ap.frequency)); lfo.start();
    return {input:inp,output:out,set(k,v){
      if(k==='rate') lfo.frequency.value=v;
      if(k==='depth') lg.gain.value=v*550;
    }};
  }
});
registerPlugin({
  id:'flanger', name:'Flanger', desc:'Délai très court modulé avec réinjection — l\'effet « avion ».',
  params:[
    {key:'rate',label:'RATE',min:0.05,max:2, def:0.25,fmt:v=>v.toFixed(2)+' Hz'},
    {key:'fb',  label:'FB',  min:0,   max:0.85,def:0.45,fmt:v=>Math.round(v*100)+' %'},
    {key:'mix', label:'MIX', min:0,   max:1, def:0.5, fmt:v=>Math.round(v*100)+' %'},
  ],
  create(c){
    const inp=c.createGain(), out=c.createGain(), dry=c.createGain(), wet=c.createGain();
    const dl=c.createDelay(0.03); dl.delayTime.value=0.0035;
    const fb=c.createGain(); fb.gain.value=0.45;
    const lfo=c.createOscillator(), lg=c.createGain();
    lfo.frequency.value=0.25; lg.gain.value=0.0022;
    lfo.connect(lg); lg.connect(dl.delayTime); lfo.start();
    inp.connect(dry); dry.connect(out);
    inp.connect(dl); dl.connect(wet); wet.connect(out);
    dl.connect(fb); fb.connect(dl);
    dry.gain.value=0.5; wet.gain.value=0.5;
    return {input:inp,output:out,set(k,v){
      if(k==='rate') lfo.frequency.value=v;
      if(k==='fb') fb.gain.value=v;
      if(k==='mix'){ wet.gain.value=v; dry.gain.value=1-v*0.5; }
    }};
  }
});
registerPlugin({
  id:'wah', name:'Auto-Wah', desc:'Passe-bas résonant balayé en rythme — funk garanti.',
  params:[
    {key:'rate', label:'RATE', min:0.1,max:8, def:2,  fmt:v=>v.toFixed(1)+' Hz'},
    {key:'range',label:'RANGE',min:0,  max:1, def:0.7,fmt:v=>Math.round(v*100)+' %'},
    {key:'res',  label:'RES',  min:0.5,max:14,def:6,  fmt:v=>v.toFixed(1)},
  ],
  create(c){
    const f=c.createBiquadFilter();
    f.type='lowpass'; f.frequency.value=420; f.Q.value=6;
    const lfo=c.createOscillator(), lg=c.createGain();
    lfo.frequency.value=2; lg.gain.value=0.7*1300;
    lfo.connect(lg); lg.connect(f.frequency); lfo.start();
    return {input:f,output:f,set(k,v){
      if(k==='rate') lfo.frequency.value=v;
      if(k==='range') lg.gain.value=v*1300;
      if(k==='res') f.Q.value=v;
    }};
  }
});
registerPlugin({
  id:'filter', name:'Filtre', desc:'Filtre multi-mode statique : passe-bas, passe-bande ou passe-haut.',
  params:[
    {key:'type',label:'TYPE',min:0,  max:2,   def:0,  fmt:v=>['LP','BP','HP'][Math.round(v)]},
    {key:'freq',label:'FREQ',min:80, max:8000,def:1200,fmt:v=>Math.round(v)+' Hz'},
    {key:'res', label:'RES', min:0.3,max:14,  def:1.5,fmt:v=>v.toFixed(1)},
  ],
  create(c){
    const f=c.createBiquadFilter();
    f.type='lowpass'; f.frequency.value=1200; f.Q.value=1.5;
    return {input:f,output:f,set(k,v){
      if(k==='type') f.type=['lowpass','bandpass','highpass'][Math.round(v)];
      if(k==='freq') f.frequency.value=v;
      if(k==='res') f.Q.value=v;
    }};
  }
});
registerPlugin({
  id:'comp', name:'Compresseur', desc:'Resserre la dynamique et gagne en présence.',
  params:[
    {key:'thr',  label:'THR',  min:-60,max:0, def:-24,fmt:v=>Math.round(v)+' dB'},
    {key:'ratio',label:'RATIO',min:1,  max:20,def:4,  fmt:v=>v.toFixed(1)+':1'},
    {key:'gain', label:'GAIN', min:0,  max:2, def:1.2,fmt:v=>Math.round(v*100)+' %'},
  ],
  create(c){
    const comp=c.createDynamicsCompressor(), mk=c.createGain();
    comp.threshold.value=-24; comp.ratio.value=4;
    comp.attack.value=0.005; comp.release.value=0.12; comp.knee.value=12;
    mk.gain.value=1.2;
    comp.connect(mk);
    return {input:comp,output:mk,set(k,v){
      if(k==='thr') comp.threshold.value=v;
      if(k==='ratio') comp.ratio.value=v;
      if(k==='gain') mk.gain.value=v;
    }};
  }
});
/* Sidechain réelle : registre des cibles de pompage, par contexte audio
   (le live et l'export ont chacun le leur — mêmes réglages, même rendu). */
const scReg=new WeakMap();
function scAdd(c,entry){
  let s=scReg.get(c);
  if(!s){ s=new Set(); scReg.set(c,s); }
  s.add(entry);
}
function duckTrig(c,ti,t){
  const s=scReg.get(c); if(!s) return;
  for(const e of s){
    if(!e.on||e.src!==ti) continue;
    try{
      const gp=e.gp;
      if(gp.cancelAndHoldAtTime) gp.cancelAndHoldAtTime(t);
      else gp.cancelScheduledValues(t);
      gp.setValueAtTime(1,t);
      gp.linearRampToValueAtTime(Math.max(0.02,1-e.amt),t+0.006);
      gp.linearRampToValueAtTime(1,t+0.006+e.rel);
    }catch(err){}
  }
}
registerPlugin({
  id:'pump', name:'Pump', desc:'Pompage : par l\'horloge (SOURCE = Horloge), ou déclenché par une vraie piste — le mix plonge à chaque coup de la SOURCE.',
  params:[
    {key:'src', label:'SOURCE',min:0,  max:24,def:0, fmt:v=>{const s=Math.round(v);return s<1?'Horloge':(tracks[s-1]?tracks[s-1].name:'Piste '+s);}},
    {key:'rate',label:'RATE',min:0.5,max:8,def:2,  fmt:v=>v.toFixed(1)+' Hz'},
    {key:'amt', label:'AMT', min:0,  max:1,def:0.6,fmt:v=>Math.round(v*100)+' %'},
    {key:'rel', label:'REL', min:0.05,max:0.8,def:0.25,fmt:v=>Math.round(v*1000)+' ms'},
  ],
  create(c){
    const inp=c.createGain(), g=c.createGain(), out=c.createGain();
    const lfo=c.createOscillator(), lg=c.createGain();
    lfo.type='sawtooth';            /* rampe montante : plongeon au début du cycle */
    lfo.frequency.value=2;
    g.gain.value=1-0.6/2; lg.gain.value=0.6/2;
    lfo.connect(lg); lg.connect(g.gain); lfo.start();
    inp.connect(g); g.connect(out);
    const entry={gp:g.gain,amt:0.6,rel:0.25,src:-1,on:false};
    return {input:inp,output:out,set(k,v){
      if(k==='rate') lfo.frequency.value=v;
      if(k==='rel') entry.rel=v;
      if(k==='amt'){
        entry.amt=v;
        if(!entry.on){ g.gain.value=1-v/2; lg.gain.value=v/2; }
      }
      if(k==='src'){
        const s=Math.round(v);
        if(s>=1){
          entry.src=s-1;
          if(!entry.on){
            entry.on=true;
            try{ lg.disconnect(); }catch(e){}
            g.gain.value=1;
            scAdd(c,entry);
          }
        } else if(entry.on){
          entry.on=false; entry.src=-1;
          try{ lg.connect(g.gain); }catch(e){}
          g.gain.value=1-entry.amt/2; lg.gain.value=entry.amt/2;
        }
      }
    }};
  }
});
registerPlugin({
  id:'width', name:'Largeur stéréo', desc:'Élargit (ou resserre) l\'image stéréo par matrice mid/side.',
  params:[{key:'w',label:'WIDTH',min:0,max:2,def:1.4,fmt:v=>Math.round(v*100)+' %'}],
  create(c){
    const inp=c.createGain(), out=c.createGain();
    inp.channelCount=2; inp.channelCountMode='explicit';   /* mono → stéréo dupliquée */
    const sp=c.createChannelSplitter(2), mg=c.createChannelMerger(2);
    const ll=c.createGain(), lr=c.createGain(), rl=c.createGain(), rr=c.createGain();
    inp.connect(sp);
    sp.connect(ll,0); sp.connect(rl,0); sp.connect(lr,1); sp.connect(rr,1);
    ll.connect(mg,0,0); lr.connect(mg,0,0); rl.connect(mg,0,1); rr.connect(mg,0,1);
    mg.connect(out);
    const apply=w=>{ const a=(1+w)/2, b=(1-w)/2; ll.gain.value=a; rr.gain.value=a; lr.gain.value=b; rl.gain.value=b; };
    apply(1.4);
    return {input:inp,output:out,set(k,v){ if(k==='w') apply(v); }};
  }
});

/* ===== Chaîne d'inserts : insérée entre l'EQ et le panoramique ===== */
function buildInserts(c,fromNode,fxIns){
  let node=fromNode;
  const inserts=[];
  (fxIns||[]).forEach(slot=>{
    if(!slot||slot.byp||!PLUGINS[slot.id]){ inserts.push(null); return; }
    const desc=PLUGINS[slot.id];
    try{
      const inst=desc.create(c);
      for(const p of desc.params)
        inst.set(p.key,(slot.params&&slot.params[p.key]!=null)?slot.params[p.key]:p.def);
      node.connect(inst.input);
      node=inst.output;
      inserts.push(inst);
    }catch(e){ inserts.push(null); }
  });
  return {last:node,inserts};
}
function rebuildChan(obj){ obj._ch=null; }   /* recréé au prochain événement par chanOf */

/* ===== Éditeur d'insert (modale) ===== */
let insEdit=null, insDirty=false;
function openInsEditor(obj,slot){
  insEdit={obj,slot}; insDirty=false;
  $('#insTitle').textContent=`Insert ${slot+1} — ${obj.name}`;
  renderInsEditor();
  $('#insBg').classList.add('open');
}
function renderInsEditor(){
  const {obj,slot}=insEdit;
  const cur=obj.fxIns[slot];
  const list=$('#insList'); list.innerHTML='';
  const none=document.createElement('button');
  none.className='pchip'+(cur?'':' sel'); none.textContent='— Aucun';
  none.onclick=()=>{ pushUndo(); obj.fxIns[slot]=null; rebuildChan(obj); renderInsEditor(); renderMixer(); };
  list.append(none);
  Object.values(PLUGINS).forEach(d=>{
    const b=document.createElement('button');
    b.className='pchip'+(cur&&cur.id===d.id?' sel':'');
    if(cur&&cur.id===d.id) b.style.color='var(--amber)';
    b.textContent=d.name;
    b.onclick=()=>{
      pushUndo();
      const params={}; d.params.forEach(p=>params[p.key]=p.def);
      obj.fxIns[slot]={id:d.id,params};
      rebuildChan(obj); renderInsEditor(); renderMixer();
    };
    list.append(b);
  });
  if(cur){
    const by=document.createElement('button');
    by.className='pchip'+(cur.byp?' sel':'');
    if(cur.byp) by.style.color='var(--red)';
    by.innerHTML='<span class="sw" style="background:var(--red)"></span>'+(cur.byp?'Contourné (bypass)':'Contourner');
    by.title='Couper l\'effet sans le retirer — clic droit sur le slot dans le mixeur fait pareil';
    by.onclick=()=>{ pushUndo(); cur.byp=!cur.byp; rebuildChan(obj); renderInsEditor(); renderMixer(); };
    list.append(by);
  }
  const zone=$('#insParams'); zone.innerHTML='';
  if(cur&&PLUGINS[cur.id]){
    const d=PLUGINS[cur.id];
    const di=document.createElement('p'); di.style.cssText='color:var(--muted);font-size:11px;margin:4px 0 10px';
    di.textContent=d.desc||'';
    zone.append(di);
    const row=document.createElement('div'); row.className='row'; row.style.gap='16px';
    d.params.forEach(p=>{
      row.append(mkKnob(p.label,
        ()=>cur.params[p.key]!=null?cur.params[p.key]:p.def,
        v=>{
          if(!insDirty){ pushUndo(); insDirty=true; }
          cur.params[p.key]=v;
          const inst=insEdit.obj._ch&&insEdit.obj._ch.inserts&&insEdit.obj._ch.inserts[insEdit.slot];
          if(inst) inst.set(p.key,v);
        },
        p.min,p.max,p.fmt||(v=>v.toFixed(2)),p.def));
    });
    zone.append(row);
  } else if(cur){
    const w=document.createElement('p'); w.style.cssText='color:var(--red);font-size:11px';
    w.textContent=`Plugin « ${cur.id} » introuvable : chargez son fichier .js via la Bibliothèque.`;
    zone.append(w);
  }
}
$('#insClose').onclick=()=>$('#insBg').classList.remove('open');
$('#insBg').onclick=e=>{ if(e.target.id==='insBg') e.target.classList.remove('open'); };

/* ===== Chargement de plugins .js (format ouvert TIBO) ===== */
const PLUGIN_TEMPLATE=`/* Plugin TIBO — fichier .js à charger via Bibliothèque > Plugins.
   Le fichier doit appeler registerPlugin({...}) :
   - id      : identifiant unique (sauvegardé dans les projets)
   - name    : nom affiché
   - params  : [{key,label,min,max,def,fmt}] — potentiomètres générés automatiquement
   - create(c) : reçoit un AudioContext (ou OfflineAudioContext à l'export) et
                 retourne {input, output, set(key, valeur)} en nœuds Web Audio. */
registerPlugin({
  id:'monfiltre', name:'Mon Filtre',
  desc:'Passe-bas résonant — exemple de plugin TIBO.',
  params:[
    {key:'freq',label:'FREQ',min:100,max:8000,def:1200,fmt:v=>Math.round(v)+' Hz'},
    {key:'q',   label:'RES', min:0.3,max:14,  def:2,   fmt:v=>v.toFixed(1)},
  ],
  create(c){
    const f=c.createBiquadFilter();
    f.type='lowpass'; f.frequency.value=1200; f.Q.value=2;
    return {input:f,output:f,set(k,v){
      if(k==='freq') f.frequency.value=v;
      if(k==='q') f.Q.value=v;
    }};
  }
});`;
async function loadPluginFile(f){
  try{
    const code=await f.text();
    const before=Object.keys(PLUGINS).length;
    new Function('registerPlugin',code)(registerPlugin);
    const added=Object.keys(PLUGINS).length-before;
    renderPluginCards();
    /* réactiver les slots qui attendaient ce plugin */
    [...insts,...tracks].forEach(o=>{ if((o.fxIns||[]).some(s=>s&&PLUGINS[s.id])) rebuildChan(o); });
    setStatus(added>0
      ?`Plugin chargé : ${f.name} (${added} effet(s) ajoutés) — disponible dans les inserts du mixeur.`
      :`${f.name} exécuté, mais aucun registerPlugin() détecté.`);
  }catch(err){ setStatus('Plugin invalide ('+f.name+') : '+err); }
}
$('#filePlugin').addEventListener('change',e=>{
  [...e.target.files].forEach(loadPluginFile);
  e.target.value='';
});
function renderPluginCards(){
  const grid=$('#plugGrid'); if(!grid) return;
  grid.innerHTML='';
  Object.values(PLUGINS).forEach(d=>{
    const c=document.createElement('div'); c.className='card';
    c.innerHTML=`<h4>${d.name} <span class="badge cc0">INSERT</span></h4><p>${d.desc||'Plugin chargé.'}<br><span style="opacity:.7">id : ${d.id} · ${d.params.length} paramètre(s)</span></p>`;
    grid.append(c);
  });
  const imp=document.createElement('div'); imp.className='card';
  imp.innerHTML=`<h4>Charger un plugin .js <span class="badge mix">FORMAT OUVERT</span></h4>
    <p>Un plugin TIBO est un simple fichier JavaScript qui appelle <b>registerPlugin()</b> avec des nœuds Web Audio. Il s'insère ensuite sur n'importe quelle tranche et s'applique aussi à l'export.</p>`;
  const row=document.createElement('div'); row.className='row2';
  const b1=document.createElement('button'); b1.className='btn'; b1.textContent='＋ Charger…';
  b1.onclick=()=>$('#filePlugin').click();
  const b2=document.createElement('button'); b2.className='btn'; b2.textContent='Modèle de plugin';
  b2.onclick=()=>{
    dlBlob(new Blob([PLUGIN_TEMPLATE],{type:'text/javascript'}),'plugin-tibo-exemple.js');
    setStatus('Modèle téléchargé : ouvrez-le, modifiez-le, rechargez-le — votre premier plugin !');
  };
  row.append(b1,b2); imp.append(row); grid.append(imp);
}
renderPluginCards();
