/* ---------- Voix ---------- */
const VOICES={
  kick(c,noise,dest,t,v){
    const o=c.createOscillator(), g=c.createGain();
    o.frequency.setValueAtTime(155,t);
    o.frequency.exponentialRampToValueAtTime(44,t+0.11);
    g.gain.setValueAtTime(v*1.15,t);
    g.gain.exponentialRampToValueAtTime(0.001,t+0.32);
    o.connect(g).connect(dest); o.start(t); o.stop(t+0.34);
  },
  snare(c,noise,dest,t,v){
    const n=c.createBufferSource(); n.buffer=noise;
    const f=c.createBiquadFilter(), g=c.createGain();
    f.type='bandpass'; f.frequency.value=1900; f.Q.value=0.8;
    g.gain.setValueAtTime(v*0.85,t);
    g.gain.exponentialRampToValueAtTime(0.001,t+0.16);
    n.connect(f).connect(g).connect(dest); n.start(t); n.stop(t+0.2);
    const o=c.createOscillator(), g2=c.createGain();
    o.type='triangle'; o.frequency.value=185;
    g2.gain.setValueAtTime(v*0.5,t);
    g2.gain.exponentialRampToValueAtTime(0.001,t+0.09);
    o.connect(g2).connect(dest); o.start(t); o.stop(t+0.1);
  },
  hat(c,noise,dest,t,v){
    const n=c.createBufferSource(); n.buffer=noise;
    const f=c.createBiquadFilter(), g=c.createGain();
    f.type='highpass'; f.frequency.value=7500;
    g.gain.setValueAtTime(v*0.45,t);
    g.gain.exponentialRampToValueAtTime(0.001,t+0.05);
    n.connect(f).connect(g).connect(dest); n.start(t); n.stop(t+0.06);
  },
  clap(c,noise,dest,t,v){
    for(let i=0;i<3;i++){
      const n=c.createBufferSource(); n.buffer=noise;
      const f=c.createBiquadFilter(), g=c.createGain();
      f.type='bandpass'; f.frequency.value=1300; f.Q.value=1.4;
      const tt=t+i*0.011;
      g.gain.setValueAtTime(v*0.55,tt);
      g.gain.exponentialRampToValueAtTime(0.001,tt+0.11);
      n.connect(f).connect(g).connect(dest); n.start(tt); n.stop(tt+0.13);
    }
  }
};
function playSample(c,dest,buf,t,v,rate=1,off=0){
  const s=c.createBufferSource(), g=c.createGain();
  s.buffer=buf; g.gain.value=v; s.playbackRate.value=rate;
  s.connect(g).connect(dest);
  s.start(t,Math.max(0,Math.min(off,buf.duration-0.01)));
}
function playSynth(c,dest,t,midi,dur,v=0.8,cutMul=1,P=SYNTHS.lead){
  const f=440*Math.pow(2,(midi-69)/12);
  const o1=c.createOscillator(), o2=c.createOscillator();
  o1.type=P.w1; o2.type=P.w2;
  o1.frequency.value=f; o2.frequency.value=f; o2.detune.value=P.det;
  const flt=c.createBiquadFilter();
  flt.type='lowpass'; flt.Q.value=P.q;
  flt.frequency.setValueAtTime(Math.max(120,P.cut*cutMul),t);
  flt.frequency.exponentialRampToValueAtTime(Math.max(90,P.cutEnd*cutMul),t+Math.max(0.05,dur));
  const g=c.createGain(), a=P.atk, r=P.rel, end=t+dur;
  g.gain.setValueAtTime(0,t);
  g.gain.linearRampToValueAtTime(v*P.lvl,t+a);
  g.gain.setValueAtTime(v*P.lvl,Math.max(t+a,end-0.02));
  g.gain.linearRampToValueAtTime(0.0001,end+r);
  o1.connect(flt); o2.connect(flt); flt.connect(g).connect(dest);
  o1.start(t); o2.start(t); o1.stop(end+r+0.05); o2.stop(end+r+0.05);
}
/* Tic de métronome : aigu sur le premier temps, médium sur les autres */
let metVol=1;                  /* volume du métronome (clic droit sur ◔) */
function tick(c,dest,t,acc){
  const o=c.createOscillator(), g=c.createGain();
  o.frequency.value=acc?1568:1046;
  g.gain.setValueAtTime((acc?0.45:0.28)*metVol,t);
  g.gain.exponentialRampToValueAtTime(0.001,t+0.05);
  o.connect(g).connect(dest); o.start(t); o.stop(t+0.06);
}
