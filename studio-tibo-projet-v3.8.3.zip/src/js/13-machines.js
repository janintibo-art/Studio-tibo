/* ---------- Machines à rythmes (modules style Groove Agent) ---------- */
/* Chaque son est une fonction (c,noise,dest,t,v) — même signature que VOICES,
   donc identique en lecture live et à l'export offline. */
const _env=(p,t,peak,dec)=>{p.setValueAtTime(Math.max(0.001,peak),t);p.exponentialRampToValueAtTime(0.001,t+dec);};
const _nz=(c,noise)=>{const s=c.createBufferSource();s.buffer=noise;s.loop=true;return s;};

const mKick=P=>(c,noise,dest,t,v)=>{
  const o=c.createOscillator(),g=c.createGain();
  o.type='sine';
  o.frequency.setValueAtTime(P.f0,t);
  o.frequency.exponentialRampToValueAtTime(P.f1,t+(P.drop||0.09));
  _env(g.gain,t,v*0.95,P.dec);
  o.connect(g).connect(dest); o.start(t); o.stop(t+P.dec+0.05);
  if(P.click){
    const ck=c.createOscillator(),cg=c.createGain();
    ck.type='square'; ck.frequency.value=1100;
    _env(cg.gain,t,v*P.click,0.012);
    ck.connect(cg).connect(dest); ck.start(t); ck.stop(t+0.03);
  }
};
const mSnare=P=>(c,noise,dest,t,v)=>{
  const o=c.createOscillator(),og=c.createGain();
  o.type='sine';
  o.frequency.setValueAtTime(P.tone,t);
  o.frequency.exponentialRampToValueAtTime(P.tone*0.7,t+0.05);
  _env(og.gain,t,v*0.5,P.dec);
  o.connect(og).connect(dest); o.start(t); o.stop(t+P.dec+0.05);
  const n=_nz(c,noise),hp=c.createBiquadFilter(),ng=c.createGain();
  hp.type='highpass'; hp.frequency.value=P.hp;
  _env(ng.gain,t,v*0.6,P.ndec);
  n.connect(hp).connect(ng).connect(dest); n.start(t); n.stop(t+P.ndec+0.05);
};
const mHat=P=>(c,noise,dest,t,v)=>{
  const n=_nz(c,noise),hp=c.createBiquadFilter(),g=c.createGain();
  hp.type='highpass'; hp.frequency.value=P.hp;
  _env(g.gain,t,v*0.42,P.dec);
  n.connect(hp).connect(g).connect(dest); n.start(t); n.stop(t+P.dec+0.05);
  return {g};
};
const mClap=P=>(c,noise,dest,t,v)=>{
  [[0,0.45],[0.012,0.4],[0.026,0.85]].forEach(([dt,a])=>{
    const n=_nz(c,noise),bp=c.createBiquadFilter(),g=c.createGain();
    bp.type='bandpass'; bp.frequency.value=1100; bp.Q.value=1.2;
    _env(g.gain,t+dt,v*a*0.7,dt<0.02?0.03:0.18);
    n.connect(bp).connect(g).connect(dest); n.start(t+dt); n.stop(t+dt+0.25);
  });
};
const mTom=P=>(c,noise,dest,t,v)=>{
  const o=c.createOscillator(),g=c.createGain();
  o.type='sine';
  o.frequency.setValueAtTime(P.f,t);
  o.frequency.exponentialRampToValueAtTime(P.f*0.55,t+0.12);
  _env(g.gain,t,v*0.85,0.3);
  o.connect(g).connect(dest); o.start(t); o.stop(t+0.36);
};
const mCow=P=>(c,noise,dest,t,v)=>{
  const bp=c.createBiquadFilter(),g=c.createGain();
  bp.type='bandpass'; bp.frequency.value=850; bp.Q.value=3;
  [540,810].forEach(f=>{
    const o=c.createOscillator(); o.type='square'; o.frequency.value=f;
    o.connect(bp); o.start(t); o.stop(t+0.22);
  });
  _env(g.gain,t,v*0.5,0.18);
  bp.connect(g).connect(dest);
};
const mRim=P=>(c,noise,dest,t,v)=>{
  const o=c.createOscillator(),g=c.createGain();
  o.type='square'; o.frequency.value=1700;
  _env(g.gain,t,v*0.45,0.025);
  o.connect(g).connect(dest); o.start(t); o.stop(t+0.05);
};
const mCym=P=>(c,noise,dest,t,v)=>{
  const n=_nz(c,noise),hp=c.createBiquadFilter(),bp=c.createBiquadFilter(),g=c.createGain();
  hp.type='highpass'; hp.frequency.value=5200;
  bp.type='peaking'; bp.frequency.value=9200; bp.gain.value=7;
  _env(g.gain,t,v*0.45,P.dec);
  n.connect(hp).connect(bp).connect(g).connect(dest); n.start(t); n.stop(t+P.dec+0.1);
};
const mZap=P=>(c,noise,dest,t,v)=>{
  const o=c.createOscillator(),g=c.createGain();
  o.type='sine';
  o.frequency.setValueAtTime(P.f0,t);
  o.frequency.exponentialRampToValueAtTime(P.f1,t+P.swp);
  _env(g.gain,t,v*0.9,P.dec);
  o.connect(g).connect(dest); o.start(t); o.stop(t+P.dec+0.05);
};
const mBlip=P=>(c,noise,dest,t,v)=>{
  const o=c.createOscillator(),g=c.createGain();
  o.type='square'; o.frequency.value=P.f;
  _env(g.gain,t,v*0.35,0.06);
  o.connect(g).connect(dest); o.start(t); o.stop(t+0.1);
};
const mNzHit=P=>(c,noise,dest,t,v)=>{
  const n=_nz(c,noise),bp=c.createBiquadFilter(),g=c.createGain();
  bp.type='bandpass'; bp.frequency.value=P.f; bp.Q.value=2.2;
  _env(g.gain,t,v*0.75,P.dec);
  n.connect(bp).connect(g).connect(dest); n.start(t); n.stop(t+P.dec+0.05);
};

const MACHINES={
  m808:{label:'TIBO 808', tag:'808', color:'#FF6A8A',
    desc:'La légende boomy : kick long et profond, cowbell iconique, toms ronds.',
    sounds:[
      ['BD','Kick boomy',        mKick({f0:150,f1:41,drop:0.1,dec:0.55,click:0})],
      ['SD','Snare claquante',   mSnare({tone:185,dec:0.16,hp:900,ndec:0.22})],
      ['LT','Tom grave',         mTom({f:95})],
      ['MT','Tom médium',        mTom({f:140})],
      ['HT','Tom aigu',          mTom({f:195})],
      ['CH','Charley fermé',     mHat({hp:7400,dec:0.05}), 'hh8'],
      ['OH','Charley ouvert',    mHat({hp:6400,dec:0.34}), 'hh8'],
      ['CP','Clap',              mClap({})],
      ['CB','Cowbell',           mCow({})],
      ['RS','Rimshot',           mRim({})],
    ]},
  m909:{label:'TIBO 909', tag:'909', color:'#FFA03F',
    desc:'La machine des clubs : kick avec attaque, hats brillants, crash et ride.',
    sounds:[
      ['BD','Kick punchy',       mKick({f0:210,f1:50,drop:0.06,dec:0.32,click:0.5})],
      ['SD','Snare dense',       mSnare({tone:220,dec:0.12,hp:1400,ndec:0.18})],
      ['LT','Tom grave',         mTom({f:110})],
      ['HT','Tom aigu',          mTom({f:175})],
      ['CH','Charley fermé',     mHat({hp:8600,dec:0.04}), 'hh9'],
      ['OH','Charley ouvert',    mHat({hp:7800,dec:0.28}), 'hh9'],
      ['CP','Clap',              mClap({})],
      ['CR','Crash',             mCym({dec:0.9})],
      ['RD','Ride',              mCym({dec:0.45})],
    ]},
  mele:{label:'TIBO Electro', tag:'ELC', color:'#7CE3B8',
    desc:'Percussions synthétiques : zaps, lasers, blips et impacts de bruit.',
    sounds:[
      ['ZAP','Kick zap',         mZap({f0:1900,f1:44,swp:0.07,dec:0.3})],
      ['SUB','Sub boom',         mKick({f0:80,f1:38,drop:0.16,dec:0.7,click:0})],
      ['SNM','Snare métal',      mNzHit({f:1750,dec:0.2})],
      ['TIK','Tick',             mHat({hp:9500,dec:0.025}), 'hhe'],
      ['OHX','Tick ouvert',      mHat({hp:8800,dec:0.22}), 'hhe'],
      ['LAZ','Laser',            mZap({f0:3000,f1:170,swp:0.22,dec:0.26})],
      ['BLP','Blip',             mBlip({f:880})],
      ['NHX','Impact bruit',     mNzHit({f:420,dec:0.24})],
    ]},
};
const machSound=tr=>MACHINES[tr.mach.kit].sounds[tr.mach.si][2];
/* Étouffement (choke) : tout déclenchement d'un groupe coupe la voix précédente
   du même groupe — le charley fermé étouffe l'ouvert, comme sur une vraie machine. */
const chokeReg=new WeakMap();
function trigMach(tr,c,noise,dest,t,v){
  const s=MACHINES[tr.mach.kit].sounds[tr.mach.si];
  const h=s[2](c,noise,dest,t,v);
  const grp=s[3];
  if(!grp) return;
  let m=chokeReg.get(c);
  if(!m){ m={}; chokeReg.set(c,m); }
  const prev=m[grp];
  if(prev&&prev.g&&prev.t<t){
    try{
      const gp=prev.g.gain;
      if(gp.cancelAndHoldAtTime) gp.cancelAndHoldAtTime(t);
      else { gp.cancelScheduledValues(t); gp.setValueAtTime(0.12,t); }
      gp.linearRampToValueAtTime(0.0001,t+0.014);
    }catch(e){}
  }
  m[grp]={g:h&&h.g,t};
}
const machineCount=kid=>tracks.filter(t=>t.kind==='mach'&&t.mach.kit===kid).length;

function addMachine(kid){
  const M=MACHINES[kid];
  if(machineCount(kid)){ setStatus('La machine '+M.label+' est déjà chargée dans le séquenceur.'); return; }
  pushUndo();
  M.sounds.forEach((s,si)=>{
    tracks.push(normCh({name:(s[0]+' '+M.tag).slice(0,22),kind:'mach',mach:{kit:kid,si},
      mute:false,solo:false,gain:0.85,pan:0}));
    patterns.forEach(p=>p.steps.push(Array(NSTEPS).fill(0)));
  });
  renderTracks(); renderMixer(); renderMachineCards();
  switchView('seq');
  setStatus('Module chargé : '+M.label+' — '+M.sounds.length+' sons, chacun avec sa piste, sa tranche de mixeur et son stem.');
}
function removeMachine(kid){
  pushUndo();
  for(let i=tracks.length-1;i>=0;i--)
    if(tracks[i].kind==='mach'&&tracks[i].mach.kit===kid){
      tracks.splice(i,1);
      patterns.forEach(p=>p.steps.splice(i,1));
    }
  renderTracks(); renderMixer(); renderMachineCards();
  setStatus('Module retiré : '+MACHINES[kid].label+' (et ses pas dans tous les patterns) — ⌘Z pour revenir.');
}
function renderMachineCards(){
  const grid=$('#machGrid'); if(!grid) return;
  grid.innerHTML='';
  Object.entries(MACHINES).forEach(([kid,M])=>{
    const c=document.createElement('div'); c.className='card';
    c.innerHTML=`<h4><span class="sw" style="background:${M.color};width:10px;height:10px;display:inline-block;border-radius:3px;margin-right:6px"></span>${M.label} <span class="badge mix">MODULE</span></h4><p>${M.desc}</p>`;
    const pads=document.createElement('div'); pads.className='mpads';
    M.sounds.forEach(s=>{
      const b=document.createElement('button');
      b.className='mpad'; b.textContent=s[0]; b.title=s[1]+' — cliquez pour écouter';
      b.style.borderColor=M.color;
      b.onclick=()=>{ audio(); s[2](ctx,liveNoise,masterIn,ctx.currentTime+0.02,1); };
      pads.append(b);
    });
    c.append(pads);
    const row=document.createElement('div'); row.className='row2';
    const act=document.createElement('button'); act.className='btn';
    if(machineCount(kid)){
      act.textContent='Retirer du séquenceur';
      act.onclick=()=>removeMachine(kid);
    } else {
      act.textContent='＋ Ajouter au séquenceur';
      act.style.borderColor=M.color;
      act.onclick=()=>addMachine(kid);
    }
    row.append(act); c.append(row);
    grid.append(c);
  });
}
renderMachineCards();
