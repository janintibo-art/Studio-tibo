/* ---------- Glisser-déposer universel : des fichiers n'importe où ---------- */
let _dragDepth=0;
function _dropHintEl(){
  let h=$('#dropHint');
  if(!h&&document.body){
    h=document.createElement('div');
    h.id='dropHint';
    h.innerHTML='<div>Déposez vos fichiers<br><small>samples audio · MIDI · projets .tibo / .json · plugins .js</small></div>';
    document.body.append(h);
  }
  return h;
}
document.addEventListener('dragover',e=>{ e.preventDefault(); });
document.addEventListener('dragenter',e=>{
  e.preventDefault();
  if(e.target.closest&&e.target.closest('#libDrop')) return;   /* la bibliothèque a son propre cadre */
  _dragDepth++;
  const h=_dropHintEl(); if(h) h.classList.add('on');
});
document.addEventListener('dragleave',()=>{
  if(--_dragDepth<=0){ _dragDepth=0; const h=$('#dropHint'); if(h) h.classList.remove('on'); }
});
document.addEventListener('drop',async e=>{
  e.preventDefault();
  _dragDepth=0; const h=$('#dropHint'); if(h) h.classList.remove('on');
  if(e.target.closest&&e.target.closest('#libDrop')) return;
  const files=[...(e.dataTransfer&&e.dataTransfer.files||[])];
  if(!files.length) return;
  audio();
  const rest=[];
  for(const f of files){
    try{
      if(/\.(tibo|zip)$/i.test(f.name)){
        pushUndo();
        await applyTiboBuffer(await f.arrayBuffer(),f.name);
      } else if(/\.json$/i.test(f.name)){
        const d=JSON.parse(await f.text());
        if(d.app!=='studio-un') throw 'format inconnu';
        pushUndo(); applyProject(d);
        setStatus('Projet ouvert par glisser-déposer : '+f.name+'.');
      } else if(/\.js$/i.test(f.name)&&typeof loadPluginFile==='function'){
        await loadPluginFile(f);
      } else rest.push(f);
    }catch(err){ setStatus('Fichier ignoré ('+f.name+') : '+err); }
  }
  if(rest.length) await libImport(rest);   /* audio → pistes, .mid → patterns */
});
