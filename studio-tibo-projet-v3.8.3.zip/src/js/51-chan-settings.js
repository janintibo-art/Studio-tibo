/* ---------- Réglages par son : VOL / PAN / GRAVES / MÉDIUMS / AIGUS (+ vitesse) ---------- */
/* Courbe de réponse de l'EQ 3 bandes (mêmes filtres que le moteur : 200 Hz / 1 kHz Q0.9 / 4,2 kHz) */
const _eqNF=128, _eqFreqs=new Float32Array(_eqNF);
for(let i=0;i<_eqNF;i++) _eqFreqs[i]=20*Math.pow(1000,i/(_eqNF-1));   /* 20 Hz → 20 kHz log */
function drawEqCurve(obj){
  const cv=$('#eqCurve'); if(!cv||!cv.getContext) return;
  audio();
  const g=cv.getContext('2d'); if(!g) return;
  const W=cv.width,H=cv.height;
  g.clearRect(0,0,W,H);
  g.fillStyle='rgba(255,255,255,.04)'; g.fillRect(0,0,W,H);
  g.strokeStyle='rgba(255,255,255,.12)';
  g.beginPath(); g.moveTo(0,H/2); g.lineTo(W,H/2); g.stroke();   /* 0 dB */
  try{
    const mk=(type,f,q,gain)=>{
      const b=ctx.createBiquadFilter();
      b.type=type; b.frequency.value=f; if(q) b.Q.value=q; b.gain.value=gain;
      return b;
    };
    const fl=[mk('lowshelf',200,0,obj.eq.lo),mk('peaking',1000,0.9,obj.eq.mid),mk('highshelf',4200,0,obj.eq.hi)];
    const mag=new Float32Array(_eqNF), ph=new Float32Array(_eqNF), tot=new Float32Array(_eqNF).fill(1);
    for(const b of fl){
      b.getFrequencyResponse(_eqFreqs,mag,ph);
      for(let i=0;i<_eqNF;i++) tot[i]*=mag[i];
    }
    g.strokeStyle='#3EC8FF'; g.lineWidth=2; g.beginPath();
    for(let i=0;i<_eqNF;i++){
      const db=20*Math.log10(Math.max(1e-4,tot[i]));
      const y=H/2-db/15*(H/2);                                    /* ±15 dB pleine échelle */
      const x=i/(_eqNF-1)*W;
      i?g.lineTo(x,y):g.moveTo(x,y);
    }
    g.stroke();
  }catch(e){}
}
function applyChanLive(o){
  if(!o._ch) return;
  o._ch.g.gain.value=o.gain;
  if(o._ch.p.pan) o._ch.p.pan.value=o.pan;
  o._ch.lo.gain.value=o.eq.lo;
  o._ch.mid.gain.value=o.eq.mid;
  o._ch.hi.gain.value=o.eq.hi;
}
function openChanSettings(tr){
  let dirty=false;
  const tag=()=>{ if(!dirty){ pushUndo(); dirty=true; } };
  $('#chanTitle').textContent='Réglages du son — '+tr.name;
  const zone=$('#chanKnobs'); zone.innerHTML='';
  const row=document.createElement('div'); row.className='row'; row.style.gap='16px';
  row.append(
    mkKnob('VOL',    ()=>tr.gain,  v=>{tag();tr.gain=v;applyChanLive(tr);},0,1.2,v=>Math.round(v*100)+' %',0.9),
    mkKnob('PAN',    ()=>tr.pan,   v=>{tag();tr.pan=v;applyChanLive(tr);},-1,1,v=>Math.abs(v)<0.02?'C':(v<0?'G ':'D ')+Math.round(Math.abs(v)*100),0),
    mkKnob('GRAVES', ()=>tr.eq.lo, v=>{tag();tr.eq.lo=v;applyChanLive(tr);drawEqCurve(tr);},-12,12,v=>v.toFixed(1)+' dB'),
    mkKnob('MÉDIUMS',()=>tr.eq.mid,v=>{tag();tr.eq.mid=v;applyChanLive(tr);drawEqCurve(tr);},-12,12,v=>v.toFixed(1)+' dB'),
    mkKnob('AIGUS',  ()=>tr.eq.hi, v=>{tag();tr.eq.hi=v;applyChanLive(tr);drawEqCurve(tr);},-12,12,v=>v.toFixed(1)+' dB'),
  );
  zone.append(row);
  const oldEq=$('#eqCurve'); if(oldEq) oldEq.remove();
  const eqcv=document.createElement('canvas');
  eqcv.width=380; eqcv.height=70; eqcv.id='eqCurve'; eqcv.className='wavecv';
  $('#chanKnobs').insertAdjacentElement('afterend',eqcv);
  setTimeout(()=>drawEqCurve(tr),0);
  const sz=$('#chanSpeed'); sz.innerHTML='';
  if(tr.kind==='sample'){
    const cv=document.createElement('canvas');
    cv.width=380; cv.height=64; cv.className='wavecv';
    sz.append(cv);
    const drawWave=()=>{
      const g=cv.getContext('2d'); if(!g||!tr.buffer) return;
      g.clearRect(0,0,380,64);
      g.fillStyle='rgba(255,255,255,.04)'; g.fillRect(0,0,380,64);
      const d=tr.buffer.getChannelData(0), step=Math.max(1,Math.floor(d.length/380));
      g.strokeStyle='#3EC8FF'; g.beginPath();
      for(let x=0;x<380;x++){
        let mn=1,mx=-1;
        for(let k=0;k<step;k++){ const v=d[x*step+k]||0; if(v<mn)mn=v; if(v>mx)mx=v; }
        g.moveTo(x+0.5,32-mx*30); g.lineTo(x+0.5,32-mn*30);
      }
      g.stroke();
      const ox=Math.min(379,(tr.off||0)/1000/tr.buffer.duration*380);
      g.strokeStyle='var(--red)'; g.strokeStyle='#FF6262';
      g.beginPath(); g.moveTo(ox+0.5,0); g.lineTo(ox+0.5,64); g.stroke();
    };
    tr._drawWave=drawWave;
    setTimeout(drawWave,0);
    const r2=document.createElement('div'); r2.className='row';
    r2.style.cssText='gap:16px;margin-top:14px;align-items:center';
    r2.append(
      mkKnob('VITESSE',()=>tr.spd||1,   v=>{tag();tr.spd=+v.toFixed(2);},0.5,2,v=>'×'+(+v).toFixed(2),1),
      mkKnob('HAUTEUR',()=>tr.pitch||0, v=>{tag();tr.pitch=Math.round(v);},-12,12,v=>(v>0?'+':'')+Math.round(v)+' ½t',0),
      mkKnob('DÉCALAGE',()=>tr.off||0,  v=>{tag();tr.off=Math.round(v);if(tr._drawWave)tr._drawWave();},0,300,v=>Math.round(v)+' ms',0),
    );
    const kp=document.createElement('button');
    kp.className='pchip'+(tr.keep?' sel':'');
    if(tr.keep) kp.style.color='#7CE3B8';
    kp.innerHTML='<span class="sw" style="background:#7CE3B8"></span>Conserver la hauteur';
    kp.title='Time-stretch granulaire : accélérer ou ralentir sans que le son monte ou descende';
    kp.onclick=()=>{ tag(); tr.keep=!tr.keep; openChanSettings(tr); };
    r2.append(kp);
    const hint=document.createElement('p');
    hint.style.cssText='color:var(--muted);font-size:11px;margin:10px 0 0';
    hint.textContent='VITESSE ×0,5 à ×2 — avec « Conserver la hauteur », le timbre reste intact (stretch granulaire). HAUTEUR : ±12 demi-tons à durée constante. DÉCALAGE : rogne le début de la prise (compense la latence d\'un enregistrement micro). Pré-écoutez avec ▶ ; l\'export applique le même traitement.';
    sz.append(r2,hint);
  }
  $('#chanBg').classList.add('open');
}
$('#chanClose').onclick=()=>{ $('#chanBg').classList.remove('open'); renderMixer(); };
$('#chanBg').onclick=e=>{ if(e.target.id==='chanBg'){ e.target.classList.remove('open'); renderMixer(); } };
