/* ---------- Thèmes visuels ---------- */
const THEMES={
  tibo:  {label:'Néon TIBO'},   /* défaut : variables du CSS */
  minuit:{label:'Minuit', vars:{'--amber':'#7FB4FF','--mag':'#5E7CFF','--cyan':'#9AD7FF',
    '--bg':'#090C14','--panel':'#10141E','--panel2':'#161B28','--inset':'#070910',
    '--line':'#243049','--line-soft':'#1A2438','--amber-soft':'rgba(127,180,255,.14)'}},
  braise:{label:'Braise', vars:{'--amber':'#FFB454','--mag':'#FF6A3D','--cyan':'#FFD166',
    '--bg':'#120B0A','--panel':'#1C1210','--panel2':'#241713','--inset':'#0D0807',
    '--line':'#3A2A22','--line-soft':'#2C1F19','--amber-soft':'rgba(255,138,60,.14)'}},
};
let curTheme='tibo';
let curAccent=null;
function applyAccent(){
  for(const d of DOCS){
    const st=d.documentElement.style;
    if(curAccent){
      st.setProperty('--amber',curAccent);
      st.setProperty('--amber-soft',curAccent+'33');
    }
  }
}
function setAccent(hex){
  curAccent=hex;
  applyAccent();
  if(hex) setStatus('Couleur d\'accent personnalisée : '+hex+' — sauvegardée avec le projet (thème par défaut : pastille ↺).');
}
function applyTheme(k){
  if(!THEMES[k]) k='tibo';
  curTheme=k;
  for(const d of DOCS){
    const st=d.documentElement.style;
    ['--amber','--mag','--cyan','--bg','--panel','--panel2','--inset','--line','--line-soft','--amber-soft']
      .forEach(v=>st.removeProperty(v));
    if(THEMES[k].vars) Object.entries(THEMES[k].vars).forEach(([v,val])=>st.setProperty(v,val));
  }
  applyAccent();   /* l'accent personnalisé survit au changement de thème */
  $$('.menu [data-theme]').forEach(b=>{
    b.querySelector('.kbd').textContent=(b.dataset.theme===k?'✓':'');
  });
}
function setNotation(fr){
  noteFr=fr;
  buildPianoRoll();
  if(typeof buildScreenKeys==='function') buildScreenKeys();
  $$('.menu [data-notation]').forEach(b=>{
    b.querySelector('.kbd').textContent=((b.dataset.notation==='fr')===fr?'✓':'');
  });
  setStatus('Notation : '+(fr?'Do Ré Mi (latine)':'C D E (anglo-saxonne)')+'.');
}
{
  const pick=$('#accentPick'), rst=$('#accentReset');
  if(pick) pick.oninput=()=>setAccent(pick.value);
  if(rst) rst.onclick=e=>{ e.stopPropagation(); curAccent=null; applyTheme(curTheme); setStatus('Accent : couleur du thème restaurée.'); };
}
$$('.menu [data-notation]').forEach(b=>b.onclick=()=>setNotation(b.dataset.notation==='fr'));
$$('.menu [data-theme]').forEach(b=>b.onclick=()=>{
  applyTheme(b.dataset.theme);
  setStatus('Thème : '+THEMES[curTheme].label+'.');
});
