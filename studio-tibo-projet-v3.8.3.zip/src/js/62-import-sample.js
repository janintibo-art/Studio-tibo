/* ---------- Import sample ---------- */
$('#fileSample').addEventListener('change',async e=>{
  const f=e.target.files[0]; if(!f) return;
  try{
    audio();
    const buf=await ctx.decodeAudioData(await f.arrayBuffer());
    pushUndo();
    addSampleTrack(f.name.replace(/\.[^.]+$/,''),buf);
    renderTracks(); renderMixer();
    setStatus(`Sample importé : ${f.name} (${buf.duration.toFixed(2)} s) — piste disponible dans tous les patterns.`);
  }catch(err){ setStatus('Format audio non reconnu. Essayez un WAV, MP3 ou OGG.'); }
  e.target.value='';
});
