/* ---------- Onglet VST & Plugins : galerie TIBO installable + catalogue de VST gratuits ---------- */
/* Galerie : plugins au format .js ouvert, code source embarqué — installables en un clic,
   téléchargeables pour les modifier, et réinstallés automatiquement à l'ouverture du projet. */
const GALLERY=[
 {id:'autopan',name:'AutoPan',cat:'Mouvement',
  desc:'Balayage stéréo gauche-droite au tempo de votre choix — nappes vivantes, charleys voyageurs.',
  src:`registerPlugin({
  id:'autopan', name:'AutoPan', desc:'Balayage stéréo automatique.',
  params:[
    {key:'rate', label:'RATE', min:0.1,max:8,  def:0.8, fmt:v=>v.toFixed(1)+' Hz'},
    {key:'depth',label:'DEPTH',min:0,  max:1,  def:0.7, fmt:v=>Math.round(v*100)+' %'},
  ],
  create(c){
    const inp=c.createGain(), out=c.createGain();
    const p=(c.createStereoPanner?c.createStereoPanner():null);
    const lfo=c.createOscillator(), lg=c.createGain();
    lfo.type='sine'; lfo.frequency.value=0.8; lg.gain.value=0.7;
    if(p){ lfo.connect(lg); lg.connect(p.pan); inp.connect(p); p.connect(out); }
    else inp.connect(out);
    lfo.start();
    return {input:inp,output:out,set(k,v){
      if(k==='rate') lfo.frequency.value=v;
      if(k==='depth') lg.gain.value=v;
    }};
  },
});`},
 {id:'tgate',name:'Gate',cat:'Mouvement',
  desc:'Porte rythmique (trance gate) : le son hache en croches/doubles — nappes qui pulsent.',
  src:`registerPlugin({
  id:'tgate', name:'Gate', desc:'Porte rythmique : hache le son en rythme.',
  params:[
    {key:'rate',  label:'RATE',  min:1,   max:16, def:8,   fmt:v=>v.toFixed(0)+' Hz'},
    {key:'depth', label:'DEPTH', min:0,   max:1,  def:0.9, fmt:v=>Math.round(v*100)+' %'},
    {key:'smooth',label:'SMOOTH',min:0.001,max:0.04,def:0.008,fmt:v=>Math.round(v*1000)+' ms'},
  ],
  create(c){
    const inp=c.createGain(), g=c.createGain(), out=c.createGain();
    const lfo=c.createOscillator(), sh=c.createWaveShaper(), lg=c.createGain(), off=c.createGain();
    const N=256, curve=new Float32Array(N);
    for(let i=0;i<N;i++) curve[i]=i<N/2?-1:1;          /* sinus → carré */
    sh.curve=curve;
    const lp=c.createBiquadFilter(); lp.type='lowpass'; lp.frequency.value=1/(2*Math.PI*0.008);
    lfo.type='sine'; lfo.frequency.value=8;
    lg.gain.value=0.45;                                 /* profondeur/2 */
    g.gain.value=1-0.45;
    lfo.connect(sh); sh.connect(lp); lp.connect(lg); lg.connect(g.gain);
    lfo.start();
    inp.connect(g); g.connect(out);
    return {input:inp,output:out,set(k,v){
      if(k==='rate') lfo.frequency.value=v;
      if(k==='depth'){ lg.gain.value=v/2; g.gain.value=1-v/2; }
      if(k==='smooth') lp.frequency.value=1/(2*Math.PI*Math.max(0.001,v));
    }};
  },
});`},
 {id:'tilt',name:'Tilt EQ',cat:'Couleur',
  desc:'Une seule molette pour basculer le spectre : vers les graves (chaud) ou les aigus (aérien).',
  src:`registerPlugin({
  id:'tilt', name:'Tilt EQ', desc:'Bascule du spectre : graves ↔ aigus.',
  params:[
    {key:'tilt',label:'TILT',min:-6,max:6,def:0,fmt:v=>(v>0?'+':'')+v.toFixed(1)+' dB aigus'},
  ],
  create(c){
    const inp=c.createGain(), out=c.createGain();
    const lo=c.createBiquadFilter(); lo.type='lowshelf';  lo.frequency.value=700;
    const hi=c.createBiquadFilter(); hi.type='highshelf'; hi.frequency.value=700;
    inp.connect(lo); lo.connect(hi); hi.connect(out);
    return {input:inp,output:out,set(k,v){
      if(k==='tilt'){ lo.gain.value=-v; hi.gain.value=v; }
    }};
  },
});`},
 {id:'slap',name:'Slap Echo',cat:'Espace',
  desc:'Écho très court à répétition unique (60-180 ms) — la profondeur rockabilly/dub sur une voix ou une caisse claire.',
  src:`registerPlugin({
  id:'slap', name:'Slap Echo', desc:'Écho court à répétition unique.',
  params:[
    {key:'time',label:'TIME',min:0.04,max:0.2,def:0.11,fmt:v=>Math.round(v*1000)+' ms'},
    {key:'mix', label:'MIX', min:0,   max:1,  def:0.35,fmt:v=>Math.round(v*100)+' %'},
  ],
  create(c){
    const inp=c.createGain(), out=c.createGain();
    const d=c.createDelay(0.5), wet=c.createGain(), dry=c.createGain();
    d.delayTime.value=0.11; wet.gain.value=0.35; dry.gain.value=1;
    inp.connect(dry); dry.connect(out);
    inp.connect(d); d.connect(wet); wet.connect(out);
    return {input:inp,output:out,set(k,v){
      if(k==='time') d.delayTime.value=v;
      if(k==='mix') wet.gain.value=v;
    }};
  },
});`},
];
let installedGallery=[];
function installGalleryPlugin(id,quiet){
  const g=GALLERY.find(x=>x.id===id);
  if(!g) return false;
  if(!PLUGINS[id]){
    try{ new Function('registerPlugin',g.src)(registerPlugin); }
    catch(e){ if(!quiet) setStatus('Installation impossible ('+g.name+') : '+e); return false; }
  }
  if(!installedGallery.includes(id)) installedGallery.push(id);
  [...insts,...tracks].forEach(o=>{ if((o.fxIns||[]).some(s=>s&&s.id===id)) rebuildChan(o); });
  if(!quiet){
    renderVstTab(); renderMixer();
    setStatus(g.name+' installé — disponible dans les inserts du mixeur, et mémorisé dans le projet.');
  }
  return true;
}
/* ---------- Catalogue de VST gratuits (liens officiels) ---------- */
const VSTCAT=[
 {name:'Vital',by:'Matt Tytel',cat:'Synthé',url:'https://vital.audio',
  desc:'LE synthé wavetable gratuit de référence — visuel, puissant, des milliers de presets.'},
 {name:'Surge XT',by:'Surge Synth Team',cat:'Synthé',url:'https://surge-synthesizer.github.io',
  desc:'Synthé hybride open source immense : 3 oscillateurs, des dizaines de filtres et d\'effets.'},
 {name:'Dexed',by:'Digital Suburban',cat:'Synthé',url:'https://asb2m10.github.io/dexed/',
  desc:'Clone fidèle du Yamaha DX7 — la FM des années 80, compatible avec ses banques d\'origine.'},
 {name:'TAL-NoiseMaker',by:'TAL Software',cat:'Synthé',url:'https://tal-software.com/products/tal-noisemaker',
  desc:'Synthé analogique virtuel simple et chaud — parfait pour débuter la synthèse.'},
 {name:'Odin 2',by:'TheWaveWarden',cat:'Synthé',url:'https://thewavewarden.com/pages/odin-2',
  desc:'Polyphonique 24 voix musclé, sonorité moderne, open source.'},
 {name:'LABS',by:'Spitfire Audio',cat:'Instruments',url:'https://labs.spitfireaudio.com',
  desc:'Collection gratuite d\'instruments échantillonnés magnifiques : pianos doux, cordes, textures.'},
 {name:'Decent Sampler',by:'DecentSamples',cat:'Instruments',url:'https://www.decentsamples.com/product/decent-sampler-plugin/',
  desc:'Lecteur d\'échantillons gratuit avec un vaste écosystème de banques libres.'},
 {name:'Valhalla Supermassive',by:'Valhalla DSP',cat:'Effet',url:'https://valhalladsp.com/shop/reverb/valhalla-supermassive/',
  desc:'Réverbérations et délais cosmiques — l\'effet gratuit le plus téléchargé au monde.'},
 {name:'TDR Nova',by:'Tokyo Dawn Records',cat:'Effet',url:'https://www.tokyodawn.net/tdr-nova/',
  desc:'Égaliseur dynamique transparent de qualité studio — un indispensable du mixage.'},
 {name:'OTT',by:'Xfer Records',cat:'Effet',url:'https://xferrecords.com/freeware',
  desc:'Le compresseur multibande agressif culte de l\'électro moderne.'},
 {name:'MFreeFXBundle',by:'MeldaProduction',cat:'Effet',url:'https://www.meldaproduction.com/MFreeFXBundle',
  desc:'37 effets gratuits (EQ, comp, vibrato, autopan…) — une boîte à outils complète.'},
 {name:'SPAN',by:'Voxengo',cat:'Effet',url:'https://www.voxengo.com/product/span/',
  desc:'Analyseur de spectre professionnel — pour voir votre mix comme les ingés son.'},
];
let vstFilter='Tous';
function renderVstTab(){
  /* galerie TIBO */
  const gal=$('#galList'); if(!gal) return;
  gal.innerHTML='';
  GALLERY.forEach(g=>{
    const card=document.createElement('div'); card.className='vst-card';
    const inOk=!!PLUGINS[g.id];
    card.innerHTML=`<h4>${g.name} <span class="cat">${g.cat}</span></h4><p>${g.desc}</p>`;
    const row=document.createElement('div'); row.className='row';
    const inst=document.createElement('button');
    inst.className='btn'+(inOk?'':' cy');
    inst.textContent=inOk?'✓ Installé':'＋ Installer';
    inst.disabled=inOk;
    inst.onclick=()=>installGalleryPlugin(g.id);
    const dl=document.createElement('button');
    dl.className='btn'; dl.textContent='⬇ .js';
    dl.title='Télécharger le code source — modifiez-le, rechargez-le : c\'est le format ouvert TIBO';
    dl.onclick=()=>dlBlob(new Blob([g.src],{type:'text/javascript'}),'plugin-'+g.id+'.js');
    row.append(inst,dl);
    card.append(row);
    gal.append(card);
  });
  /* catalogue VST */
  const cats=$('#vstCats'), list=$('#vstList');
  if(!cats||!list) return;
  cats.innerHTML='';
  ['Tous','Synthé','Instruments','Effet'].forEach(c=>{
    const b=document.createElement('button');
    b.className='pchip'+(vstFilter===c?' sel':'');
    if(vstFilter===c) b.style.color='var(--amber)';
    b.textContent=c;
    b.onclick=()=>{ vstFilter=c; renderVstTab(); };
    cats.append(b);
  });
  list.innerHTML='';
  VSTCAT.filter(v=>vstFilter==='Tous'||v.cat===vstFilter).forEach(v=>{
    const card=document.createElement('div'); card.className='vst-card';
    card.innerHTML=`<h4>${v.name} <span class="cat">${v.cat}</span></h4><p class="by">par ${v.by}</p><p>${v.desc}</p>`;
    const row=document.createElement('div'); row.className='row';
    const a=document.createElement('a');
    a.className='btn cy'; a.textContent='⬇ Site officiel';
    a.href=v.url; a.target='_blank'; a.rel='noopener';
    a.title=v.url;
    const cp=document.createElement('button');
    cp.className='btn'; cp.textContent='📋';
    cp.title='Copier le lien';
    cp.onclick=async()=>{
      try{ await navigator.clipboard.writeText(v.url); setStatus('Lien copié : '+v.url); }
      catch(e){ setStatus('Lien : '+v.url); }
    };
    row.append(a,cp);
    card.append(row);
    list.append(card);
  });
}
renderVstTab();
