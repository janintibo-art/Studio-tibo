/* ---------- Bibliothèque : kit interne synthétisé (100 % libre) ---------- */
const KIT=[
  {id:'sub',  name:'Sub Kick 808', desc:'Grave profond à longue queue, parfait pour le trap et la house.'},
  {id:'tom',  name:'Tom analogique', desc:'Tom électronique descendant, façon boîte à rythmes vintage.'},
  {id:'rim',  name:'Rimshot', desc:'Claqué court et sec pour marquer les contretemps.'},
  {id:'shk',  name:'Shaker', desc:'Souffle filtré bref, idéal en doubles-croches.'},
  {id:'bfm',  name:'Basse FM', desc:'Note de basse percussive en synthèse FM (Sol grave).'},
  {id:'plk',  name:'Pluck', desc:'Corde pincée synthétique, balayage de filtre rapide.'},
];
async function renderPreset(id){
  const sr=44100;
  const dur=({sub:0.9,tom:0.5,rim:0.18,shk:0.22,bfm:0.55,plk:0.6})[id];
  const oc=new OfflineAudioContext(1,Math.ceil(sr*dur),sr);
  const out=oc.createGain(); out.gain.value=0.95; out.connect(oc.destination);
  const noise=mkNoise(oc);
  const t=0.002;
  if(id==='sub'){
    const o=oc.createOscillator(), g=oc.createGain();
    o.frequency.setValueAtTime(58,t);
    o.frequency.exponentialRampToValueAtTime(36,t+0.5);
    g.gain.setValueAtTime(1,t);
    g.gain.exponentialRampToValueAtTime(0.001,t+0.85);
    o.connect(g).connect(out); o.start(t); o.stop(dur);
  } else if(id==='tom'){
    const o=oc.createOscillator(), g=oc.createGain();
    o.frequency.setValueAtTime(165,t);
    o.frequency.exponentialRampToValueAtTime(82,t+0.32);
    g.gain.setValueAtTime(0.95,t);
    g.gain.exponentialRampToValueAtTime(0.001,t+0.42);
    o.connect(g).connect(out); o.start(t); o.stop(dur);
  } else if(id==='rim'){
    const n=oc.createBufferSource(); n.buffer=noise;
    const f=oc.createBiquadFilter(); f.type='bandpass'; f.frequency.value=3400; f.Q.value=3.5;
    const g=oc.createGain();
    g.gain.setValueAtTime(1,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.09);
    n.connect(f).connect(g).connect(out); n.start(t); n.stop(dur);
    const o=oc.createOscillator(); o.type='square'; o.frequency.value=1700;
    const g2=oc.createGain();
    g2.gain.setValueAtTime(0.4,t); g2.gain.exponentialRampToValueAtTime(0.001,t+0.03);
    o.connect(g2).connect(out); o.start(t); o.stop(0.05);
  } else if(id==='shk'){
    const n=oc.createBufferSource(); n.buffer=noise;
    const f=oc.createBiquadFilter(); f.type='highpass'; f.frequency.value=6200;
    const g=oc.createGain();
    g.gain.setValueAtTime(0.0001,t);
    g.gain.exponentialRampToValueAtTime(0.8,t+0.02);
    g.gain.exponentialRampToValueAtTime(0.001,t+0.2);
    n.connect(f).connect(g).connect(out); n.start(t); n.stop(dur);
  } else if(id==='bfm'){
    const car=oc.createOscillator(); car.frequency.value=49;
    const mod=oc.createOscillator(); mod.frequency.value=98;
    const mg=oc.createGain(); mg.gain.setValueAtTime(160,t);
    mg.gain.exponentialRampToValueAtTime(8,t+0.3);
    mod.connect(mg); mg.connect(car.frequency);
    const g=oc.createGain();
    g.gain.setValueAtTime(0.9,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.5);
    car.connect(g).connect(out); car.start(t); mod.start(t); car.stop(dur); mod.stop(dur);
  } else if(id==='plk'){
    const o=oc.createOscillator(); o.type='sawtooth'; o.frequency.value=196;
    const f=oc.createBiquadFilter(); f.type='lowpass'; f.Q.value=2;
    f.frequency.setValueAtTime(5200,t);
    f.frequency.exponentialRampToValueAtTime(260,t+0.28);
    const g=oc.createGain();
    g.gain.setValueAtTime(0.85,t); g.gain.exponentialRampToValueAtTime(0.001,t+0.55);
    o.connect(f).connect(g).connect(out); o.start(t); o.stop(dur);
  }
  return oc.startRendering();
}
function renderKit(){
  const grid=$('#kitGrid'); grid.innerHTML='';
  KIT.forEach(k=>{
    const c=document.createElement('div'); c.className='card kit-card';
    c.innerHTML=`<h4>${k.name} <span class="badge cc0">LIBRE</span></h4><p>${k.desc}</p>`;
    const row=document.createElement('div'); row.className='row2';
    const bP=document.createElement('button'); bP.className='btn'; bP.textContent='▶ Écouter';
    bP.onclick=async()=>{
      audio();
      const buf=await renderPreset(k.id);
      playSample(ctx,masterIn,buf,ctx.currentTime+0.02,0.95);
    };
    const bA=document.createElement('button'); bA.className='btn'; bA.textContent='＋ Ajouter';
    bA.onclick=async()=>{
      pushUndo();
      audio();
      const buf=await renderPreset(k.id);
      addSampleTrack(k.name,buf);
      renderTracks(); renderMixer(); updateStats();
      setStatus(`« ${k.name} » ajouté en piste — il est disponible dans tous les patterns.`);
    };
    row.append(bP,bA); c.append(row); grid.append(c);
  });
}
renderKit();
