/* ---------- Export WAV ---------- */
let expReps=1, expSrc='song', expFmt='mix';
async function renderMix(onProg){
  const sr=44100, sp=spStep();
  const nSlots=expSrc==='song'?songLen():1;
  const total=LOOP*sp*nSlots*expReps+fx.rev.size+1.0;
  const oc=new OfflineAudioContext(2,Math.ceil(sr*total),sr);
  const mIn=oc.createGain(); mIn.gain.value=masterCh.gain;
  const comp=oc.createDynamicsCompressor();
  comp.threshold.value=-8; comp.ratio.value=4;
  const lim=oc.createDynamicsCompressor();
  lim.threshold.value=-1; lim.ratio.value=20; lim.knee.value=0;
  lim.attack.value=0.002; lim.release.value=0.08;
  mIn.connect(comp).connect(lim).connect(oc.destination);
  const noise=mkNoise(oc);
  const fxb=mkFxBuses(oc,mIn);
  const mkDest=ch=>{
    const g=oc.createGain(); g.gain.value=ch.gain;
    const lo=oc.createBiquadFilter(); lo.type='lowshelf';  lo.frequency.value=200;  lo.gain.value=ch.eq.lo;
    const mid=oc.createBiquadFilter(); mid.type='peaking'; mid.frequency.value=1000; mid.Q.value=0.9; mid.gain.value=ch.eq.mid;
    const hi=oc.createBiquadFilter(); hi.type='highshelf'; hi.frequency.value=4200; hi.gain.value=ch.eq.hi;
    const p=oc.createStereoPanner?oc.createStereoPanner():oc.createGain();
    if(p.pan) p.pan.value=ch.pan||0;
    g.connect(lo); lo.connect(mid); mid.connect(hi);
    const built=buildInserts(oc,hi,ch.fxIns);
    built.last.connect(p); p.connect(mIn);
    const sR=oc.createGain(); sR.gain.value=ch.send.rev; built.last.connect(sR); sR.connect(fxb.revIn);
    const sD=oc.createGain(); sD.gain.value=ch.send.dly; built.last.connect(sD); sD.connect(fxb.dlyIn);
    return {g,sR,sD};
  };
  const dchain=tracks.map(mkDest), ichain=insts.map(mkDest);
  const dests=dchain.map(d=>d.g), instDests=ichain.map(d=>d.g);
  for(let rep=0;rep<expReps;rep++){
    for(let slot=0;slot<nSlots;slot++){
      const off=(rep*nSlots+slot)*LOOP*sp;
      for(let local=0;local<LOOP;local++){
        const t=off+local*sp+0.05;
        const ts=t+((local%2)?(swing/100)*sp*0.6:0);
        let cut=1;
        if(expSrc==='song'){
          const pos=(slot*LOOP+local)/LOOP;
          const mv=autoVal('master',pos); if(mv!=null) mIn.gain.linearRampToValueAtTime(AUTOP.master.map(mv),t);
          const rv=autoVal('srev',pos);   if(rv!=null&&ichain[autoTarget]) ichain[autoTarget].sR.gain.linearRampToValueAtTime(rv,t);
          const dv=autoVal('sdly',pos);   if(dv!=null&&ichain[autoTarget]) ichain[autoTarget].sD.gain.linearRampToValueAtTime(dv,t);
          const cv=autoVal('cutoff',pos); if(cv!=null) cut=AUTOP.cutoff.map(cv);
          for(const p of patterns) if(p.clips[slot])
            schedulePattern(p,local,ts,oc,noise,dests,instDests,cut);
        } else {
          schedulePattern(patterns[curPat],local,ts,oc,noise,dests,instDests,cut);
        }
      }
    }
  }
  /* progression : suspensions régulières du rendu offline */
  if(typeof onProg==='function'){
    for(let k=1;k<20;k++){
      const at=total*k/20;
      try{ oc.suspend(at).then(()=>{ onProg(Math.round(k*5)); oc.resume(); }); }catch(e){}
    }
  }
  return oc.startRendering();
}
let expTail='tail';
$$('#expTailSel button').forEach(b=>b.onclick=()=>{
  expTail=b.dataset.tail;
  $$('#expTailSel button').forEach(x=>x.classList.toggle('sel',x===b));
});
function finishRender(buf){
  const sp=60/bpm/4;
  const musical=Math.min(buf.length,
    Math.round((expSrc==='song'?LOOP*songLen():LOOP*expReps)*sp*buf.sampleRate));
  if(expTail==='cut'){
    return {numberOfChannels:buf.numberOfChannels,sampleRate:buf.sampleRate,length:musical,
      duration:musical/buf.sampleRate,
      getChannelData:i=>buf.getChannelData(i).subarray(0,musical)};
  }
  if(expTail==='fade'){
    const N=buf.length, F=Math.min(N,Math.round(2*buf.sampleRate));
    for(let c=0;c<buf.numberOfChannels;c++){
      const d=buf.getChannelData(c);
      for(let k=0;k<F;k++) d[N-1-k]*=k/F;
    }
  }
  return buf;
}
function expProgress(pc,label){
  const w=$('#expProg'), bar=$('#expProgBar'), tx=$('#expProgTxt');
  if(!w) return;
  if(pc==null){ w.style.display='none'; return; }
  w.style.display='block';
  bar.style.width=pc+'%';
  tx.textContent=(label||'Rendu')+' — '+pc+' %';
  setStatus((label||'Rendu en cours')+' : '+pc+' %');
}
async function exportWav(){
  expProgress(0);
  const rendered=finishRender(await renderMix(pc=>expProgress(pc)));
  expProgress(100);
  await dlBlob(encodeWav(rendered),
    expSrc==='song'
      ?`${projSlug()}_${bpm}bpm.wav`
      :`${projSlug()}_${patterns[curPat].name.replace(/\s+/g,'-')}_${bpm}bpm_x${expReps}.wav`);
  expProgress(null);
  setStatus(`Export terminé : ${rendered.duration.toFixed(1)} s · 44,1 kHz · 16 bit.`);
}
/* ---------- Export stems : un WAV par canal, livrés en .zip ---------- */
async function exportStems(){
  setStatus('Rendu des stems en cours… (un canal à la fois)');
  const chans=[...insts,...tracks];
  const saved=chans.map(c=>({m:c.mute,s:c.solo}));
  const files=[];
  try{
    /* 00 : mixage complet avec l'état solo/muet d'origine */
    const full=await renderMix();
    files.push({name:'stems/00-Master.wav',data:new Uint8Array(encodeWavBytes(full))});
    for(let i=0;i<chans.length;i++){
      chans.forEach((c,j)=>{c.solo=(j===i);c.mute=false;});
      const r=await renderMix();
      const nm=String(i+1).padStart(2,'0')+'-'+sanitizeName(chans[i].name);
      files.push({name:`stems/${nm}.wav`,data:new Uint8Array(encodeWavBytes(r))});
      setStatus(`Stems : ${i+1}/${chans.length} rendus…`);
    }
  } finally {
    chans.forEach((c,j)=>{c.mute=saved[j].m;c.solo=saved[j].s;});
    renderTracks(); renderMixer();
  }
  await dlBlob(zipStore(files),`${projSlug()}_stems_${bpm}bpm.zip`);
  setStatus(`Stems exportés : ${files.length} fichiers WAV dans l'archive.`);
}
function encodeWav(ab){ return new Blob([encodeWavBytes(ab)],{type:'audio/wav'}); }
function encodeWavBytes(ab){
  const ch=ab.numberOfChannels, len=ab.length, sr=ab.sampleRate;
  const bytes=44+len*ch*2, dv=new DataView(new ArrayBuffer(bytes));
  let p=0;
  const wstr=s=>{for(let i=0;i<s.length;i++)dv.setUint8(p++,s.charCodeAt(i));};
  const w32=v=>{dv.setUint32(p,v,true);p+=4;}, w16=v=>{dv.setUint16(p,v,true);p+=2;};
  wstr('RIFF'); w32(bytes-8); wstr('WAVE'); wstr('fmt '); w32(16);
  w16(1); w16(ch); w32(sr); w32(sr*ch*2); w16(ch*2); w16(16);
  wstr('data'); w32(len*ch*2);
  const chans=[]; for(let c=0;c<ch;c++) chans.push(ab.getChannelData(c));
  for(let i=0;i<len;i++) for(let c=0;c<ch;c++){
    const s=Math.max(-1,Math.min(1,chans[c][i]));
    dv.setInt16(p,s<0?s*0x8000:s*0x7FFF,true); p+=2;
  }
  return dv.buffer;
}
