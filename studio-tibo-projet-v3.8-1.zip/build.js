#!/usr/bin/env node
/* ============================================================
   STUDIO TIBO — bundler maison (zéro dépendance)
   Usage : node build.js
   Concatène src/styles/*.css et src/js/*.js (ordre alphabétique,
   d'où les préfixes numériques) dans src/index.html, et écrit le
   fichier unique dist/studio-tibo-v1.4.html.
   ============================================================ */
const fs = require('fs');
const path = require('path');

const SRC = path.join(__dirname, 'src');
const DIST = path.join(__dirname, 'dist');

function concatDir(dir, sep) {
  return fs.readdirSync(dir)
    .filter(f => !f.startsWith('.'))
    .sort()
    .map(f => fs.readFileSync(path.join(dir, f), 'utf8'))
    .join(sep);
}

const css = concatDir(path.join(SRC, 'styles'), '\n');
const js  = concatDir(path.join(SRC, 'js'), '\n');
let html  = fs.readFileSync(path.join(SRC, 'index.html'), 'utf8');

html = html.replace('{{CSS}}', () => css).replace('{{JS}}', () => js);

if (!fs.existsSync(DIST)) fs.mkdirSync(DIST);
const VERSION = '3.8';
const out = path.join(DIST, `studio-tibo-v${VERSION}.html`);
fs.writeFileSync(out, html);
/* synchroniser les numéros de version de l'application de bureau */
const sync = (file, re, rep) => {
  if (!fs.existsSync(file)) return;
  fs.writeFileSync(file, fs.readFileSync(file, 'utf8').replace(re, rep));
};
sync(path.join(__dirname, 'desktop', 'src-tauri', 'tauri.conf.json'), /"version": "[^"]+"/, `"version": "${VERSION}.0"`);
sync(path.join(__dirname, 'desktop', 'package.json'), /"version": "[^"]+"/, `"version": "${VERSION}.0"`);
sync(path.join(__dirname, 'desktop', 'src-tauri', 'Cargo.toml'), /^version = "[^"]+"/m, `version = "${VERSION}.0"`);
console.log(`✔ versions desktop synchronisées → ${VERSION}.0`);
/* copie pour l'application de bureau (frontendDist de Tauri) */
const desk = path.join(__dirname, 'desktop', 'src');
if (fs.existsSync(desk)) {
  fs.writeFileSync(path.join(desk, 'index.html'), html);
  console.log('✔ desktop/src/index.html synchronisé');
}
console.log(`✔ ${out} — ${(html.length / 1024).toFixed(0)} Ko`);
console.log(`  ${fs.readdirSync(path.join(SRC,'js')).length} modules JS · ${fs.readdirSync(path.join(SRC,'styles')).length} feuilles CSS`);
