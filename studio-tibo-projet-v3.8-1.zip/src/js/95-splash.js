/* ---------- Écran d'accueil ---------- */
document.addEventListener('keydown',e=>{
  if(e.key==='Enter'&&$('#splash')&&!$('#splash').classList.contains('hide')) $('#splashEnter').click();
});
$('#splashEnter').onclick=()=>{
  audio();                       // geste utilisateur : déverrouille le moteur audio
  initMidi();                    // et demande l'accès aux périphériques MIDI
  applyPendingTibo();            // projet .tibo double-cliqué (app de bureau)
  if(window._resume){
    try{
      applyProject(window._resume);
      setStatus('Session précédente restaurée — réglages, patterns et notes. (Les samples audio ne sont pas dans l\'autosauvegarde : sauvegardez en .tibo pour tout conserver.)');
    }catch(e){ setStatus('Reprise impossible : '+e); }
    window._resume=null;
  }
  const sp=$('#splash');
  sp.classList.add('hide');
  setTimeout(()=>sp.remove(),600);
  setStatus(isTauri?'Bienvenue dans STUDIO TIBO bureau — vos exports passent par de vraies boîtes « Enregistrer sous ».':'Bienvenue dans STUDIO TIBO. Appuyez sur espace pour écouter la démo.');
  if(isTauri) $('.logo .ver').textContent+=' · bureau';
};
